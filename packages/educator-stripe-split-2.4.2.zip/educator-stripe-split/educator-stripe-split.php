<?php
/**
 * Plugin Name:       Educator Stripe Split
 * Description:       Pay every educator their share of each course sale and subscription renewal, automatically, straight to their Stripe account. Works with LearnDash, Tutor LMS, LearnPress, LifterLMS and more through WooCommerce.
 * Version:           2.4.2
 * Author:            Faraz Fayaz
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Requires Plugins:  woocommerce
 * WC requires at least: 7.0
 * WC tested up to:   11.1
 * Text Domain:       educator-stripe-split
 */

defined( 'ABSPATH' ) || exit;

define( 'EDSS_VERSION', '2.4.2' );
define( 'EDSS_DB_VERSION', '1' );
define( 'EDSS_FILE', __FILE__ );
define( 'EDSS_DIR', plugin_dir_path( __FILE__ ) );
define( 'EDSS_GROUP', 'educator-stripe-split' );
// edss-private-start
define( 'EDSS_UPDATE_REPO', 'flexyy07/educator-stripe-split-updates' ); // Public release feed that delivers plugin updates.
define( 'EDSS_PRIVATE_BUILD', true ); // Hides the "Pro coming soon" line on the client build.
// edss-private-end

require_once EDSS_DIR . 'includes/class-edss-settings.php';
require_once EDSS_DIR . 'includes/class-edss-stripe.php';
require_once EDSS_DIR . 'includes/class-edss-ledger.php';
require_once EDSS_DIR . 'includes/class-edss-resolver.php';
require_once EDSS_DIR . 'includes/class-edss-processor.php';
require_once EDSS_DIR . 'includes/class-edss-notifier.php';
// edss-private-start
require_once EDSS_DIR . 'includes/class-edss-updater.php';
// edss-private-end
require_once EDSS_DIR . 'includes/class-edss-educator.php';

register_activation_hook( __FILE__, array( 'EDSS_Ledger', 'install' ) );

register_deactivation_hook(
	__FILE__,
	function () {
		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( 'edss_sweep', array(), EDSS_GROUP );
		}
		delete_transient( 'edss_sweep_checked' );
	}
);

// WooCommerce HPOS (custom order tables) compatibility: the plugin only touches orders through WC_Order APIs.
add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		}
	}
);

add_action(
	'plugins_loaded',
	function () {
		// edss-private-start
		EDSS_Updater::init();
		// edss-private-end

		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action(
				'admin_notices',
				function () {
					echo '<div class="notice notice-error"><p><strong>Educator Stripe Split</strong> needs WooCommerce to be active.</p></div>';
				}
			);
			return;
		}

		EDSS_Ledger::maybe_upgrade();
		EDSS_Processor::init();
		EDSS_Notifier::init();
		EDSS_Educator::init();

		if ( is_admin() ) {
			require_once EDSS_DIR . 'includes/class-edss-ledger-table.php';
			require_once EDSS_DIR . 'includes/class-edss-admin.php';
			EDSS_Admin::init();
		}
	}
);
