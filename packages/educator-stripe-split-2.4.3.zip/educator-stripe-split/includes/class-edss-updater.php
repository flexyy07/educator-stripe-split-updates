<?php
/**
 * Plugin updates from the public release feed EDSS_UPDATE_REPO (info.json + packages/*.zip on its main branch).
 *
 * WordPress shows "Update now" (and allows auto-updates) whenever info.json names a version newer than
 * EDSS_VERSION. No key or token is needed.
 */

defined( 'ABSPATH' ) || exit;

class EDSS_Updater {

	const SLUG  = 'educator-stripe-split';
	const CACHE = 'edss_update_release';

	public static function init() {
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'inject' ) );
		add_filter( 'plugins_api', array( __CLASS__, 'info' ), 20, 3 );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'flush' ) );
	}

	public static function flush() {
		delete_transient( self::CACHE );
	}

	/**
	 * Latest release, cached for 6 hours (errors for 1 hour).
	 *
	 * @return array|WP_Error {version, package, notes, published}
	 */
	public static function latest( $force = false ) {
		if ( ! $force ) {
			$cached = get_transient( self::CACHE );
			if ( is_array( $cached ) ) {
				return isset( $cached['error'] ) ? new WP_Error( 'edss_update', $cached['error'] ) : $cached;
			}
		}
		if ( ! defined( 'EDSS_UPDATE_REPO' ) ) {
			return new WP_Error( 'edss_update', 'Updates are not configured for this copy of the plugin.' );
		}

		// info.json and the zip are plain files served straight from raw.githubusercontent.com: no redirect to a
		// signed URL, which WordPress's downloader could not follow ("Download failed. Unauthorized").
		$base = 'https://raw.githubusercontent.com/' . EDSS_UPDATE_REPO . '/main/';
		$res  = wp_remote_get(
			$base . 'info.json',
			array(
				'timeout' => 15,
				'headers' => array( 'User-Agent' => self::SLUG ),
			)
		);
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$body = json_decode( wp_remote_retrieve_body( $res ), true );

		$error = '';
		if ( 200 !== $code || ! is_array( $body ) ) {
			$error = sprintf( 'The update server answered with HTTP %d. Please try again later.', $code );
		} elseif ( empty( $body['version'] ) || empty( $body['package'] ) || 0 !== strpos( (string) $body['package'], $base ) ) {
			$error = 'The update information is incomplete.'; // Only packages from our own feed are ever installed.
		}
		if ( $error ) {
			set_transient( self::CACHE, array( 'error' => $error ), HOUR_IN_SECONDS );
			return new WP_Error( 'edss_update', $error );
		}

		$data = array(
			'version'   => ltrim( (string) $body['version'], 'vV' ),
			'package'   => (string) $body['package'],
			'notes'     => (string) ( $body['notes'] ?? '' ),
			'published' => (string) ( $body['published'] ?? '' ),
		);
		set_transient( self::CACHE, $data, 6 * HOUR_IN_SECONDS );
		return $data;
	}

	private static function item( $release ) {
		$file = plugin_basename( EDSS_FILE );
		return (object) array(
			'id'           => $file,
			'slug'         => self::SLUG,
			'plugin'       => $file,
			'new_version'  => $release['version'],
			'url'          => '',
			'package'      => $release['package'],
			'icons'        => array(),
			'banners'      => array(),
			'requires_php' => '7.4',
		);
	}

	/** Adds our update to WordPress's plugin-update list. */
	public static function inject( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}
		$release = self::latest( ! empty( $_GET['force-check'] ) ); // phpcs:ignore WordPress.Security.NonceVerification -- core "Check again" link.
		if ( is_wp_error( $release ) ) {
			return $transient;
		}
		$file = plugin_basename( EDSS_FILE );
		if ( version_compare( $release['version'], EDSS_VERSION, '>' ) ) {
			$transient->response[ $file ] = self::item( $release );
		} else {
			if ( isset( $transient->response[ $file ] ) ) {
				unset( $transient->response[ $file ] );
			}
			$transient->no_update[ $file ] = self::item( $release );
		}
		return $transient;
	}

	/** "View details" popup on the Plugins screen. */
	public static function info( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || self::SLUG !== $args->slug ) {
			return $result;
		}
		$release = self::latest();
		if ( is_wp_error( $release ) ) {
			return $result;
		}
		return (object) array(
			'name'          => 'Educator Stripe Split',
			'slug'          => self::SLUG,
			'version'       => $release['version'],
			'author'        => 'Faraz Fayaz',
			'requires_php'  => '7.4',
			'last_updated'  => $release['published'],
			'sections'      => array( 'changelog' => $release['notes'] ? nl2br( esc_html( $release['notes'] ) ) : 'No release notes.' ),
			'download_link' => $release['package'],
		);
	}
}
