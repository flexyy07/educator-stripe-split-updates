<?php
/**
 * The critical mapping: WooCommerce Product → Course (any LMS) → Educator (WP user) → Stripe acct_… + split rule.
 * Uses IDs only — never names or emails.
 */

defined( 'ABSPATH' ) || exit;

class EDSS_Resolver {

	const ACCT_REGEX = '/^acct_[A-Za-z0-9]+$/';

	/* Meta keys. Test and live connected accounts are different Stripe objects, so each educator stores both. */
	const USER_ACCT_TEST   = 'edss_acct_test';
	const USER_ACCT_LIVE   = 'edss_acct_live';
	const USER_ACTIVE      = 'edss_active';
	const USER_SPLIT_TYPE  = 'edss_split_type';
	const USER_SPLIT_VALUE = 'edss_split_value';
	const POST_EDUCATOR    = '_edss_educator_id';
	const POST_COURSE      = '_edss_course_id';
	const POST_SPLIT_TYPE  = '_edss_split_type';
	const POST_SPLIT_VALUE = '_edss_split_value';
	const POST_NO_SPLIT    = '_edss_no_split';
	const POST_CO          = '_edss_co_educators'; // array of array( 'user' => id, 'type' => percent|fixed, 'value' => number ).
	const USER_IS_EDUCATOR = 'edss_is_educator'; // 'yes' on a product or course = never split, the platform keeps 100%.
	/**
	 * Course post types of the common WordPress LMS plugins. Any other platform works too: tick its post type
	 * in Settings (or use the edss_course_post_types filter).
	 */
	const KNOWN_COURSE_TYPES = array(
		'sfwd-courses' => 'LearnDash',
		'courses'      => 'Tutor LMS',
		'lp_course'    => 'LearnPress',
		'course'       => 'LifterLMS / Sensei LMS',
		'stm-courses'  => 'MasterStudy LMS',
	);

	/** Course post types in use: the ones ticked in Settings, otherwise every known LMS type that exists on this site. */
	public static function course_post_types() {
		$types = array_filter( (array) EDSS_Settings::get( 'course_post_types' ) );
		if ( ! $types ) {
			$types = array_keys( self::KNOWN_COURSE_TYPES );
		}
		$types = array_values( array_filter( $types, 'post_type_exists' ) );
		return (array) apply_filters( 'edss_course_post_types', $types );
	}

	public static function account_meta_key( $test = null ) {
		if ( null === $test ) {
			$test = EDSS_Settings::is_test_mode();
		}
		return $test ? self::USER_ACCT_TEST : self::USER_ACCT_LIVE;
	}

	public static function educator_account( $user_id ) {
		return trim( (string) get_user_meta( $user_id, self::account_meta_key(), true ) );
	}

	public static function course_ids_for_product( $product_id ) {
		$override = absint( get_post_meta( $product_id, self::POST_COURSE, true ) );
		$ids      = $override ? array( $override ) : self::detected_course_ids( $product_id );
		$ids      = (array) apply_filters( 'edss_product_course_ids', $ids, $product_id );
		return array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
	}

	/**
	 * Courses that an LMS's own WooCommerce integration has linked to this product. Each LMS stores the link
	 * differently; platforms not listed here are linked with the product's "Course" field instead.
	 */
	public static function detected_course_ids( $product_id ) {
		$ids = array();

		// LearnDash WooCommerce integration: product meta holds the course IDs.
		if ( post_type_exists( 'sfwd-courses' ) ) {
			$ids = array_merge( $ids, (array) get_post_meta( $product_id, '_related_course', true ) );
		}

		// Tutor LMS (course → product) and Sensei LMS paid courses (course → product): look the link up from the course side.
		$reverse = array(
			'courses' => '_tutor_course_product_id',
			'course'  => '_course_woocommerce_product',
		);
		foreach ( $reverse as $post_type => $meta_key ) {
			if ( ! post_type_exists( $post_type ) ) {
				continue;
			}
			$ids = array_merge(
				$ids,
				get_posts(
					array(
						'post_type'      => $post_type,
						'post_status'    => 'any',
						'fields'         => 'ids',
						'posts_per_page' => 20,
						'no_found_rows'  => true,
						'meta_key'       => $meta_key, // phpcs:ignore WordPress.DB.SlowDBQuery
						'meta_value'     => (string) $product_id, // phpcs:ignore WordPress.DB.SlowDBQuery
					)
				)
			);
		}

		return array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
	}

	public static function course_owner( $course_id ) {
		$owner = absint( get_post_meta( $course_id, self::POST_EDUCATOR, true ) );
		if ( ! $owner && 'yes' === EDSS_Settings::get( 'author_fallback' ) ) {
			$owner = (int) get_post_field( 'post_author', $course_id );
		}
		return (int) apply_filters( 'edss_course_owner', $owner, $course_id );
	}

	/**
	 * @return array status = ok | not_applicable | error.
	 */
	public static function resolve( $product_id ) {
		$out = array(
			'status'       => 'ok',
			'error'        => '',
			'product_id'   => (int) $product_id,
			'course_id'    => 0,
			'course_ids'   => array(),
			'educator_id'  => 0,
			'account_id'   => '',
			'split_type'   => '',
			'split_value'  => 0,
			'split_source' => '',
			'payees'       => array(),
		);

		if ( self::split_disabled( $product_id ) ) {
			$out['status'] = 'not_applicable';
			$out['error']  = 'Split is turned off for this product — the platform keeps 100%.';
			return $out;
		}

		$course_ids   = self::course_ids_for_product( $product_id );
		$edu_override = absint( get_post_meta( $product_id, self::POST_EDUCATOR, true ) );

		// Courses with split turned off don't take part (e.g. a bundle where only some courses pay an educator).
		if ( $course_ids && ! $edu_override ) {
			$paying = array_values( array_filter( $course_ids, function ( $cid ) { return ! self::split_disabled( $cid ); } ) );
			if ( ! $paying ) {
				$out['status'] = 'not_applicable';
				$out['error']  = 'Split is turned off for the linked course — the platform keeps 100%.';
				return $out;
			}
			$course_ids = $paying;
		}

		if ( ! $course_ids && ! $edu_override ) {
			$out['status'] = 'not_applicable';
			$out['error']  = 'Product is not linked to a course or an educator.';
			return $out;
		}

		$out['course_ids'] = $course_ids;
		$out['course_id']  = $course_ids ? (int) $course_ids[0] : 0;

		if ( $edu_override ) {
			$educator = $edu_override;
		} else {
			$owners = array();
			foreach ( $course_ids as $cid ) {
				$course = get_post( $cid );
				if ( ! $course ) {
					return self::fail( $out, sprintf( 'Linked course #%d does not exist.', $cid ) );
				}
				$owner = self::course_owner( $cid );
				if ( ! $owner ) {
					return self::fail( $out, sprintf( 'Course #%d "%s" has no educator owner.', $cid, $course->post_title ) );
				}
				$owners[ $owner ] = true;
			}
			if ( count( $owners ) > 1 ) {
				return self::fail( $out, 'Product is linked to courses owned by different educators. Set one educator on the product.' );
			}
			$educator = (int) key( $owners );
		}

		$out['educator_id'] = $educator;
		$user               = get_userdata( $educator );
		if ( ! $user ) {
			return self::fail( $out, sprintf( 'Educator user #%d does not exist.', $educator ) );
		}
		if ( 'no' === get_user_meta( $educator, self::USER_ACTIVE, true ) ) {
			return self::fail( $out, sprintf( 'Payouts are switched off for educator %s (#%d).', $user->display_name, $educator ) );
		}

		$acct = self::educator_account( $educator );
		if ( ! preg_match( self::ACCT_REGEX, $acct ) ) {
			return self::fail(
				$out,
				sprintf( 'Educator %s (#%d) has no valid %s-mode Stripe connected account ID (acct_…).', $user->display_name, $educator, EDSS_Settings::mode_label() )
			);
		}
		$out['account_id'] = $acct;

		$rule = self::split_rule( $product_id, 1 === count( $course_ids ) ? $course_ids[0] : 0, $educator );
		if ( is_wp_error( $rule ) ) {
			return self::fail( $out, $rule->get_error_message() );
		}
		$out = array_merge( $out, $rule );

		// Everyone paid for this line: the owning educator first, then any co-educators.
		$out['payees'] = array(
			array(
				'educator_id'  => $educator,
				'account_id'   => $acct,
				'split_type'   => $out['split_type'],
				'split_value'  => $out['split_value'],
				'split_source' => $out['split_source'],
			),
		);
		$co   = self::co_educators( $product_id, 1 === count( $course_ids ) ? $course_ids[0] : 0 );
		$seen = array();
		foreach ( $co['list'] as $entry ) {
			$uid = (int) $entry['user'];
			$u   = get_userdata( $uid );
			if ( ! $u ) {
				return self::fail( $out, sprintf( 'Co-educator user #%d does not exist.', $uid ) );
			}
			if ( $uid === $educator || isset( $seen[ $uid ] ) ) {
				return self::fail( $out, sprintf( '%s is listed twice as a payee for this product.', $u->display_name ) );
			}
			$seen[ $uid ] = true;
			if ( 'no' === get_user_meta( $uid, self::USER_ACTIVE, true ) ) {
				return self::fail( $out, sprintf( 'Payouts are switched off for co-educator %s (#%d).', $u->display_name, $uid ) );
			}
			$co_acct = self::educator_account( $uid );
			if ( ! preg_match( self::ACCT_REGEX, $co_acct ) ) {
				return self::fail( $out, sprintf( 'Co-educator %s (#%d) has no valid %s-mode Stripe connected account ID.', $u->display_name, $uid, EDSS_Settings::mode_label() ) );
			}
			if ( ! self::valid_split( $entry['type'], $entry['value'] ) || ! in_array( $entry['type'], array( 'percent', 'fixed' ), true ) ) {
				return self::fail( $out, sprintf( 'Invalid split for co-educator %s.', $u->display_name ) );
			}
			$out['payees'][] = array(
				'educator_id'  => $uid,
				'account_id'   => $co_acct,
				'split_type'   => $entry['type'],
				'split_value'  => (float) $entry['value'],
				'split_source' => 'co-educator/' . $co['source'], // Max 20 characters (ledger column).
			);
		}

		return apply_filters( 'edss_resolved_mapping', $out, $product_id );
	}

	/**
	 * Co-educators: the product's own list wins; otherwise the (single) linked course's list.
	 *
	 * @return array{list: array, source: string}
	 */
	public static function co_educators( $product_id, $course_id ) {
		$list = self::clean_co_list( get_post_meta( $product_id, self::POST_CO, true ) );
		if ( $list ) {
			return array(
				'list'   => $list,
				'source' => 'product',
			);
		}
		$list = $course_id ? self::clean_co_list( get_post_meta( $course_id, self::POST_CO, true ) ) : array();
		return array(
			'list'   => $list,
			'source' => 'course',
		);
	}

	public static function clean_co_list( $raw ) {
		$out = array();
		foreach ( (array) $raw as $entry ) {
			if ( is_array( $entry ) && ! empty( $entry['user'] ) ) {
				$out[] = array(
					'user'  => absint( $entry['user'] ),
					'type'  => (string) ( $entry['type'] ?? '' ),
					'value' => (string) ( $entry['value'] ?? '' ),
				);
			}
		}
		return $out;
	}

	/** Who may use the Educator Dashboard / connect Stripe: flagged by an admin, already has an account, or owns a course. */
	public static function is_educator( $user_id ) {
		if ( ! $user_id ) {
			return false;
		}
		if ( 'yes' === get_user_meta( $user_id, self::USER_IS_EDUCATOR, true ) || get_user_meta( $user_id, self::USER_ACCT_TEST, true ) || get_user_meta( $user_id, self::USER_ACCT_LIVE, true ) ) {
			return true;
		}
		$types = self::course_post_types();
		if ( ! $types ) {
			return false;
		}
		$owned = get_posts(
			array(
				'post_type'      => $types,
				'post_status'    => 'any',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_key'       => self::POST_EDUCATOR, // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'     => (string) $user_id, // phpcs:ignore WordPress.DB.SlowDBQuery
			)
		);
		if ( ! $owned && 'yes' === EDSS_Settings::get( 'author_fallback' ) ) {
			$owned = get_posts(
				array(
					'post_type'      => $types,
					'post_status'    => 'any',
					'posts_per_page' => 1,
					'fields'         => 'ids',
					'no_found_rows'  => true,
					'author'         => (int) $user_id,
				)
			);
		}
		return (bool) $owned;
	}

	public static function split_disabled( $post_id ) {
		return 'yes' === get_post_meta( $post_id, self::POST_NO_SPLIT, true );
	}

	private static function fail( $out, $message ) {
		$out['status'] = 'error';
		$out['error']  = $message;
		return $out;
	}

	/**
	 * First rule found wins: product → course → educator → global default.
	 *
	 * @return array|WP_Error
	 */
	public static function split_rule( $product_id, $course_id, $educator_id ) {
		$sources = array(
			'product' => array( get_post_meta( $product_id, self::POST_SPLIT_TYPE, true ), get_post_meta( $product_id, self::POST_SPLIT_VALUE, true ) ),
		);
		if ( $course_id ) {
			$sources['course'] = array( get_post_meta( $course_id, self::POST_SPLIT_TYPE, true ), get_post_meta( $course_id, self::POST_SPLIT_VALUE, true ) );
		}
		$sources['educator'] = array( get_user_meta( $educator_id, self::USER_SPLIT_TYPE, true ), get_user_meta( $educator_id, self::USER_SPLIT_VALUE, true ) );
		$sources['default']  = array( EDSS_Settings::get( 'default_split_type' ), EDSS_Settings::get( 'default_split_value' ) );

		foreach ( $sources as $source => $pair ) {
			list( $type, $value ) = $pair;
			if ( ! in_array( $type, array( 'percent', 'fixed' ), true ) || '' === trim( (string) $value ) ) {
				continue;
			}
			if ( ! self::valid_split( $type, $value ) ) {
				return new WP_Error( 'edss_bad_rule', sprintf( 'Invalid %s split rule on the %s (%s).', $type, $source, $value ) );
			}
			return array(
				'split_type'   => $type,
				'split_value'  => (float) $value,
				'split_source' => $source,
			);
		}
		return new WP_Error( 'edss_no_rule', 'No split rule set on the product, course, educator, or the global default.' );
	}

	public static function valid_split( $type, $value ) {
		if ( ! is_numeric( $value ) || (float) $value < 0 ) {
			return false;
		}
		return 'percent' !== $type || (float) $value <= 100;
	}

	public static function describe_rule( $type, $value, $currency = '' ) {
		if ( 'fixed' === $type ) {
			return sprintf( '%s %s fixed', number_format( (float) $value, 2 ), strtoupper( $currency ? $currency : get_woocommerce_currency() ) );
		}
		return rtrim( rtrim( number_format( (float) $value, 4 ), '0' ), '.' ) . '%';
	}
}
