<?php
/**
 * Admin screens: Ledger, Mapping overview, Settings,
 * plus the vendor profile fields and course / product / order meta boxes.
 */

defined( 'ABSPATH' ) || exit;

class EDSS_Admin {

	const CAP    = 'manage_woocommerce';
	/** Tags the dropdown helpers may output (wp_kses_post() strips form controls). */
	const SELECT_KSES = array(
		'select'   => array( 'name' => true ),
		'optgroup' => array( 'label' => true ),
		'option'   => array(
			'value'    => true,
			'selected' => true,
		),
	);

	const EVENTS = array( 'transferred', 'dry_run', 'held', 'failed', 'unmapped', 'skipped', 'reversed', 'reversal_failed' );

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notices' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );

		foreach ( array( 'retry', 'resend', 'process_order', 'test_connection', 'test_webhook', 'check_account', 'export' ) as $action ) {
			add_action( 'admin_post_edss_' . $action, array( __CLASS__, 'action_' . $action ) );
		}
		// edss-private-start
		add_action( 'admin_post_edss_check_update', array( __CLASS__, 'action_check_update' ) );
		// edss-private-end

		add_action( 'show_user_profile', array( __CLASS__, 'user_fields' ) );
		add_action( 'edit_user_profile', array( __CLASS__, 'user_fields' ) );
		add_action( 'personal_options_update', array( __CLASS__, 'save_user' ) );
		add_action( 'edit_user_profile_update', array( __CLASS__, 'save_user' ) );
		add_action( 'user_profile_update_errors', array( __CLASS__, 'validate_user' ), 10, 3 );

		add_action( 'add_meta_boxes', array( __CLASS__, 'meta_boxes' ) );
		add_action( 'save_post', array( __CLASS__, 'save_post' ), 10, 2 );
	}

	/* =========================================================
	 * Menu + shared bits
	 * ========================================================= */

	public static function menu() {
		add_menu_page( 'Vendor Splits', 'Vendor Splits', self::CAP, 'edss-overview', array( __CLASS__, 'page_overview' ), 'dashicons-money-alt', 56 );
		add_submenu_page( 'edss-overview', 'Overview', 'Overview', self::CAP, 'edss-overview', array( __CLASS__, 'page_overview' ) );
		add_submenu_page( 'edss-overview', 'Payouts', 'Payouts', self::CAP, 'edss', array( __CLASS__, 'page_ledger' ) );
		add_submenu_page( 'edss-overview', 'Course Mapping', 'Course Mapping', self::CAP, 'edss-mapping', array( __CLASS__, 'page_mapping' ) );
		add_submenu_page( 'edss-overview', 'Settings', 'Settings', self::CAP, 'edss-settings', array( __CLASS__, 'page_settings' ) );
	}

	/** Loads the admin CSS/JS only on this plugin's screens and on the editors that show its boxes. */
	public static function enqueue( $hook ) {
		$screen = get_current_screen();
		$id     = $screen ? (string) $screen->id : '';
		$ours   = false !== strpos( (string) $hook, 'edss' )
			|| false !== strpos( $id, 'edss' )
			|| in_array( $hook, array( 'post.php', 'post-new.php', 'profile.php', 'user-edit.php' ), true )
			|| in_array( $id, array( 'shop_order', 'woocommerce_page_wc-orders' ), true );
		if ( ! $ours ) {
			return;
		}
		wp_enqueue_style( 'edss-admin', plugins_url( 'assets/admin.css', EDSS_FILE ), array(), EDSS_VERSION );
		wp_enqueue_script( 'edss-admin', plugins_url( 'assets/admin.js', EDSS_FILE ), array(), EDSS_VERSION, true );
	}

	private static function guard( $nonce_action ) {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( $nonce_action );
	}

	private static function back( $type, $message, $url = '' ) {
		set_transient( 'edss_notice_' . get_current_user_id(), array( $type, $message ), 60 );
		$target = $url ? $url : wp_get_referer();
		wp_safe_redirect( $target ? $target : admin_url( 'admin.php?page=edss' ) );
		exit;
	}

	private static function action_url( $action, $args = array() ) {
		$nonce = 'edss_' . $action . ( isset( $args['id'] ) ? '_' . $args['id'] : '' );
		return wp_nonce_url( add_query_arg( array_merge( array( 'action' => 'edss_' . $action ), $args ), admin_url( 'admin-post.php' ) ), $nonce );
	}

	public static function notices() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		$notice = get_transient( 'edss_notice_' . get_current_user_id() );
		if ( $notice ) {
			delete_transient( 'edss_notice_' . get_current_user_id() );
			printf( '<div class="notice notice-%s is-dismissible"><p>%s</p></div>', esc_attr( $notice[0] ), wp_kses_post( $notice[1] ) );
		}

		$mode   = EDSS_Settings::get( 'run_mode' );
		$screen = get_current_screen();
		$ours   = $screen && ( false !== strpos( $screen->id, 'edss' ) || in_array( $screen->id, array( 'shop_order', 'woocommerce_page_wc-orders' ), true ) );

		if ( 'live' === $mode && '' === EDSS_Settings::secret_key() ) {
			echo '<div class="notice notice-error"><p><strong>Vendor Splits:</strong> live transfers are ON but no Stripe secret key was found. Vendor payouts will fail until this is fixed in Vendor Splits → Settings.</p></div>';
		} elseif ( $ours && 'dry_run' === $mode ) {
			echo '<div class="notice notice-info"><p><strong>Vendor Splits is in DRY RUN:</strong> splits are calculated and logged, but no Stripe transfers are sent.</p></div>';
		} elseif ( $ours && 'off' === $mode ) {
			echo '<div class="notice notice-warning"><p><strong>Vendor Splits is OFF:</strong> paid orders are not being processed.</p></div>';
		}
	}

	public static function row_actions_html( $row ) {
		$links = array();
		$same_mode = (int) $row['test_mode'] === ( EDSS_Settings::is_test_mode() ? 1 : 0 );
		$live      = 'live' === EDSS_Settings::get( 'run_mode' );

		if ( $same_mode && in_array( $row['status'], array( 'failed', 'held', 'unmapped', 'skipped' ), true ) ) {
			$links[] = sprintf( '<a class="button button-small" href="%s">Retry</a>', esc_url( self::action_url( 'retry', array( 'id' => $row['id'] ) ) ) );
		}
		if ( $same_mode && $live && 'dry_run' === $row['status'] ) {
			$links[] = sprintf(
				'<a class="button button-small" href="%s" data-edss-confirm="%s">Send now</a>',
				esc_url( self::action_url( 'retry', array( 'id' => $row['id'] ) ) ),
				esc_attr( sprintf( 'Send a REAL Stripe transfer of %s to %s?', EDSS_Stripe::format( $row['educator_minor'], $row['currency'] ), $row['account_id'] ) )
			);
		}
		if ( EDSS_Settings::get( 'webhook_url' ) ) {
			$links[] = sprintf( '<a class="button button-small" href="%s">Resend webhook</a>', esc_url( self::action_url( 'resend', array( 'id' => $row['id'] ) ) ) );
		}
		return implode( ' ', $links );
	}

	/* =========================================================
	 * Plain-language status names (used everywhere in the admin)
	 * ========================================================= */

	const STATUS_LABELS = array(
		'transferred'        => array( 'Paid', 'Sent to the vendor\'s Stripe account.' ),
		'dry_run'            => array( 'Test only', 'Calculated in Dry run mode. No money was sent.' ),
		'held'               => array( 'On hold', 'The vendor\'s Stripe account cannot receive money yet. Retried every hour automatically.' ),
		'failed'             => array( 'Failed – retrying', 'Stripe refused the transfer. It is retried automatically; the reason is shown under the status.' ),
		'unmapped'           => array( 'Needs setup', 'Course, vendor, Stripe account ID or split rule is missing. Nothing was sent. Fix it, then click Retry.' ),
		'pending'            => array( 'Processing', 'Queued — it will be handled in a moment.' ),
		'processing'         => array( 'Processing', 'Being sent right now.' ),
		'partially_reversed' => array( 'Partly refunded', 'The customer got a partial refund and that part of the vendor\'s share was taken back.' ),
		'reversed'           => array( 'Refunded', 'The customer was refunded and the vendor\'s share was taken back.' ),
		'skipped'            => array( 'Not paid out', 'Nothing was owed: the share was zero, the split is turned off, or the order is no longer paid.' ),
	);

	public static function status_label( $status ) {
		return isset( self::STATUS_LABELS[ $status ] ) ? self::STATUS_LABELS[ $status ][0] : ucwords( str_replace( '_', ' ', $status ) );
	}

	public static function status_badge( $status ) {
		$help = isset( self::STATUS_LABELS[ $status ] ) ? self::STATUS_LABELS[ $status ][1] : '';
		return '<span class="edss-status edss-' . esc_attr( $status ) . '" title="' . esc_attr( $help ) . '">' . esc_html( self::status_label( $status ) ) . '</span>';
	}

	public static function status_legend() {
		echo '<details class="edss-legend"><summary>What do the statuses mean?</summary><table>';
		foreach ( array( 'transferred', 'dry_run', 'held', 'failed', 'unmapped', 'reversed', 'skipped' ) as $s ) {
			echo '<tr><td>' . wp_kses_post( self::status_badge( $s ) ) . '</td><td>' . esc_html( self::STATUS_LABELS[ $s ][1] ) . '</td></tr>';
		}
		echo '</table></details>';
	}

	/* =========================================================
	 * Overview page: setup checklist + key numbers + what needs attention
	 * ========================================================= */

	public static function page_overview() {
		$test     = EDSS_Settings::is_test_mode();
		$mode     = EDSS_Settings::get( 'run_mode' );
		$conn     = get_option( 'edss_last_connection' );
		$types    = EDSS_Resolver::course_post_types();
		$settings = admin_url( 'admin.php?page=edss-settings' );

		$educators = get_users(
			array(
				'meta_key'     => EDSS_Resolver::account_meta_key(), // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_compare' => 'EXISTS',
				'fields'       => 'ID',
				'number'       => 1000,
			)
		);
		$ready    = 0;
		$problems = 0;
		foreach ( wc_get_products( array( 'limit' => 300, 'status' => array( 'publish', 'private' ), 'return' => 'ids' ) ) as $pid ) {
			$m = EDSS_Resolver::resolve( $pid );
			if ( 'ok' === $m['status'] ) {
				++$ready;
			} elseif ( 'error' === $m['status'] ) {
				++$problems;
			}
		}
		$counts    = EDSS_Ledger::status_counts( $test );
		$month     = EDSS_Ledger::month_paid( $test );
		$attention = EDSS_Ledger::attention_rows( $test, 10 );
		$dash_pages = get_posts(
			array(
				'post_type'      => 'any',
				'post_status'    => 'publish',
				's'              => '_dashboard]', // Matches [edss_vendor_dashboard] and the older [edss_educator_dashboard].
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		$dash_page  = $dash_pages ? (int) $dash_pages[0] : 0;

		$connected = is_array( $conn ) && ! empty( $conn['ok'] ) && ( $conn['mode'] ?? '' ) === EDSS_Settings::mode_label() && '' !== EDSS_Settings::secret_key();
		$type_names = array();
		foreach ( $types as $t ) {
			$type_names[] = EDSS_Resolver::KNOWN_COURSE_TYPES[ $t ] ?? $t;
		}

		// Each step: state (done|todo|warn|optional), title, explanation, link, link label.
		$steps = array(
			array(
				$connected ? 'done' : 'todo',
				'Connect your Stripe account',
				$connected ? sprintf( 'Connected to %s (%s mode).', $conn['acct'], $conn['mode'] ) : 'Add the secret key of the Stripe account that receives your course payments, save, then click "Test Stripe connection".',
				$settings . '#start',
				$connected ? 'Check again' : 'Connect Stripe',
			),
			array(
				$types ? 'done' : 'todo',
				'Choose your course platform',
				$types ? 'Courses from: ' . implode( ', ', array_unique( $type_names ) ) . '.' : 'Tell the plugin which post type holds your courses (LearnDash, Tutor LMS, LearnPress…).',
				$settings . '#courses',
				'Course settings',
			),
			array(
				$educators ? 'done' : 'todo',
				'Give each vendor a Stripe account',
				$educators ? sprintf( '%d vendor(s) have a %s-mode Stripe account.', count( $educators ), EDSS_Settings::mode_label() ) : 'Paste each vendor\'s acct_… ID on their user profile, or let them click "Connect Stripe" on the Vendor Dashboard page.',
				admin_url( 'users.php' ),
				'Users',
			),
			array(
				$problems ? 'warn' : ( $ready ? 'done' : 'todo' ),
				'Link course products to vendors',
				sprintf( '%d product(s) ready to split%s.', $ready, $problems ? sprintf( ', %d need attention', $problems ) : '' ),
				admin_url( 'admin.php?page=edss-mapping' ),
				'Open Course Mapping',
			),
			array(
				( ! empty( $counts['dry_run'] ) || ! empty( $counts['transferred'] ) ) ? 'done' : 'todo',
				'Test with a purchase',
				'Buy a course with a Stripe test card while Run mode is "Dry run" and check the amounts in Payouts.',
				admin_url( 'admin.php?page=edss' ),
				'Open Payouts',
			),
			array(
				'live' === $mode ? 'done' : 'todo',
				'Turn on live transfers',
				'live' === $mode ? ( $test ? 'Live transfers are ON — but Stripe is in test mode, so this is still test money.' : 'Live transfers are ON — vendors are being paid.' ) : 'When your tests look right, switch Run mode to "Live transfers".',
				$settings . '#start',
				'Run mode',
			),
			array(
				$dash_page ? 'done' : 'optional',
				'Vendor dashboard page (recommended)',
				$dash_page ? 'Vendors can see their earnings here: ' . get_permalink( $dash_page ) : 'Create a page containing [edss_vendor_dashboard] so vendors can see their earnings and connect Stripe themselves.',
				$dash_page ? get_permalink( $dash_page ) : admin_url( 'post-new.php?post_type=page' ),
				$dash_page ? 'View page' : 'Create page',
			),
			array(
				EDSS_Settings::get( 'webhook_url' ) ? 'done' : 'optional',
				'Send results to your CRM (optional)',
				'Pabbly, Zapier, Make, n8n or GoHighLevel receive every payout automatically.',
				$settings . '#webhook',
				'Webhook settings',
			),
		);
		$done_count = count(
			array_filter(
				array_slice( $steps, 0, 6 ),
				function ( $s ) {
					return 'done' === $s[0];
				}
			)
		);

		$waiting   = (int) ( $counts['held'] ?? 0 ) + (int) ( $counts['pending'] ?? 0 ) + (int) ( $counts['processing'] ?? 0 );
		$attn_n    = (int) ( $counts['unmapped'] ?? 0 ) + (int) ( $counts['failed'] ?? 0 );
		$paid_text = array();
		foreach ( $month as $c => $minor ) {
			$paid_text[] = EDSS_Stripe::format( $minor, $c );
		}
		$icons = array(
			'done'     => '✓',
			'todo'     => '•',
			'warn'     => '!',
			'optional' => '○',
		);
		?>
		<div class="wrap edss-wrap">
			<h1>Vendor Splits</h1>
			<p class="edss-lead">Pays each vendor their share of every course sale and renewal, straight to their Stripe account.</p>
			<?php if ( ! defined( 'EDSS_PRIVATE_BUILD' ) ) : ?>
				<p class="edss-help">A Pro version with extra features is coming soon. Everything in this free version stays free.</p>
			<?php endif; ?>

			<div class="edss-badges">
				<span class="edss-badge <?php echo $test ? 'edss-b-test' : 'edss-b-live'; ?>">Stripe: <?php echo $test ? 'Test mode' : 'Live mode'; ?></span>
				<span class="edss-badge edss-b-<?php echo esc_attr( $mode ); ?>">
					<?php echo esc_html( array( 'off' => 'Plugin: Off', 'dry_run' => 'Plugin: Dry run (no money sent)', 'live' => 'Plugin: Live transfers' )[ $mode ] ?? $mode ); ?>
				</span>
			</div>

			<div class="edss-cards">
				<div class="edss-card"><span>Paid to vendors this month</span><b><?php echo esc_html( $paid_text ? implode( ' + ', $paid_text ) : '0' ); ?></b></div>
				<div class="edss-card"><span>Waiting (on hold / processing)</span><b><?php echo (int) $waiting; ?></b></div>
				<div class="edss-card <?php echo $attn_n ? 'edss-card-bad' : ''; ?>"><span>Needs your attention</span><b><?php echo (int) $attn_n; ?></b></div>
			</div>

			<div class="edss-panel">
				<h2>Setup checklist <small><?php echo (int) $done_count; ?> of 6 done</small></h2>
				<ol class="edss-steps">
					<?php foreach ( $steps as $step ) : ?>
						<li class="edss-step edss-step-<?php echo esc_attr( $step[0] ); ?>">
							<span class="edss-step-icon"><?php echo esc_html( $icons[ $step[0] ] ); ?></span>
							<div class="edss-step-body"><strong><?php echo esc_html( $step[1] ); ?></strong><p><?php echo esc_html( $step[2] ); ?></p></div>
							<a class="button <?php echo in_array( $step[0], array( 'todo', 'warn' ), true ) ? 'button-primary' : ''; ?>" href="<?php echo esc_url( $step[3] ); ?>"><?php echo esc_html( $step[4] ); ?></a>
						</li>
					<?php endforeach; ?>
				</ol>
			</div>

			<div class="edss-panel">
				<h2>Needs attention</h2>
				<?php if ( ! $attention ) : ?>
					<p class="edss-ok">Nothing to fix — all payouts are fine.</p>
				<?php else : ?>
					<table class="widefat striped">
						<thead><tr><th>Order</th><th>Course / product</th><th>Status</th><th>What's wrong</th><th></th></tr></thead>
						<tbody>
						<?php
						foreach ( $attention as $r ) :
							$o = wc_get_order( $r['order_id'] );
							?>
							<tr>
								<td><?php echo $o ? '<a href="' . esc_url( $o->get_edit_order_url() ) . '">#' . esc_html( $o->get_order_number() ) . '</a>' : '#' . (int) $r['order_id']; ?></td>
								<td><?php echo esc_html( get_the_title( $r['course_id'] ? $r['course_id'] : $r['product_id'] ) ); ?></td>
								<td><?php echo wp_kses_post( self::status_badge( $r['status'] ) ); ?></td>
								<td><?php echo esc_html( $r['last_error'] ); ?></td>
								<td><?php echo wp_kses_post( self::row_actions_html( $r ) ); ?></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
					<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=edss' ) ); ?>">See all payouts →</a></p>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	/* =========================================================
	 * Ledger page
	 * ========================================================= */

	public static function page_ledger() {
		$table = new EDSS_Ledger_Table();
		$table->prepare_items();
		$export = self::action_url( 'export', isset( $_GET['status'] ) ? array( 'status' => sanitize_key( $_GET['status'] ) ) : array() ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only list filter.
		?>
		<div class="wrap">
			<h1 class="wp-heading-inline">Payouts</h1>
			<a class="page-title-action" href="<?php echo esc_url( $export ); ?>">Export CSV</a>
			<p class="edss-lead">Every vendor payout — first payments and every renewal. One row per vendor per sale.</p>
			<?php self::status_legend(); ?>
			<form method="get">
				<input type="hidden" name="page" value="edss">
				<p class="search-box">
					<input type="number" name="order_id" placeholder="Order ID" value="<?php echo isset( $_GET['order_id'] ) ? (int) $_GET['order_id'] : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only list filter. ?>">
					<button class="button">Filter</button>
				</p>
			</form>
			<?php
			$table->views();
			$table->display();
			self::recent_orders_panel();
			?>
		</div>
		<?php
	}

	/* =========================================================
	 * Mapping page (what WILL happen for each product)
	 * ========================================================= */

	public static function page_mapping() {
		$product_ids = wc_get_products(
			array(
				'limit'  => 1000,
				'status' => array( 'publish', 'private', 'draft' ),
				'return' => 'ids',
			)
		);
		$mapped      = array();
		$unlinked    = array();
		$educators   = array();
		foreach ( $product_ids as $pid ) {
			$map = EDSS_Resolver::resolve( $pid );
			if ( 'not_applicable' === $map['status'] ) {
				$unlinked[ $pid ] = $map['error'];
				continue;
			}
			$mapped[] = $map;
			if ( $map['educator_id'] ) {
				$educators[ $map['educator_id'] ] = true;
			}
		}
		foreach ( self::educator_users() as $u ) {
			$educators[ (int) $u->ID ] = true;
		}
		$mode = EDSS_Settings::mode_label();
		?>
		<div class="wrap">
			<h1>Course Mapping</h1>
			<p class="edss-lead">Who gets paid for each product, and how much. Green = ready. Red = fix it before selling, or nothing is paid.</p>
			<?php
			$ok_n  = count( array_filter( $mapped, function ( $m ) { return 'ok' === $m['status']; } ) );
			$bad_n = count( $mapped ) - $ok_n;
			?>
			<div class="edss-cards">
				<div class="edss-card"><span>Ready to split</span><b><?php echo (int) $ok_n; ?></b></div>
				<div class="edss-card <?php echo $bad_n ? 'edss-card-bad' : ''; ?>"><span>Need attention</span><b><?php echo (int) $bad_n; ?></b></div>
				<div class="edss-card"><span>Not split (no course, or split turned off)</span><b><?php echo count( $unlinked ); ?></b></div>
			</div>
			<p class="edss-help">Built with exactly the same lookup the payment processor uses, so a green row here will pay out the same way. Stripe mode: <strong><?php echo esc_html( $mode ); ?></strong> (connected account IDs shown are the <?php echo esc_html( $mode ); ?>-mode ones).</p>

			<h2>Course products</h2>
			<table class="widefat striped">
				<thead><tr><th>Product</th><th>Course</th><th>Vendor</th><th>Stripe account</th><th>Split rule</th><th>At current price</th><th>Status</th></tr></thead>
				<tbody>
				<?php if ( ! $mapped ) : ?>
					<tr><td colspan="7">No products are linked to a course or a vendor yet.</td></tr>
				<?php endif; ?>
				<?php
				foreach ( $mapped as $m ) :
					$product = wc_get_product( $m['product_id'] );
					$user    = $m['educator_id'] ? get_userdata( $m['educator_id'] ) : null;
					$preview = '—';
					if ( 'ok' === $m['status'] && $product ) {
						$currency = get_woocommerce_currency();
						$price    = EDSS_Stripe::to_minor( (float) $product->get_price(), $currency );
						$parts    = array();
						foreach ( $m['payees'] as $p ) {
							$share   = 'fixed' === $p['split_type'] ? EDSS_Stripe::to_minor( $p['split_value'], $currency ) : (int) round( $price * $p['split_value'] / 100 );
							$parts[] = EDSS_Stripe::format( 1 === count( $m['payees'] ) ? min( $share, $price ) : $share, $currency );
						}
						$preview = EDSS_Stripe::format( $price, $currency ) . ' → ' . implode( ' + ', $parts );
					}
					?>
					<tr>
						<td><a href="<?php echo esc_url( get_edit_post_link( $m['product_id'] ) ); ?>"><?php echo esc_html( get_the_title( $m['product_id'] ) ); ?></a> <small>#<?php echo (int) $m['product_id']; ?></small></td>
						<td>
							<?php
							foreach ( $m['course_ids'] as $cid ) {
								printf( '<a href="%s">%s</a> <small>#%d</small><br>', esc_url( get_edit_post_link( $cid ) ), esc_html( get_the_title( $cid ) ), (int) $cid );
							}
							echo $m['course_ids'] ? '' : '<small>vendor set on product</small>';
							?>
						</td>
						<?php if ( count( $m['payees'] ) > 1 ) : ?>
							<td colspan="3">
								<?php
								foreach ( $m['payees'] as $p ) {
									$pu = get_userdata( $p['educator_id'] );
									printf(
										'%s <small>#%d</small> · <code>%s</code> · %s <small>(%s)</small><br>',
										esc_html( $pu ? $pu->display_name : '?' ),
										(int) $p['educator_id'],
										esc_html( $p['account_id'] ),
										esc_html( EDSS_Resolver::describe_rule( $p['split_type'], $p['split_value'] ) ),
										esc_html( EDSS_Resolver::source_label( $p['split_source'] ) )
									);
								}
								?>
							</td>
						<?php else : ?>
							<td><?php echo $user ? '<a href="' . esc_url( get_edit_user_link( $user->ID ) ) . '">' . esc_html( $user->display_name ) . '</a> <small>#' . (int) $user->ID . '</small>' : '—'; ?></td>
							<td><code><?php echo esc_html( $m['account_id'] ? $m['account_id'] : '—' ); ?></code></td>
							<td><?php echo $m['split_type'] ? esc_html( EDSS_Resolver::describe_rule( $m['split_type'], $m['split_value'] ) . ' (' . EDSS_Resolver::source_label( $m['split_source'] ) . ')' ) : '—'; ?></td>
						<?php endif; ?>
						<td><?php echo esc_html( $preview ); ?></td>
						<td><?php echo 'ok' === $m['status'] ? '<span class="edss-ok">✓ Ready</span>' : '<span class="edss-bad">' . esc_html( $m['error'] ) . '</span><br><a href="' . esc_url( get_edit_post_link( $m['product_id'] ) ) . '">Fix on product →</a>'; ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<h2>Vendors</h2>
			<table class="widefat striped">
				<thead><tr><th>Vendor</th><th>Test acct</th><th>Live acct</th><th>Payouts</th><th>Default rule</th><th>Stripe status (<?php echo esc_html( $mode ); ?>)</th><th></th></tr></thead>
				<tbody>
				<?php if ( ! $educators ) : ?>
					<tr><td colspan="7">No vendors yet. Add a Stripe connected account ID on a user's profile.</td></tr>
				<?php endif; ?>
				<?php
				foreach ( array_keys( $educators ) as $uid ) :
					$u = get_userdata( $uid );
					if ( ! $u ) {
						continue;
					}
					$type = get_user_meta( $uid, EDSS_Resolver::USER_SPLIT_TYPE, true );
					?>
					<tr>
						<td><a href="<?php echo esc_url( get_edit_user_link( $uid ) ); ?>"><?php echo esc_html( $u->display_name ); ?></a> <small>#<?php echo (int) $uid; ?></small></td>
						<td><code><?php echo esc_html( get_user_meta( $uid, EDSS_Resolver::USER_ACCT_TEST, true ) ); ?></code></td>
						<td><code><?php echo esc_html( get_user_meta( $uid, EDSS_Resolver::USER_ACCT_LIVE, true ) ); ?></code></td>
						<td><?php echo 'no' === get_user_meta( $uid, EDSS_Resolver::USER_ACTIVE, true ) ? '<span class="edss-bad">Off</span>' : 'On'; ?></td>
						<td><?php echo $type ? esc_html( EDSS_Resolver::describe_rule( $type, get_user_meta( $uid, EDSS_Resolver::USER_SPLIT_VALUE, true ) ) ) : '<small>inherit</small>'; ?></td>
						<td><?php echo wp_kses_post( self::account_status_html( $uid ) ); ?></td>
						<td><?php if ( EDSS_Resolver::educator_account( $uid ) ) : ?><a class="button button-small" href="<?php echo esc_url( self::action_url( 'check_account', array( 'id' => $uid ) ) ); ?>">Check Stripe</a><?php endif; ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<?php if ( $unlinked ) : ?>
				<details style="margin-top:20px">
					<summary><?php echo count( $unlinked ); ?> products are not split (split turned off, or not linked to a course/vendor)</summary>
					<ul>
					<?php foreach ( $unlinked as $pid => $why ) : ?>
						<li><a href="<?php echo esc_url( get_edit_post_link( $pid ) ); ?>"><?php echo esc_html( get_the_title( $pid ) ); ?></a> #<?php echo (int) $pid; ?> — <small><?php echo esc_html( $why ); ?></small></li>
					<?php endforeach; ?>
					</ul>
				</details>
			<?php endif; ?>
		</div>
		<?php
	}

	private static function account_status_html( $user_id ) {
		$status = get_user_meta( $user_id, 'edss_status_' . EDSS_Settings::mode_label(), true );
		if ( ! is_array( $status ) ) {
			return '<small>not checked</small>';
		}
		$ok  = 'active' === $status['transfers'];
		$out = sprintf( '<span class="%s">transfers: %s</span>', $ok ? 'edss-ok' : 'edss-bad', esc_html( $status['transfers'] ) );
		$out .= '<br><small>payouts ' . ( $status['payouts_enabled'] ? 'enabled' : 'disabled' );
		if ( $status['disabled_reason'] ) {
			$out .= ', ' . esc_html( $status['disabled_reason'] );
		}
		if ( $status['currently_due'] ) {
			$out .= ', ' . (int) $status['currently_due'] . ' requirements due';
		}
		return $out . ' · checked ' . esc_html( human_time_diff( $status['checked_at'] ) ) . ' ago</small>';
	}

	/* =========================================================
	 * Settings page
	 * ========================================================= */

	public static function register_settings() {
		register_setting(
			'edss',
			EDSS_Settings::OPTION,
			array( 'sanitize_callback' => array( __CLASS__, 'sanitize_settings' ) )
		);
	}

	public static function sanitize_settings( $in ) {
		$in  = is_array( $in ) ? $in : array(); // options.php has already unslashed.
		$old = EDSS_Settings::all();
		$out = array();

		$pick = function ( $key, $allowed ) use ( $in, $old ) {
			return ( isset( $in[ $key ] ) && in_array( $in[ $key ], $allowed, true ) ) ? $in[ $key ] : $old[ $key ];
		};

		$out['run_mode']           = $pick( 'run_mode', array( 'off', 'dry_run', 'live' ) );
		$out['key_source']         = $pick( 'key_source', array( 'woo', 'own' ) );
		$out['own_mode']           = $pick( 'own_mode', array( 'test', 'live' ) );
		$out['default_split_type'] = $pick( 'default_split_type', array( 'percent', 'fixed' ) );
		$out['split_base']         = $pick( 'split_base', array( 'excl_tax', 'incl_tax' ) );
		$out['refund_policy']      = $pick( 'refund_policy', array( 'proportional', 'none' ) );

		foreach ( array( 'own_test_secret_key', 'own_live_secret_key' ) as $k ) {
			$v         = trim( sanitize_text_field( $in[ $k ] ?? '' ) );
			$out[ $k ] = '' === $v ? $old[ $k ] : $v; // Blank field = keep the saved key.
			if ( ! empty( $in[ $k . '_clear' ] ) ) {
				$out[ $k ] = '';
			}
		}

		$value = trim( (string) ( $in['default_split_value'] ?? '' ) );
		if ( '' === $value || EDSS_Resolver::valid_split( $out['default_split_type'], $value ) ) {
			$out['default_split_value'] = $value;
		} else {
			$out['default_split_value'] = $old['default_split_value'];
			add_settings_error( 'edss', 'split', 'Default split value was invalid (percent must be 0–100, fixed must be ≥ 0). Kept the previous value.' );
		}

		$types                    = array_map( 'sanitize_key', (array) ( $in['course_post_types'] ?? array() ) );
		$out['course_post_types'] = array_values( array_filter( $types, 'post_type_exists' ) );

		$country                = strtoupper( trim( (string) ( $in['account_country'] ?? '' ) ) );
		$out['account_country'] = preg_match( '/^[A-Z]{2}$/', $country ) ? $country : '';

		foreach ( array( 'author_fallback', 'require_active_account', 'use_source_transaction', 'onboarding' ) as $k ) {
			$out[ $k ] = ( empty( $in[ $k ] ) || 'no' === $in[ $k ] ) ? 'no' : 'yes';
		}
		$out['max_attempts']   = max( 1, min( 50, absint( $in['max_attempts'] ?? 10 ) ) );
		$out['webhook_url']    = esc_url_raw( trim( (string) ( $in['webhook_url'] ?? '' ) ) );
		$out['webhook_secret'] = sanitize_text_field( $in['webhook_secret'] ?? '' );
		$out['webhook_events'] = array_values( array_intersect( (array) ( $in['webhook_events'] ?? array() ), self::EVENTS ) );
		$out['alert_email']    = sanitize_email( $in['alert_email'] ?? '' );

		if ( $out['key_source'] !== $old['key_source'] || $out['own_mode'] !== $old['own_mode'] || $out['own_test_secret_key'] !== $old['own_test_secret_key'] || $out['own_live_secret_key'] !== $old['own_live_secret_key'] ) {
			delete_option( 'edss_last_connection' );
		}

		if ( 'live' === $out['run_mode'] && 'live' !== $old['run_mode'] ) {
			add_settings_error( 'edss', 'live', 'LIVE transfers are now ON: every new paid course order and renewal will send real Stripe transfers.', 'warning' );
		}
		return $out;
	}

	public static function page_settings() {
		$s     = EDSS_Settings::all();
		$woo   = EDSS_Settings::woo_stripe_settings();
		$name  = EDSS_Settings::OPTION;
		$field = function ( $key ) use ( $name ) {
			return $name . '[' . $key . ']';
		};
		?>
		<div class="wrap">
			<h1>Settings</h1>
			<?php settings_errors(); ?>
			<nav class="nav-tab-wrapper edss-tabs">
				<?php
				foreach ( array(
					'start'     => 'Start',
					'courses'   => 'Courses & splits',
					'educators' => 'Vendors',
					'safety'    => 'Safety',
					'webhook'   => 'Webhook',
					// edss-private-start
					'updates'   => 'Updates',
					// edss-private-end
				) as $tab => $label ) {
					printf( '<a href="#%1$s" class="nav-tab" data-tab="%1$s">%2$s</a>', esc_attr( $tab ), esc_html( $label ) );
				}
				?>
			</nav>
			<form method="post" action="options.php">
				<?php settings_fields( 'edss' ); ?>

				<div class="edss-tab" data-tab="start">
				<h2>Run mode</h2>
				<p class="edss-help">Start with <strong>Dry run</strong>, make a test purchase, check the numbers in Payouts, then switch to <strong>Live transfers</strong>.</p>
				<div class="edss-modes">
					<?php
					foreach ( array(
						'off'     => array( 'Off', 'Payments are ignored. Nothing is calculated or sent.' ),
						'dry_run' => array( 'Dry run', 'Shares are calculated and shown in Payouts, but no money is sent. Best for testing.' ),
						'live'    => array( 'Live transfers', 'Each vendor\'s share is sent to their Stripe account automatically.' ),
					) as $v => $info ) {
						printf(
							'<label class="edss-mode"><input type="radio" name="%s" value="%s" %s> <b>%s</b><small>%s</small></label>',
							esc_attr( $field( 'run_mode' ) ),
							esc_attr( $v ),
							checked( $s['run_mode'], $v, false ),
							esc_html( $info[0] ),
							esc_html( $info[1] )
						);
					}
					?>
				</div>

				<h2>Stripe platform keys</h2>
				<p class="edss-help">Transfers must be created with the <strong>same platform Stripe account</strong> that takes the WooCommerce payments and owns the vendors' connected accounts. The secret key never leaves the server.</p>
				<table class="form-table">
					<tr><th>Key source</th><td>
						<label><input type="radio" name="<?php echo esc_attr( $field( 'key_source' ) ); ?>" value="woo" <?php checked( $s['key_source'], 'woo' ); ?>> Use the WooCommerce Stripe gateway keys (mode follows the gateway's test-mode switch)</label><br>
						<span class="edss-help">Detected: test <?php echo esc_html( EDSS_Settings::mask( $woo['test_secret_key'] ?? '' ) ); ?> · live <?php echo esc_html( EDSS_Settings::mask( $woo['secret_key'] ?? '' ) ); ?> · gateway test mode: <?php echo esc_html( ( $woo['testmode'] ?? '' ) === 'yes' ? 'ON' : 'off' ); ?></span><br>
						<label><input type="radio" name="<?php echo esc_attr( $field( 'key_source' ) ); ?>" value="own" <?php checked( $s['key_source'], 'own' ); ?>> Use the keys below</label>
					</td></tr>
					<tr><th>Own keys mode</th><td>
						<select name="<?php echo esc_attr( $field( 'own_mode' ) ); ?>">
							<option value="test" <?php selected( $s['own_mode'], 'test' ); ?>>Test</option>
							<option value="live" <?php selected( $s['own_mode'], 'live' ); ?>>Live</option>
						</select>
					</td></tr>
					<?php foreach ( array( 'own_test_secret_key' => 'Test secret key', 'own_live_secret_key' => 'Live secret key' ) as $k => $label ) : ?>
					<tr><th><?php echo esc_html( $label ); ?></th><td>
						<input type="password" autocomplete="new-password" class="regular-text edss-key-input" name="<?php echo esc_attr( $field( $k ) ); ?>" placeholder="Paste sk_test_… / sk_live_… then click Save settings">
						<label><input type="checkbox" name="<?php echo esc_attr( $field( $k . '_clear' ) ); ?>" value="1"> clear</label>
						<p><?php echo '' !== $s[ $k ] ? '<span class="edss-ok">✓ Saved: ' . esc_html( EDSS_Settings::mask( $s[ $k ] ) ) . '</span>' : ( 'own_live_secret_key' === $k ? '<span class="edss-help">Not set — only needed when you go live.</span>' : '<span class="edss-bad">✗ No key saved</span>' ); ?></p>
						<p class="edss-help">Leave blank to keep the saved key. A restricted key (rk_…) works if it has write access to Transfers and read access to Accounts, PaymentIntents and Balance.</p>
					</td></tr>
					<?php endforeach; ?>
					<tr><th>Active now</th><td>
						<strong><?php echo esc_html( EDSS_Settings::mode_label() ); ?></strong> mode, key <?php echo esc_html( EDSS_Settings::mask( EDSS_Settings::secret_key() ) ); ?>
						<a class="button" id="edss-test-connection" href="<?php echo esc_url( self::action_url( 'test_connection' ) ); ?>">Test Stripe connection</a>
					</td></tr>
				</table>

				</div>

				<div class="edss-tab" data-tab="courses">
				<h2>Course platform</h2>
				<table class="form-table">
					<tr><th>Courses are stored as</th><td>
						<?php
						$active = EDSS_Resolver::course_post_types();
						foreach ( get_post_types( array( 'show_ui' => true ), 'objects' ) as $type => $obj ) {
							if ( in_array( $type, array( 'attachment', 'product', 'product_variation', 'shop_order', 'shop_coupon', 'shop_subscription', 'post', 'page', 'wp_block', 'wp_navigation' ), true ) ) {
								continue;
							}
							$known = isset( EDSS_Resolver::KNOWN_COURSE_TYPES[ $type ] );
							printf(
								'<label style="display:block"><input type="checkbox" name="%s[]" value="%s" %s> %s <code>%s</code>%s</label>',
								esc_attr( $field( 'course_post_types' ) ),
								esc_attr( $type ),
								checked( in_array( $type, $active, true ), true, false ),
								esc_html( $obj->labels->name ),
								esc_html( $type ),
								$known ? ' <strong>— ' . esc_html( EDSS_Resolver::KNOWN_COURSE_TYPES[ $type ] ) . '</strong>' : ''
							);
						}
						?>
						<p class="edss-help">Tick the post type your course platform uses (LearnDash, Tutor LMS, LearnPress, LifterLMS, Sensei, MasterStudy or any other). Nothing ticked = detect the known LMS plugins automatically. Each ticked type gets the <em>Vendor payout</em> box on its course editor.</p>
						<p class="edss-help">Automatic product → course detection: LearnDash, Tutor LMS and Sensei LMS WooCommerce links. For any other platform pick the course on the product's <em>Vendor payout</em> box. Payments must go through WooCommerce checkout.</p>
					</td></tr>
				</table>

				<h2>Split rules</h2>
				<table class="form-table">
					<tr><th>Global default rule</th><td>
						<select name="<?php echo esc_attr( $field( 'default_split_type' ) ); ?>">
							<option value="percent" <?php selected( $s['default_split_type'], 'percent' ); ?>>Percent to vendor</option>
							<option value="fixed" <?php selected( $s['default_split_type'], 'fixed' ); ?>>Fixed amount to vendor (per unit)</option>
						</select>
						<input type="number" step="0.01" min="0" name="<?php echo esc_attr( $field( 'default_split_value' ) ); ?>" value="<?php echo esc_attr( $s['default_split_value'] ); ?>" style="width:110px">
						<p class="edss-help">Used only when the product, course and vendor have no rule. Leave blank to force an explicit rule (missing rule = split is flagged "unmapped", no money sent). Order of precedence: product → course → vendor → this default.</p>
					</td></tr>
					<tr><th>Percentage is taken from</th><td>
						<select name="<?php echo esc_attr( $field( 'split_base' ) ); ?>">
							<option value="excl_tax" <?php selected( $s['split_base'], 'excl_tax' ); ?>>Line total after coupons, excluding tax</option>
							<option value="incl_tax" <?php selected( $s['split_base'], 'incl_tax' ); ?>>Line total after coupons, including tax</option>
						</select>
					</td></tr>
					<tr><th>Course owner fallback</th><td>
						<label><input type="checkbox" name="<?php echo esc_attr( $field( 'author_fallback' ) ); ?>" value="1" <?php checked( $s['author_fallback'], 'yes' ); ?>> If a course has no vendor selected, use the course's WordPress author</label>
					</td></tr>
				</table>

				</div>

				<div class="edss-tab" data-tab="safety">
				<h2>Safeguards</h2>
				<p class="edss-help">These protect you from paying the wrong person, paying twice, or paying for refunded sales. The defaults are recommended.</p>
				<table class="form-table">
					<tr><th>Connected account check</th><td>
						<label><input type="checkbox" name="<?php echo esc_attr( $field( 'require_active_account' ) ); ?>" value="1" <?php checked( $s['require_active_account'], 'yes' ); ?>> Hold the split (retry hourly) until the vendor's Stripe account has the <code>transfers</code> capability active</label>
					</td></tr>
					<tr><th>Fund from the order's charge</th><td>
						<label><input type="checkbox" name="<?php echo esc_attr( $field( 'use_source_transaction' ) ); ?>" value="1" <?php checked( $s['use_source_transaction'], 'yes' ); ?>> Link each transfer to the order's Stripe charge (<code>source_transaction</code>) so it never fails for "insufficient platform balance"</label>
					</td></tr>
					<tr><th>Refunds</th><td>
						<select name="<?php echo esc_attr( $field( 'refund_policy' ) ); ?>">
							<option value="proportional" <?php selected( $s['refund_policy'], 'proportional' ); ?>>Reverse the vendor transfer in proportion to the refund</option>
							<option value="none" <?php selected( $s['refund_policy'], 'none' ); ?>>Do not reverse — just note it and email an alert</option>
						</select>
					</td></tr>
					<tr><th>Max retries for failed transfers</th><td>
						<input type="number" min="1" max="50" name="<?php echo esc_attr( $field( 'max_attempts' ) ); ?>" value="<?php echo (int) $s['max_attempts']; ?>" style="width:80px">
					</td></tr>
					<tr><th>Alert email</th><td>
						<input type="email" class="regular-text" name="<?php echo esc_attr( $field( 'alert_email' ) ); ?>" value="<?php echo esc_attr( $s['alert_email'] ); ?>">
						<p class="edss-help">Emailed when a split is unmapped, held, fails, or a refund can't be reversed.</p>
					</td></tr>
				</table>

				</div>

				<div class="edss-tab" data-tab="webhook">
				<h2>Webhook (Pabbly, Zapier, Make, n8n, GHL…)</h2>
				<table class="form-table">
					<tr><th>Webhook URL</th><td>
						<input type="url" class="large-text" name="<?php echo esc_attr( $field( 'webhook_url' ) ); ?>" value="<?php echo esc_attr( $s['webhook_url'] ); ?>">
						<p class="edss-help">One automation for all vendors. The JSON already contains customer, course, vendor, amounts and the Stripe transfer ID.</p>
						<?php if ( $s['webhook_url'] ) : ?>
							<a class="button" href="<?php echo esc_url( self::action_url( 'test_webhook' ) ); ?>">Send sample payload</a>
						<?php endif; ?>
					</td></tr>
					<tr><th>Signing secret (optional)</th><td>
						<input type="text" class="regular-text" name="<?php echo esc_attr( $field( 'webhook_secret' ) ); ?>" value="<?php echo esc_attr( $s['webhook_secret'] ); ?>">
						<p class="edss-help">If set, each request carries <code>X-EDSS-Signature: sha256=HMAC(body)</code>.</p>
					</td></tr>
					<tr><th>Send these events</th><td>
						<?php foreach ( self::EVENTS as $e ) : ?>
							<label style="margin-right:12px"><input type="checkbox" name="<?php echo esc_attr( $field( 'webhook_events' ) ); ?>[]" value="<?php echo esc_attr( $e ); ?>" <?php checked( in_array( $e, (array) $s['webhook_events'], true ) ); ?>> <?php echo esc_html( $e ); ?></label>
						<?php endforeach; ?>
					</td></tr>
				</table>

				</div>

				<div class="edss-tab" data-tab="educators">
				<h2>Vendor dashboard &amp; Stripe onboarding</h2>
				<p class="edss-help">Create a page (e.g. "My Earnings") containing the shortcode <code>[edss_vendor_dashboard]</code> and send vendors its link. They log in, see every sale and renewal they earned from, and connect Stripe with one button.</p>
				<table class="form-table">
					<tr><th>Self-service onboarding</th><td>
						<label><input type="checkbox" name="<?php echo esc_attr( $field( 'onboarding' ) ); ?>" value="1" <?php checked( $s['onboarding'], 'yes' ); ?>> Vendors can click <strong>Connect Stripe</strong> on the dashboard page (creates a Stripe Express account and saves its ID on their profile automatically)</label>
						<p class="edss-help">Only users who are vendors can use it: marked as Vendor on their profile, already have an account ID, or own a course. An existing account ID is never replaced.</p>
					</td></tr>
					<tr><th>Country for new vendor accounts</th><td>
						<input type="text" maxlength="2" style="width:60px;text-transform:uppercase" name="<?php echo esc_attr( $field( 'account_country' ) ); ?>" value="<?php echo esc_attr( $s['account_country'] ); ?>" placeholder="US">
						<p class="edss-help">Two-letter code. Leave empty to use your Stripe platform's country.</p>
					</td></tr>
				</table>

				</div>

				<?php // edss-private-start ?>
				<div class="edss-tab" data-tab="updates">
				<h2>Plugin updates</h2>
				<p class="edss-help">New versions appear on the Plugins screen with <strong>Update now</strong>, like any other plugin. You can also switch on auto-updates there. Nothing to set up.</p>
				<table class="form-table">
					<tr><th>Version</th><td>
						Installed: <strong><?php echo esc_html( EDSS_VERSION ); ?></strong>
						<a class="button" href="<?php echo esc_url( self::action_url( 'check_update' ) ); ?>">Check for updates now</a>
					</td></tr>
				</table>

				</div>
				<?php // edss-private-end ?>

				<?php submit_button( 'Save settings' ); ?>
			</form>
		</div>
		<?php
	}

	/* =========================================================
	 * admin-post actions
	 * ========================================================= */

	public static function action_retry() {
		$id = absint( $_GET['id'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- the nonce, which includes this ID, is verified by guard() on the next line.
		self::guard( 'edss_retry_' . $id );
		$row = EDSS_Ledger::get( $id );
		if ( ! $row || ! in_array( $row['status'], array( 'failed', 'held', 'unmapped', 'skipped', 'dry_run' ), true ) ) {
			self::back( 'error', 'That split cannot be retried.' );
		}
		if ( 'off' === EDSS_Settings::get( 'run_mode' ) ) {
			self::back( 'error', 'Run mode is Off — switch to Dry run or Live first.' );
		}
		EDSS_Ledger::update(
			$id,
			array(
				'status'   => 'pending',
				'attempts' => 0,
			)
		);
		EDSS_Processor::process_order( (int) $row['order_id'] );
		$row = EDSS_Ledger::get( $id );
		self::back(
			in_array( $row['status'], array( 'transferred', 'dry_run' ), true ) ? 'success' : 'warning',
			sprintf( 'Split #%d re-processed → <strong>%s</strong>. %s', $id, esc_html( $row['status'] ), esc_html( $row['last_error'] ) )
		);
	}

	/**
	 * Diagnostics: the latest WooCommerce orders and, for each one, exactly why it does or doesn't have a split.
	 */
	private static function recent_orders_panel() {
		$orders = wc_get_orders(
			array(
				'limit'   => 15,
				'type'    => 'shop_order',
				'orderby' => 'date',
				'order'   => 'DESC',
			)
		);
		echo '<h2 style="margin-top:30px">Recent orders — was the vendor paid, and if not, why?</h2>';

		// Purchases made through LearnDash's own payment buttons never become WooCommerce orders.
		if ( post_type_exists( 'sfwd-transactions' ) ) {
			$ld = get_posts(
				array(
					'post_type'      => 'sfwd-transactions',
					'post_status'    => 'any',
					'posts_per_page' => 5,
					'fields'         => 'ids',
					'date_query'     => array( array( 'after' => '30 days ago' ) ),
				)
			);
			if ( $ld ) {
				echo '<div class="notice notice-warning inline"><p><strong>' . count( $ld ) . ( count( $ld ) >= 5 ? '+' : '' ) . ' LearnDash transaction(s) in the last 30 days</strong> were paid through LearnDash\'s own checkout, not WooCommerce. This plugin only sees WooCommerce orders — sell the course through a WooCommerce product for the split to happen.</p></div>';
			}
		}

		if ( ! $orders ) {
			echo '<div class="notice notice-warning inline"><p><strong>No WooCommerce orders exist on this site.</strong> The test purchase went through a different checkout (LearnDash payment buttons, a membership/registration plugin, Easy Digital Downloads…). The split only runs for purchases made through the WooCommerce cart/checkout.</p></div>';
			return;
		}

		echo '<table class="widefat striped"><thead><tr><th>Order</th><th>Status</th><th>Payment</th><th>Items → mapping</th><th>Ledger</th><th></th></tr></thead><tbody>';
		foreach ( $orders as $order ) {
			$rows   = EDSS_Ledger::for_order( $order->get_id() );
			$items  = array();
			foreach ( $order->get_items( 'line_item' ) as $item ) {
				$map = EDSS_Resolver::resolve( (int) $item->get_product_id() );
				if ( 'ok' === $map['status'] ) {
					$verdict = '<span class="edss-ok">OK → ' . esc_html( $map['account_id'] ) . '</span>';
				} elseif ( 'not_applicable' === $map['status'] ) {
					$verdict = '<span class="edss-help">' . esc_html( $map['error'] ) . ' (ignored)</span>';
				} else {
					$verdict = '<span class="edss-bad">' . esc_html( $map['error'] ) . '</span>';
				}
				$items[] = esc_html( $item->get_name() ) . ' <small>(product #' . (int) $item->get_product_id() . ')</small><br>' . $verdict;
			}

			if ( $rows ) {
				$ledger = implode( ', ', array_map( function ( $r ) { return esc_html( str_replace( '_', ' ', $r['status'] ) ); }, $rows ) );
			} elseif ( ! $order->is_paid() ) {
				$ledger = '<span class="edss-bad">Not paid (status "' . esc_html( $order->get_status() ) . '") — only processing/completed orders are split</span>';
			} elseif ( 'off' === EDSS_Settings::get( 'run_mode' ) ) {
				$ledger = '<span class="edss-bad">Run mode is Off</span>';
			} elseif ( function_exists( 'as_has_scheduled_action' ) && as_has_scheduled_action( 'edss_process_order', array( $order->get_id() ), EDSS_GROUP ) ) {
				$ledger = 'Queued — background job has not run yet';
			} else {
				$ledger = '<span class="edss-bad">Not recorded</span>';
			}

			printf(
				'<tr><td><a href="%s">#%s</a><br><small>%s</small></td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td><a class="button button-small" href="%s">Process now</a></td></tr>',
				esc_url( $order->get_edit_order_url() ),
				esc_html( $order->get_order_number() ),
				esc_html( $order->get_date_created() ? $order->get_date_created()->date_i18n( 'Y-m-d H:i' ) : '' ),
				esc_html( wc_get_order_status_name( $order->get_status() ) ),
				esc_html( $order->get_payment_method_title() ? $order->get_payment_method_title() : $order->get_payment_method() ),
				wp_kses_post( $items ? implode( '<br>', $items ) : '<small>no items</small>' ),
				wp_kses_post( $ledger ),
				esc_url( self::action_url( 'process_order', array( 'id' => $order->get_id() ) ) )
			);
		}
		echo '</tbody></table>';
		echo '<p class="edss-help">"Process now" runs the split for that order immediately (respects Dry run / Live). It is safe to click more than once — an order line is never paid twice.</p>';
	}

	public static function action_process_order() {
		$id = absint( $_GET['id'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- the nonce, which includes this ID, is verified by guard() on the next line.
		self::guard( 'edss_process_order_' . $id );
		if ( 'off' === EDSS_Settings::get( 'run_mode' ) ) {
			self::back( 'error', 'Run mode is Off — switch to Dry run or Live first.' );
		}
		EDSS_Processor::process_order( $id );
		$rows = EDSS_Ledger::for_order( $id );
		if ( ! $rows ) {
			self::back( 'warning', sprintf( 'Order #%d processed — no split was recorded. See the "Items → mapping" column for the reason (usually: the product is not linked to a course/vendor, or the order is not paid).', $id ) );
		}
		$parts = array();
		foreach ( $rows as $r ) {
			$parts[] = esc_html( $r['status'] . ( $r['last_error'] ? ' — ' . $r['last_error'] : '' ) );
		}
		self::back( 'success', sprintf( 'Order #%d processed: %s', $id, implode( '; ', $parts ) ) );
	}

	// edss-private-start
	public static function action_check_update() {
		self::guard( 'edss_check_update' );
		$release = EDSS_Updater::latest( true );
		delete_site_transient( 'update_plugins' ); // Makes WordPress re-check on the next Plugins page load.
		if ( is_wp_error( $release ) ) {
			self::back( 'error', 'Update check failed: ' . esc_html( $release->get_error_message() ) );
		}
		if ( version_compare( $release['version'], EDSS_VERSION, '>' ) ) {
			self::back( 'success', sprintf( 'Version <strong>%s</strong> is available (installed %s). Go to <a href="%s">Plugins</a> and click <strong>Update now</strong>.', esc_html( $release['version'] ), esc_html( EDSS_VERSION ), esc_url( admin_url( 'plugins.php' ) ) ) );
		}
		self::back( 'success', sprintf( 'You have the latest version (%s).', esc_html( EDSS_VERSION ) ) );
	}
	// edss-private-end

	public static function action_resend() {
		$id = absint( $_GET['id'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- the nonce, which includes this ID, is verified by guard() on the next line.
		self::guard( 'edss_resend_' . $id );
		$row = EDSS_Ledger::get( $id );
		if ( ! $row ) {
			self::back( 'error', 'Split not found.' );
		}
		$res = EDSS_Notifier::send( $id, $row['status'] );
		self::back( is_wp_error( $res ) ? 'error' : 'success', is_wp_error( $res ) ? 'Webhook failed: ' . esc_html( $res->get_error_message() ) : 'Webhook sent.' );
	}

	public static function action_test_connection() {
		self::guard( 'edss_test_connection' );
		$acct = EDSS_Stripe::request( 'GET', 'account' );
		update_option(
			'edss_last_connection',
			array(
				'ok'   => is_wp_error( $acct ) ? 0 : 1,
				'acct' => is_wp_error( $acct ) ? '' : (string) ( $acct['id'] ?? '' ),
				'mode' => EDSS_Settings::mode_label(),
				'time' => time(),
			),
			false
		);
		if ( is_wp_error( $acct ) ) {
			self::back( 'error', 'Stripe connection failed: ' . esc_html( $acct->get_error_message() ) );
		}
		$balance = EDSS_Stripe::request( 'GET', 'balance' );
		$parts   = array();
		if ( ! is_wp_error( $balance ) ) {
			foreach ( array( 'available', 'pending' ) as $bucket ) {
				foreach ( (array) ( $balance[ $bucket ] ?? array() ) as $b ) {
					$parts[] = $bucket . ' ' . EDSS_Stripe::format( $b['amount'], $b['currency'] );
				}
			}
		}
		self::back(
			'success',
			sprintf(
				'Connected to Stripe platform account <code>%s</code> (%s mode). Balance: %s.',
				esc_html( $acct['id'] ?? '?' ),
				esc_html( EDSS_Settings::mode_label() ),
				esc_html( $parts ? implode( ', ', $parts ) : 'n/a' )
			)
		);
	}

	public static function action_test_webhook() {
		self::guard( 'edss_test_webhook' );
		$res = EDSS_Notifier::post( EDSS_Settings::get( 'webhook_url' ), EDSS_Notifier::sample_payload() );
		self::back( is_wp_error( $res ) ? 'error' : 'success', is_wp_error( $res ) ? 'Webhook failed: ' . esc_html( $res->get_error_message() ) : 'Sample payload sent. Map its fields in your automation tool.' );
	}

	public static function action_check_account() {
		$uid = absint( $_GET['id'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- the nonce, which includes this ID, is verified by guard() on the next line.
		self::guard( 'edss_check_account_' . $uid );
		$acct_id = EDSS_Resolver::educator_account( $uid );
		if ( ! $acct_id ) {
			self::back( 'error', 'This vendor has no connected account ID for the current mode.' );
		}
		$acct = EDSS_Stripe::get_account( $acct_id, true );
		if ( is_wp_error( $acct ) ) {
			self::back( 'error', 'Stripe lookup failed: ' . esc_html( $acct->get_error_message() ) );
		}
		$summary = EDSS_Stripe::summarize_account( $acct );
		update_user_meta( $uid, 'edss_status_' . EDSS_Settings::mode_label(), $summary );
		self::back(
			'active' === $summary['transfers'] ? 'success' : 'warning',
			sprintf( '%s: transfers capability <strong>%s</strong>, payouts %s%s.', esc_html( $acct_id ), esc_html( $summary['transfers'] ), $summary['payouts_enabled'] ? 'enabled' : 'disabled', $summary['disabled_reason'] ? ' (' . esc_html( $summary['disabled_reason'] ) . ')' : '' )
		);
	}

	public static function action_export() {
		self::guard( 'edss_export' );
		list( $rows ) = EDSS_Ledger::query(
			array(
				'status'   => isset( $_GET['status'] ) ? sanitize_key( $_GET['status'] ) : '', // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- nonce verified by guard() above.
				'per_page' => 50000,
				'page'     => 1,
			)
		);
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=vendor-splits-' . gmdate( 'Y-m-d' ) . '.csv' );
		$out  = fopen( 'php://output', 'w' );
		$cols = array( 'id', 'created_at', 'order_id', 'is_renewal', 'subscription_id', 'parent_order_id', 'product_id', 'course_id', 'vendor_id', 'account_id', 'currency', 'gross', 'vendor_share', 'platform_share', 'reversed', 'split_type', 'split_value', 'split_source', 'status', 'transfer_id', 'charge_id', 'attempts', 'last_error', 'test_mode' );
		fputcsv( $out, $cols );
		foreach ( $rows as $r ) {
			$c = $r['currency'];
			fputcsv(
				$out,
				array( $r['id'], $r['created_at'], $r['order_id'], $r['is_renewal'], $r['subscription_id'], $r['parent_order_id'], $r['product_id'], $r['course_id'], $r['educator_id'], $r['account_id'], $c, EDSS_Stripe::from_minor( $r['gross_minor'], $c ), EDSS_Stripe::from_minor( $r['educator_minor'], $c ), EDSS_Stripe::from_minor( $r['platform_minor'], $c ), EDSS_Stripe::from_minor( $r['reversed_minor'], $c ), $r['split_type'], $r['split_value'], $r['split_source'], $r['status'], $r['transfer_id'], $r['charge_id'], $r['attempts'], $r['last_error'], $r['test_mode'] )
			);
		}
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		exit;
	}

	/* =========================================================
	 * Vendor profile fields (admins only — a vendor must never edit their own payout account)
	 * ========================================================= */

	public static function user_fields( $user ) {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		$type = get_user_meta( $user->ID, EDSS_Resolver::USER_SPLIT_TYPE, true );
		wp_nonce_field( 'edss_user', 'edss_user_nonce' );
		?>
		<h2>Vendor payouts (Stripe Connect)</h2>
		<table class="form-table">
			<tr><th><label for="edss_acct_test">Connected account ID — TEST mode</label></th><td>
				<input type="text" class="regular-text" id="edss_acct_test" name="edss_acct_test" placeholder="acct_…" value="<?php echo esc_attr( get_user_meta( $user->ID, EDSS_Resolver::USER_ACCT_TEST, true ) ); ?>">
			</td></tr>
			<tr><th><label for="edss_acct_live">Connected account ID — LIVE mode</label></th><td>
				<input type="text" class="regular-text" id="edss_acct_live" name="edss_acct_live" placeholder="acct_…" value="<?php echo esc_attr( get_user_meta( $user->ID, EDSS_Resolver::USER_ACCT_LIVE, true ) ); ?>">
				<p class="description">Copy from Stripe Dashboard → Connect → Connected accounts. Test and live accounts are different objects with different IDs.</p>
			</td></tr>
			<tr><th>Payouts</th><td>
				<label><input type="checkbox" name="edss_active" value="1" <?php checked( 'no' !== get_user_meta( $user->ID, EDSS_Resolver::USER_ACTIVE, true ) ); ?>> Payouts active for this vendor</label><br>
				<label><input type="checkbox" name="edss_is_educator" value="1" <?php checked( 'yes' === get_user_meta( $user->ID, EDSS_Resolver::USER_IS_EDUCATOR, true ) ); ?>> Vendor — may use the Vendor Dashboard page and connect Stripe</label>
			</td></tr>
			<tr><th>Vendor default split</th><td>
				<select name="edss_split_type">
					<option value="">Inherit global default</option>
					<option value="percent" <?php selected( $type, 'percent' ); ?>>Percent</option>
					<option value="fixed" <?php selected( $type, 'fixed' ); ?>>Fixed amount</option>
				</select>
				<input type="number" step="0.01" min="0" name="edss_split_value" style="width:110px" value="<?php echo esc_attr( get_user_meta( $user->ID, EDSS_Resolver::USER_SPLIT_VALUE, true ) ); ?>">
				<p class="description">Applies to all this vendor's courses unless a course or product sets its own rule.</p>
			</td></tr>
			<tr><th>Stripe status (<?php echo esc_html( EDSS_Settings::mode_label() ); ?>)</th><td>
				<?php echo wp_kses_post( self::account_status_html( $user->ID ) ); ?>
				<?php if ( EDSS_Resolver::educator_account( $user->ID ) ) : ?>
					<a class="button button-small" href="<?php echo esc_url( self::action_url( 'check_account', array( 'id' => $user->ID ) ) ); ?>">Check now</a>
				<?php endif; ?>
			</td></tr>
		</table>
		<?php
	}

	public static function validate_user( $errors, $update, $user ) {
		if ( ! isset( $_POST['edss_user_nonce'] ) || ! current_user_can( self::CAP ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		foreach ( array( 'edss_acct_test', 'edss_acct_live' ) as $k ) {
			$v = trim( sanitize_text_field( wp_unslash( $_POST[ $k ] ?? '' ) ) ); // phpcs:ignore WordPress.Security.NonceVerification
			if ( '' !== $v && ! preg_match( EDSS_Resolver::ACCT_REGEX, $v ) ) {
				$errors->add( $k, 'Stripe connected account IDs look like <code>acct_1AbC…</code>. The invalid value was not saved.' );
			}
		}
		$type  = sanitize_key( wp_unslash( $_POST['edss_split_type'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$value = trim( sanitize_text_field( wp_unslash( $_POST['edss_split_value'] ?? '' ) ) ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( $type && '' !== $value && ! EDSS_Resolver::valid_split( $type, $value ) ) {
			$errors->add( 'edss_split', 'Vendor split value is invalid (percent 0–100, fixed ≥ 0). It was not saved.' );
		}
	}

	public static function save_user( $user_id ) {
		if ( ! current_user_can( self::CAP ) || ! current_user_can( 'edit_user', $user_id ) || ! isset( $_POST['edss_user_nonce'] ) ) {
			return;
		}
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['edss_user_nonce'] ) ), 'edss_user' ) ) {
			return;
		}
		foreach ( array( 'edss_acct_test' => EDSS_Resolver::USER_ACCT_TEST, 'edss_acct_live' => EDSS_Resolver::USER_ACCT_LIVE ) as $field => $meta ) {
			$v = trim( sanitize_text_field( wp_unslash( $_POST[ $field ] ?? '' ) ) );
			if ( '' === $v ) {
				delete_user_meta( $user_id, $meta );
			} elseif ( preg_match( EDSS_Resolver::ACCT_REGEX, $v ) ) {
				if ( get_user_meta( $user_id, $meta, true ) !== $v ) {
					delete_user_meta( $user_id, 'edss_status_' . ( EDSS_Resolver::USER_ACCT_TEST === $meta ? 'test' : 'live' ) );
				}
				update_user_meta( $user_id, $meta, $v );
			}
		}
		update_user_meta( $user_id, EDSS_Resolver::USER_ACTIVE, empty( $_POST['edss_active'] ) ? 'no' : 'yes' );
		if ( empty( $_POST['edss_is_educator'] ) ) {
			delete_user_meta( $user_id, EDSS_Resolver::USER_IS_EDUCATOR );
		} else {
			update_user_meta( $user_id, EDSS_Resolver::USER_IS_EDUCATOR, 'yes' );
		}
		self::save_split_fields( $_POST, 'edss_split_type', 'edss_split_value', function ( $key, $val ) use ( $user_id ) {
			'' === $val ? delete_user_meta( $user_id, $key ) : update_user_meta( $user_id, $key, $val );
		}, EDSS_Resolver::USER_SPLIT_TYPE, EDSS_Resolver::USER_SPLIT_VALUE );
	}

	/**
	 * Saves a type/value pair only when valid; an invalid pair keeps the previous values (never silently falls
	 * through to a broader rule).
	 */
	private static function save_split_fields( $src, $type_field, $value_field, $writer, $type_meta, $value_meta ) {
		$type  = sanitize_key( wp_unslash( $src[ $type_field ] ?? '' ) );
		$value = trim( sanitize_text_field( wp_unslash( $src[ $value_field ] ?? '' ) ) );
		if ( '' === $type ) {
			$writer( $type_meta, '' );
			$writer( $value_meta, '' );
			return true;
		}
		if ( ! in_array( $type, array( 'percent', 'fixed' ), true ) || '' === $value || ! EDSS_Resolver::valid_split( $type, $value ) ) {
			return false;
		}
		$writer( $type_meta, $type );
		$writer( $value_meta, (string) (float) $value );
		return true;
	}

	/* =========================================================
	 * Meta boxes: course, product, order
	 * ========================================================= */

	public static function meta_boxes() {
		foreach ( EDSS_Resolver::course_post_types() as $course_type ) {
			add_meta_box( 'edss_course', 'Vendor payout', array( __CLASS__, 'course_box' ), $course_type, 'side' );
		}
		add_meta_box( 'edss_product', 'Vendor payout', array( __CLASS__, 'product_box' ), 'product', 'side' );
		$screens = array( 'shop_order' );
		if ( function_exists( 'wc_get_page_screen_id' ) ) {
			$screens[] = wc_get_page_screen_id( 'shop-order' );
		}
		foreach ( array_unique( $screens ) as $screen ) {
			add_meta_box( 'edss_order', 'Vendor splits', array( __CLASS__, 'order_box' ), $screen, 'normal', 'low' );
		}
	}

	private static function educator_users() {
		return get_users(
			array(
				'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery
					'relation' => 'OR',
					array(
						'key'     => EDSS_Resolver::USER_ACCT_TEST,
						'compare' => 'EXISTS',
					),
					array(
						'key'     => EDSS_Resolver::USER_ACCT_LIVE,
						'compare' => 'EXISTS',
					),
				),
				'orderby'    => 'display_name',
				'number'     => 1000,
			)
		);
	}

	private static function educator_select( $name, $selected, $empty_label ) {
		$users = self::educator_users();
		$ids   = wp_list_pluck( $users, 'ID' );
		if ( $selected && ! in_array( (int) $selected, array_map( 'intval', $ids ), true ) ) {
			$extra = get_userdata( $selected );
			if ( $extra ) {
				$users[] = $extra;
			}
		}
		$html = '<select name="' . esc_attr( $name ) . '"><option value="0">' . esc_html( $empty_label ) . '</option>';
		foreach ( $users as $u ) {
			$acct  = get_user_meta( $u->ID, EDSS_Resolver::account_meta_key(), true );
			$html .= sprintf( '<option value="%d" %s>%s (#%d)%s</option>', $u->ID, selected( (int) $selected, (int) $u->ID, false ), esc_html( $u->display_name ), $u->ID, $acct ? '' : ' — no ' . esc_html( EDSS_Settings::mode_label() ) . ' acct' );
		}
		return $html . '</select>';
	}

	private static function split_inputs( $type, $value ) {
		?>
		<label>Split rule override</label>
		<select name="edss_split_type">
			<option value="">Inherit</option>
			<option value="percent" <?php selected( $type, 'percent' ); ?>>Percent to vendor</option>
			<option value="fixed" <?php selected( $type, 'fixed' ); ?>>Fixed amount to vendor</option>
		</select>
		<input type="number" step="0.01" min="0" name="edss_split_value" value="<?php echo esc_attr( $value ); ?>" placeholder="e.g. 40">
		<?php
	}

	/** Dropdown of courses from every enabled course platform, grouped by post type. */
	private static function course_select( $name, $selected ) {
		$html = '<select name="' . esc_attr( $name ) . '"><option value="0">— Use the course linked by the LMS —</option>';
		foreach ( EDSS_Resolver::course_post_types() as $type ) {
			$obj     = get_post_type_object( $type );
			$courses = get_posts(
				array(
					'post_type'      => $type,
					'post_status'    => array( 'publish', 'private', 'draft', 'pending', 'future' ),
					'posts_per_page' => 1000,
					'orderby'        => 'title',
					'order'          => 'ASC',
					'no_found_rows'  => true,
				)
			);
			if ( ! $courses ) {
				continue;
			}
			$label = isset( EDSS_Resolver::KNOWN_COURSE_TYPES[ $type ] ) ? EDSS_Resolver::KNOWN_COURSE_TYPES[ $type ] : ( $obj ? $obj->labels->name : $type );
			$html .= '<optgroup label="' . esc_attr( $label ) . '">';
			foreach ( $courses as $c ) {
				$html .= sprintf( '<option value="%d" %s>%s (#%d)</option>', $c->ID, selected( $selected, $c->ID, false ), esc_html( $c->post_title ), $c->ID );
			}
			$html .= '</optgroup>';
		}
		if ( $selected && ! get_post( $selected ) ) {
			$html .= sprintf( '<option value="%d" selected>#%d (missing)</option>', $selected, $selected );
		}
		return $html . '</select>';
	}

	/** Existing co-vendors plus two empty rows (save to get more rows). */
	private static function co_educator_inputs( $post_id ) {
		$list   = EDSS_Resolver::clean_co_list( get_post_meta( $post_id, EDSS_Resolver::POST_CO, true ) );
		$list[] = array(
			'user'  => 0,
			'type'  => 'percent',
			'value' => '',
		);
		$list[] = array(
			'user'  => 0,
			'type'  => 'percent',
			'value' => '',
		);
		echo '<label style="margin-top:14px">Co-vendors (also paid on every sale)</label>';
		foreach ( $list as $i => $entry ) {
			echo '<div style="border-top:1px solid #eee;padding-top:6px;margin-top:6px">';
			echo wp_kses( self::educator_select( 'edss_co[' . $i . '][user]', $entry['user'], '— none —' ), self::SELECT_KSES );
			printf(
				'<select name="edss_co[%1$d][type]" style="width:48%%"><option value="percent" %2$s>Percent</option><option value="fixed" %3$s>Fixed</option></select> <input type="number" step="0.01" min="0" name="edss_co[%1$d][value]" value="%4$s" placeholder="e.g. 10" style="width:48%%">',
				(int) $i,
				selected( $entry['type'], 'percent', false ),
				selected( $entry['type'], 'fixed', false ),
				esc_attr( $entry['value'] )
			);
			echo '</div>';
		}
		echo '<p class="edss-help">Each co-vendor gets their own Stripe transfer. If all shares add up to more than the sale, nothing is sent and the split is flagged for review.</p>';
	}

	private static function no_split_checkbox( $post_id, $what ) {
		printf(
			'<label style="font-weight:600"><input type="checkbox" name="edss_no_split" value="1" %s> Do not split this %s</label><p class="edss-help" style="margin-top:0">The platform keeps 100%%. Nothing is sent to a vendor.</p>',
			checked( EDSS_Resolver::split_disabled( $post_id ), true, false ),
			esc_html( $what )
		);
	}

	public static function course_box( $post ) {
		wp_nonce_field( 'edss_post', 'edss_post_nonce' );
		$author = get_userdata( $post->post_author );
		$label  = 'yes' === EDSS_Settings::get( 'author_fallback' ) && $author ? '— Course author: ' . $author->display_name . ' —' : '— None —';
		echo '<div class="edss-box">';
		self::no_split_checkbox( $post->ID, 'course' );
		echo '<label>Vendor (course owner)</label>';
		echo wp_kses( self::educator_select( 'edss_educator_id', get_post_meta( $post->ID, EDSS_Resolver::POST_EDUCATOR, true ), $label ), self::SELECT_KSES );
		self::split_inputs( get_post_meta( $post->ID, EDSS_Resolver::POST_SPLIT_TYPE, true ), get_post_meta( $post->ID, EDSS_Resolver::POST_SPLIT_VALUE, true ) );
		self::co_educator_inputs( $post->ID );
		echo '<p class="edss-help">Every product linked to this course pays this vendor, on the first payment and every renewal.</p></div>';
	}

	public static function product_box( $post ) {
		wp_nonce_field( 'edss_post', 'edss_post_nonce' );
		$related = EDSS_Resolver::detected_course_ids( $post->ID );
		$map     = EDSS_Resolver::resolve( $post->ID );
		echo '<div class="edss-box">';
		self::no_split_checkbox( $post->ID, 'product' );
		echo '<p class="edss-help">Courses linked by your LMS: ' . ( $related ? esc_html( implode( ', ', array_map( function ( $id ) { return get_the_title( $id ) . ' #' . $id; }, $related ) ) ) : 'none detected' ) . '</p>';
		echo '<label>Course</label>' . wp_kses( self::course_select( 'edss_course_id', absint( get_post_meta( $post->ID, EDSS_Resolver::POST_COURSE, true ) ) ), self::SELECT_KSES );
		echo '<label>Vendor override</label>';
		echo wp_kses( self::educator_select( 'edss_educator_id', get_post_meta( $post->ID, EDSS_Resolver::POST_EDUCATOR, true ), '— From the course —' ), self::SELECT_KSES );
		self::split_inputs( get_post_meta( $post->ID, EDSS_Resolver::POST_SPLIT_TYPE, true ), get_post_meta( $post->ID, EDSS_Resolver::POST_SPLIT_VALUE, true ) );
		self::co_educator_inputs( $post->ID );

		if ( 'ok' === $map['status'] ) {
			foreach ( $map['payees'] as $p ) {
				$u = get_userdata( $p['educator_id'] );
				printf( '<p class="edss-ok" style="margin:4px 0">Pays %s → %s at %s (%s).</p>', esc_html( $u ? $u->display_name : '' ), esc_html( $p['account_id'] ), esc_html( EDSS_Resolver::describe_rule( $p['split_type'], $p['split_value'] ) ), esc_html( EDSS_Resolver::source_label( $p['split_source'] ) ) );
			}
		} elseif ( 'error' === $map['status'] ) {
			echo '<p class="edss-bad">' . esc_html( $map['error'] ) . '</p>';
		} else {
			echo '<p class="edss-help">No split: ' . esc_html( $map['error'] ) . '</p>';
		}
		echo '</div>';
	}

	private static function can_save_post( $post_id ) {
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) ) {
			return false;
		}
		if ( ! isset( $_POST['edss_post_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['edss_post_nonce'] ) ), 'edss_post' ) ) {
			return false;
		}
		return current_user_can( self::CAP ) && current_user_can( 'edit_post', $post_id );
	}

	private static function save_post_fields( $post_id, $with_course ) {
		$writer = function ( $key, $val ) use ( $post_id ) {
			'' === $val ? delete_post_meta( $post_id, $key ) : update_post_meta( $post_id, $key, $val );
		};
		// phpcs:disable WordPress.Security.NonceVerification -- verified in can_save_post().
		$educator = absint( $_POST['edss_educator_id'] ?? 0 );
		$writer( EDSS_Resolver::POST_EDUCATOR, $educator ? (string) $educator : '' );
		$writer( EDSS_Resolver::POST_NO_SPLIT, empty( $_POST['edss_no_split'] ) ? '' : 'yes' );
		if ( $with_course ) {
			$course = absint( $_POST['edss_course_id'] ?? 0 );
			$writer( EDSS_Resolver::POST_COURSE, $course ? (string) $course : '' );
		}
		$ok = self::save_split_fields( $_POST, 'edss_split_type', 'edss_split_value', $writer, EDSS_Resolver::POST_SPLIT_TYPE, EDSS_Resolver::POST_SPLIT_VALUE );

		// Co-vendors: saved only when every filled row is valid, otherwise the previous list stays.
		$co_rows = array();
		$co_ok   = true;
		$co_input = isset( $_POST['edss_co'] ) ? map_deep( wp_unslash( $_POST['edss_co'] ), 'sanitize_text_field' ) : array();
		foreach ( (array) $co_input as $entry ) {
			$uid = absint( $entry['user'] ?? 0 );
			if ( ! $uid ) {
				continue;
			}
			$type  = sanitize_key( $entry['type'] ?? '' );
			$value = trim( (string) ( $entry['value'] ?? '' ) );
			if ( ! in_array( $type, array( 'percent', 'fixed' ), true ) || '' === $value || ! EDSS_Resolver::valid_split( $type, $value ) ) {
				$co_ok = false;
				break;
			}
			$co_rows[] = array(
				'user'  => $uid,
				'type'  => $type,
				'value' => (string) (float) $value,
			);
		}
		if ( $co_ok ) {
			$writer( EDSS_Resolver::POST_CO, $co_rows ? $co_rows : '' );
		} else {
			$ok = false;
		}
		// phpcs:enable
		if ( ! $ok ) {
			set_transient( 'edss_notice_' . get_current_user_id(), array( 'error', 'Vendor payout: a split value was invalid (percent 0–100, fixed ≥ 0, co-vendors need a value) and was NOT saved. The previous rule is still in place.' ), 60 );
		}
	}

	public static function save_post( $post_id, $post ) {
		$is_product = 'product' === $post->post_type;
		if ( ! $is_product && ! in_array( $post->post_type, EDSS_Resolver::course_post_types(), true ) ) {
			return;
		}
		if ( self::can_save_post( $post_id ) ) {
			self::save_post_fields( $post_id, $is_product );
		}
	}

	public static function order_box( $post_or_order ) {
		if ( $post_or_order instanceof WP_Post ) {
			$order_id = $post_or_order->ID;
		} elseif ( is_object( $post_or_order ) && method_exists( $post_or_order, 'get_id' ) ) {
			$order_id = $post_or_order->get_id();
		} else {
			return;
		}
		$rows = EDSS_Ledger::for_order( $order_id );
		if ( ! $rows ) {
			echo '<p>No vendor splits for this order.</p>';
			return;
		}
		echo '<table class="widefat striped"><thead><tr><th>Item</th><th>Vendor → account</th><th>Gross → vendor</th><th>Status</th><th>Transfer</th><th></th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$u = $r['educator_id'] ? get_userdata( $r['educator_id'] ) : null;
			printf(
				'<tr><td>%s</td><td>%s<br><code>%s</code></td><td>%s → <strong>%s</strong></td><td>%s<br><small>%s</small></td><td><code>%s</code></td><td>%s</td></tr>',
				esc_html( get_the_title( $r['product_id'] ) ),
				esc_html( $u ? $u->display_name : '—' ),
				esc_html( $r['account_id'] ),
				esc_html( EDSS_Stripe::format( $r['gross_minor'], $r['currency'] ) ),
				esc_html( EDSS_Stripe::format( $r['educator_minor'], $r['currency'] ) ),
				wp_kses_post( self::status_badge( $r['status'] ) ),
				esc_html( $r['last_error'] ),
				esc_html( $r['transfer_id'] ),
				wp_kses_post( self::row_actions_html( $r ) )
			);
		}
		echo '</tbody></table>';
	}
}
