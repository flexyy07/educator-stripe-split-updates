<?php
/**
 * Plugin updates from the public release feed EDSS_UPDATE_REPO (info.json + packages/*.zip on its main branch).
 *
 * WordPress shows "Update now" (and allows auto-updates) whenever info.json names a version newer than
 * EDSS_VERSION. No key or token is needed.
 */

defined( 'ABSPATH' ) || exit;

class EDSS_Updater {

	const SLUG  = 'educator-stripe-split';
	const CACHE = 'edss_update_release';

	public static function init() {
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'inject' ) );
		add_filter( 'plugins_api', array( __CLASS__, 'info' ), 20, 3 );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'flush' ) );
	}

	public static function flush() {
		delete_transient( self::CACHE );
		delete_transient( self::CACHE . '_readme' );
	}

	private static function base() {
		return 'https://raw.githubusercontent.com/' . EDSS_UPDATE_REPO . '/main/';
	}

	/**
	 * Latest release, cached for 6 hours (errors for 1 hour).
	 *
	 * @return array|WP_Error {version, package, notes, published}
	 */
	public static function latest( $force = false ) {
		if ( ! defined( 'EDSS_UPDATE_REPO' ) ) {
			return new WP_Error( 'edss_update', 'Updates are not configured for this copy of the plugin.' );
		}
		if ( ! $force ) {
			$cached = get_transient( self::CACHE );
			if ( is_array( $cached ) && isset( $cached['error'] ) ) {
				return new WP_Error( 'edss_update', $cached['error'] );
			}
			// Ignore data cached by older versions of this updater (they pointed somewhere else).
			if ( is_array( $cached ) && 0 === strpos( (string) ( $cached['package'] ?? '' ), self::base() ) ) {
				return $cached;
			}
		}

		// info.json and the zip are plain files served straight from raw.githubusercontent.com: no redirect to a
		// signed URL, which WordPress's downloader could not follow ("Download failed. Unauthorized").
		$base = self::base();
		$res  = wp_remote_get(
			$base . 'info.json',
			array(
				'timeout' => 15,
				'headers' => array( 'User-Agent' => self::SLUG ),
			)
		);
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$body = json_decode( wp_remote_retrieve_body( $res ), true );

		$error = '';
		if ( 200 !== $code || ! is_array( $body ) ) {
			$error = sprintf( 'The update server answered with HTTP %d. Please try again later.', $code );
		} elseif ( empty( $body['version'] ) || empty( $body['package'] ) || 0 !== strpos( (string) $body['package'], $base ) ) {
			$error = 'The update information is incomplete.'; // Only packages from our own feed are ever installed.
		}
		if ( $error ) {
			set_transient( self::CACHE, array( 'error' => $error ), HOUR_IN_SECONDS );
			return new WP_Error( 'edss_update', $error );
		}

		$data = array(
			'version'   => ltrim( (string) $body['version'], 'vV' ),
			'package'   => (string) $body['package'],
			'notes'     => (string) ( $body['notes'] ?? '' ),
			'published' => (string) ( $body['published'] ?? '' ),
		);
		set_transient( self::CACHE, $data, 6 * HOUR_IN_SECONDS );
		return $data;
	}

	private static function item( $release ) {
		$file = plugin_basename( EDSS_FILE );
		return (object) array(
			'id'           => $file,
			'slug'         => self::SLUG,
			'plugin'       => $file,
			'new_version'  => $release['version'],
			'url'          => '',
			'package'      => $release['package'],
			'icons'        => array(),
			'banners'      => array(),
			'requires_php' => '7.4',
		);
	}

	/** Adds our update to WordPress's plugin-update list. */
	public static function inject( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}
		$release = self::latest( ! empty( $_GET['force-check'] ) ); // phpcs:ignore WordPress.Security.NonceVerification -- core "Check again" link.
		if ( is_wp_error( $release ) ) {
			return $transient;
		}
		$file = plugin_basename( EDSS_FILE );
		if ( version_compare( $release['version'], EDSS_VERSION, '>' ) ) {
			$transient->response[ $file ] = self::item( $release );
		} else {
			if ( isset( $transient->response[ $file ] ) ) {
				unset( $transient->response[ $file ] );
			}
			$transient->no_update[ $file ] = self::item( $release );
		}
		return $transient;
	}

	/** "View details" popup on the Plugins screen. */
	public static function info( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || self::SLUG !== $args->slug ) {
			return $result;
		}
		$release = self::latest();
		if ( is_wp_error( $release ) ) {
			return $result;
		}
		$sections = self::readme_sections( self::readme_text() );
		if ( empty( $sections['changelog'] ) ) {
			$sections['changelog'] = $release['notes'] ? '<p>' . nl2br( esc_html( $release['notes'] ) ) . '</p>' : '<p>No release notes.</p>';
		}
		return (object) array(
			'name'          => 'Educator Stripe Split',
			'slug'          => self::SLUG,
			'version'       => $release['version'],
			'author'        => 'Faraz Fayaz',
			'requires'      => '6.5',
			'tested'        => '7.1',
			'requires_php'  => '7.4',
			'last_updated'  => $release['published'],
			'sections'      => $sections,
			'download_link' => $release['package'],
		);
	}

	/** The newest readme.txt from the feed (so the popup describes the version being offered), else the local one. */
	private static function readme_text() {
		$cached = get_transient( self::CACHE . '_readme' );
		if ( is_string( $cached ) && '' !== $cached ) {
			return $cached;
		}
		$res  = wp_remote_get( self::base() . 'readme.txt', array( 'timeout' => 15 ) );
		$text = ( ! is_wp_error( $res ) && 200 === (int) wp_remote_retrieve_response_code( $res ) ) ? (string) wp_remote_retrieve_body( $res ) : '';
		if ( '' === $text && is_readable( EDSS_DIR . 'readme.txt' ) ) {
			$text = (string) file_get_contents( EDSS_DIR . 'readme.txt' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		set_transient( self::CACHE . '_readme', $text, 6 * HOUR_IN_SECONDS );
		return $text;
	}

	/**
	 * Turns readme.txt sections into the HTML tabs of the "View details" popup.
	 * Handles what our readme uses: paragraphs, "* " and "1. " lists, "= Heading =", **bold**, `code` and links.
	 */
	private static function readme_sections( $text ) {
		$map   = array(
			'description'                => 'description',
			'installation'               => 'installation',
			'frequently asked questions' => 'faq',
			'changelog'                  => 'changelog',
			'external services'          => 'other_notes',
		);
		$out   = array();
		$parts = preg_split( '/^==\s*(.+?)\s*==\s*$/m', str_replace( "\r\n", "\n", (string) $text ), -1, PREG_SPLIT_DELIM_CAPTURE );
		$count = count( $parts );
		for ( $i = 1; $i + 1 < $count; $i += 2 ) {
			$key = $map[ strtolower( trim( $parts[ $i ] ) ) ] ?? '';
			if ( $key ) {
				$out[ $key ] = self::to_html( trim( $parts[ $i + 1 ] ) );
			}
		}
		return $out;
	}

	private static function to_html( $body ) {
		$html  = '';
		$list  = '';
		$para  = array();
		$flush = function () use ( &$html, &$list, &$para ) {
			if ( $para ) {
				$html .= '<p>' . implode( ' ', $para ) . '</p>';
				$para  = array();
			}
			if ( $list ) {
				$html .= '</' . $list . '>';
				$list  = '';
			}
		};
		foreach ( explode( "\n", $body ) as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				$flush();
				continue;
			}
			if ( preg_match( '/^=\s*(.+?)\s*=$/', $line, $m ) ) {
				$flush();
				$html .= '<h4>' . self::inline( $m[1] ) . '</h4>';
				continue;
			}
			if ( preg_match( '/^(\*|\d+\.)\s+(.*)$/', $line, $m ) ) {
				$want = '*' === $m[1] ? 'ul' : 'ol';
				if ( $para ) {
					$html .= '<p>' . implode( ' ', $para ) . '</p>';
					$para  = array();
				}
				if ( $list !== $want ) {
					if ( $list ) {
						$html .= '</' . $list . '>';
					}
					$html .= '<' . $want . '>';
					$list  = $want;
				}
				$html .= '<li>' . self::inline( $m[2] ) . '</li>';
				continue;
			}
			if ( $list ) {
				$html .= '</' . $list . '>';
				$list  = '';
			}
			$para[] = self::inline( $line );
		}
		$flush();
		return $html;
	}

	private static function inline( $text ) {
		$text = esc_html( $text );
		$text = preg_replace( '/\*\*(.+?)\*\*/', '<strong>$1</strong>', $text );
		$text = preg_replace( '/`([^`]+)`/', '<code>$1</code>', $text );
		return make_clickable( $text );
	}
}
