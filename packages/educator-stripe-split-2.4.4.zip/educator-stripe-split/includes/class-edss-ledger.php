<?php
/**
 * Audit ledger: one row per paid order line item (initial order or renewal order).
 * The unique idem_key (order + line item) is what makes duplicate webhooks/automation runs harmless.
 */

defined( 'ABSPATH' ) || exit;

class EDSS_Ledger {

	const INT_COLS = array( 'id', 'order_id', 'item_id', 'parent_order_id', 'subscription_id', 'is_renewal', 'product_id', 'course_id', 'educator_id', 'gross_minor', 'educator_minor', 'platform_minor', 'reversed_minor', 'attempts', 'test_mode' );

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'edss_ledger';
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table   = self::table();
		$collate = $wpdb->get_charset_collate();

		dbDelta(
			"CREATE TABLE $table (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  idem_key varchar(80) NOT NULL,
  order_id bigint(20) unsigned NOT NULL DEFAULT 0,
  item_id bigint(20) unsigned NOT NULL DEFAULT 0,
  parent_order_id bigint(20) unsigned NOT NULL DEFAULT 0,
  subscription_id bigint(20) unsigned NOT NULL DEFAULT 0,
  is_renewal tinyint(1) NOT NULL DEFAULT 0,
  product_id bigint(20) unsigned NOT NULL DEFAULT 0,
  course_id bigint(20) unsigned NOT NULL DEFAULT 0,
  educator_id bigint(20) unsigned NOT NULL DEFAULT 0,
  account_id varchar(64) NOT NULL DEFAULT '',
  currency varchar(3) NOT NULL DEFAULT '',
  gross_minor bigint(20) NOT NULL DEFAULT 0,
  split_type varchar(10) NOT NULL DEFAULT '',
  split_value decimal(14,4) NOT NULL DEFAULT 0,
  split_source varchar(20) NOT NULL DEFAULT '',
  educator_minor bigint(20) NOT NULL DEFAULT 0,
  platform_minor bigint(20) NOT NULL DEFAULT 0,
  status varchar(20) NOT NULL DEFAULT 'pending',
  transfer_id varchar(64) NOT NULL DEFAULT '',
  charge_id varchar(64) NOT NULL DEFAULT '',
  reversed_minor bigint(20) NOT NULL DEFAULT 0,
  reversal_ids text NULL,
  attempts int(11) NOT NULL DEFAULT 0,
  last_error text NULL,
  webhook_status varchar(190) NOT NULL DEFAULT '',
  test_mode tinyint(1) NOT NULL DEFAULT 0,
  created_at datetime NULL DEFAULT NULL,
  updated_at datetime NULL DEFAULT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY idem_key (idem_key),
  KEY order_id (order_id),
  KEY status (status),
  KEY educator_id (educator_id)
) $collate;"
		);

		update_option( 'edss_db_version', EDSS_DB_VERSION );
	}

	public static function maybe_upgrade() {
		if ( EDSS_DB_VERSION !== get_option( 'edss_db_version' ) ) {
			self::install();
		}
	}

	private static function format_for( $col ) {
		return in_array( $col, self::INT_COLS, true ) ? '%d' : '%s';
	}

	public static function get( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $id ), ARRAY_A );
	}

	public static function get_by_key( $key ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE idem_key = %s', $key ), ARRAY_A );
	}

	public static function for_order( $order_id ) {
		global $wpdb;
		return (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE order_id = %d ORDER BY id ASC', $order_id ), ARRAY_A );
	}

	/**
	 * INSERT IGNORE on the unique key, then return whichever row won.
	 */
	public static function create_if_missing( $key, $data ) {
		global $wpdb;
		$now  = current_time( 'mysql', true );
		$data = array_merge(
			$data,
			array(
				'idem_key'   => $key,
				'status'     => 'pending',
				'created_at' => $now,
				'updated_at' => $now,
			)
		);
		$cols    = array_keys( $data );
		$formats = array_map( array( __CLASS__, 'format_for' ), $cols );
		$sql     = 'INSERT IGNORE INTO ' . self::table() . ' (`' . implode( '`,`', $cols ) . '`) VALUES (' . implode( ',', $formats ) . ')';
		$wpdb->query( $wpdb->prepare( $sql, array_values( $data ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return self::get_by_key( $key );
	}

	public static function update( $id, $data ) {
		global $wpdb;
		$data['updated_at'] = current_time( 'mysql', true );
		return $wpdb->update(
			self::table(),
			$data,
			array( 'id' => (int) $id ),
			array_map( array( __CLASS__, 'format_for' ), array_keys( $data ) ),
			array( '%d' )
		);
	}

	/**
	 * Atomically move a row into 'processing'. Only one PHP process can win, so two simultaneous
	 * events for the same order can never both send a transfer. A 'processing' row older than
	 * 15 minutes (crashed run) can be reclaimed.
	 */
	public static function claim( $id, $from_statuses ) {
		global $wpdb;
		$in     = implode( ',', array_fill( 0, count( $from_statuses ), '%s' ) );
		$sql    = 'UPDATE ' . self::table() . " SET status = 'processing', updated_at = %s WHERE id = %d AND ( status IN ($in) OR ( status = 'processing' AND updated_at < %s ) )";
		$params = array_merge(
			array( current_time( 'mysql', true ), (int) $id ),
			$from_statuses,
			array( gmdate( 'Y-m-d H:i:s', time() - 15 * MINUTE_IN_SECONDS ) )
		);
		return 1 === (int) $wpdb->query( $wpdb->prepare( $sql, $params ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	}

	/**
	 * Orders with splits that should be retried by the hourly sweep.
	 */
	public static function orders_needing_retry( $max_attempts, $limit = 50 ) {
		global $wpdb;
		$stale = gmdate( 'Y-m-d H:i:s', time() - 15 * MINUTE_IN_SECONDS );
		return array_map(
			'intval',
			(array) $wpdb->get_col(
				$wpdb->prepare(
					'SELECT DISTINCT order_id FROM ' . self::table() . " WHERE status = 'held'
					 OR ( status = 'failed' AND attempts < %d )
					 OR ( status IN ('processing','pending') AND updated_at < %s )
					 ORDER BY order_id ASC LIMIT %d",
					$max_attempts,
					$stale,
					$limit
				)
			)
		);
	}

	public static function query( $args ) {
		global $wpdb;
		$table  = self::table();
		$where  = array( '1=1' );
		$params = array();

		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'status = %s';
			$params[] = $args['status'];
		}
		if ( ! empty( $args['order_id'] ) ) {
			$where[]  = 'order_id = %d';
			$params[] = (int) $args['order_id'];
		}
		if ( ! empty( $args['educator_id'] ) ) {
			$where[]  = 'educator_id = %d';
			$params[] = (int) $args['educator_id'];
		}
		$w = implode( ' AND ', $where );

		$count_sql = "SELECT COUNT(*) FROM $table WHERE $w";
		$total     = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) ) : $wpdb->get_var( $count_sql ) ); // phpcs:ignore

		$limit  = max( 1, (int) ( $args['per_page'] ?? 50 ) );
		$offset = ( max( 1, (int) ( $args['page'] ?? 1 ) ) - 1 ) * $limit;
		$rows   = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM $table WHERE $w ORDER BY id DESC LIMIT %d OFFSET %d", array_merge( $params, array( $limit, $offset ) ) ), // phpcs:ignore
			ARRAY_A
		);

		return array( $rows ? $rows : array(), $total );
	}

	/** Per currency + status: net (after reversals) all time and since the 1st of this month (UTC). */
	public static function educator_totals( $educator_id, $test_mode ) {
		global $wpdb;
		return (array) $wpdb->get_results(
			$wpdb->prepare(
				'SELECT currency, status,
					SUM(educator_minor - reversed_minor) AS net_minor,
					SUM(CASE WHEN created_at >= %s THEN educator_minor - reversed_minor ELSE 0 END) AS net_minor_month
				 FROM ' . self::table() . ' WHERE educator_id = %d AND test_mode = %d GROUP BY currency, status',
				gmdate( 'Y-m-01 00:00:00' ),
				$educator_id,
				$test_mode ? 1 : 0
			),
			ARRAY_A
		);
	}

	/** Net amount paid to all educators since the 1st of this month (UTC), per currency. */
	public static function month_paid( $test_mode ) {
		global $wpdb;
		$out = array();
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT currency, SUM(educator_minor - reversed_minor) AS net FROM ' . self::table() . " WHERE test_mode = %d AND status IN ('transferred','partially_reversed','reversed') AND created_at >= %s GROUP BY currency",
				$test_mode ? 1 : 0,
				gmdate( 'Y-m-01 00:00:00' )
			),
			ARRAY_A
		);
		foreach ( (array) $rows as $r ) {
			$out[ $r['currency'] ] = (int) $r['net'];
		}
		return $out;
	}

	public static function attention_rows( $test_mode, $limit = 10 ) {
		global $wpdb;
		return (array) $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM ' . self::table() . " WHERE test_mode = %d AND status IN ('unmapped','failed','held') ORDER BY id DESC LIMIT %d",
				$test_mode ? 1 : 0,
				$limit
			),
			ARRAY_A
		);
	}

	public static function educator_rows( $educator_id, $test_mode, $limit = 50 ) {
		global $wpdb;
		return (array) $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM ' . self::table() . ' WHERE educator_id = %d AND test_mode = %d ORDER BY id DESC LIMIT %d',
				$educator_id,
				$test_mode ? 1 : 0,
				$limit
			),
			ARRAY_A
		);
	}

	/** Rows per status; pass true/false to count only test-mode / live-mode rows. */
	public static function status_counts( $test_mode = null ) {
		global $wpdb;
		$out   = array();
		$where = null === $test_mode ? '' : $wpdb->prepare( ' WHERE test_mode = %d', $test_mode ? 1 : 0 );
		foreach ( (array) $wpdb->get_results( 'SELECT status, COUNT(*) AS c FROM ' . self::table() . $where . ' GROUP BY status', ARRAY_A ) as $r ) {
			$out[ $r['status'] ] = (int) $r['c'];
		}
		return $out;
	}
}
