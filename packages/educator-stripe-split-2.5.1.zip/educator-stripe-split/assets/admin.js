/* Vendors Payment Split — admin screens. */
(function () {
	'use strict';

	// Settings tabs: every tab stays inside the one form, so all fields are always saved together.
	var links = document.querySelectorAll('.edss-tabs .nav-tab');
	var panes = document.querySelectorAll('.edss-tab');
	if (links.length && panes.length) {
		var show = function (name) {
			if (!document.querySelector('.edss-tab[data-tab="' + name + '"]')) {
				name = 'start';
			}
			Array.prototype.forEach.call(panes, function (p) {
				p.style.display = p.getAttribute('data-tab') === name ? '' : 'none';
			});
			Array.prototype.forEach.call(links, function (a) {
				a.classList.toggle('nav-tab-active', a.getAttribute('data-tab') === name);
			});
			try { window.localStorage.setItem('edssTab', name); } catch (e) {}
		};
		Array.prototype.forEach.call(links, function (a) {
			a.addEventListener('click', function (e) {
				e.preventDefault();
				var name = a.getAttribute('data-tab');
				if (window.history && window.history.replaceState) {
					window.history.replaceState(null, '', '#' + name);
				}
				show(name);
			});
		});
		var start = 'start';
		try { start = window.localStorage.getItem('edssTab') || start; } catch (e) {}
		if (window.location.hash) {
			start = window.location.hash.slice(1);
		}
		show(start);
	}

	// "Test Stripe connection" does not save: stop it when a pasted key has not been saved yet.
	var test = document.getElementById('edss-test-connection');
	if (test) {
		test.addEventListener('click', function (e) {
			var unsaved = Array.prototype.some.call(document.querySelectorAll('.edss-key-input'), function (i) {
				return i.value.trim() !== '';
			});
			if (unsaved) {
				e.preventDefault();
				window.alert('You pasted a key but it is not saved yet.\n\nClick "Save settings" first, then click "Test Stripe connection".');
			}
		});
	}

	// Buttons that move real money ask first.
	document.addEventListener('click', function (e) {
		var el = e.target.closest ? e.target.closest('[data-edss-confirm]') : null;
		if (el && !window.confirm(el.getAttribute('data-edss-confirm'))) {
			e.preventDefault();
		}
	});
})();
