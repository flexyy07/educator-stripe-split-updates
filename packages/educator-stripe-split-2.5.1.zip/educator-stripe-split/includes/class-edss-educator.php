<?php
/**
 * Vendor-facing side: [edss_educator_dashboard] shortcode with earnings, and self-service Stripe onboarding
 * ("Connect Stripe") using Stripe Connect Account Links. Vendors only ever see their own splits.
 */

defined( 'ABSPATH' ) || exit;

class EDSS_Educator {

	const SHORTCODE        = 'edss_vendor_dashboard';
	const LEGACY_SHORTCODE = 'edss_educator_dashboard'; // Pages made before the rename keep working.

	public static function init() {
		add_shortcode( self::SHORTCODE, array( __CLASS__, 'render' ) );
		add_shortcode( self::LEGACY_SHORTCODE, array( __CLASS__, 'render' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_edss_connect', array( __CLASS__, 'action_connect' ) );
		add_action( 'admin_post_edss_stripe_login', array( __CLASS__, 'action_stripe_login' ) );
	}

	public static function assets() {
		wp_register_style( 'edss-dashboard', plugins_url( 'assets/dashboard.css', EDSS_FILE ), array(), EDSS_VERSION );
		$post = get_post();
		if ( $post && ( has_shortcode( (string) $post->post_content, self::SHORTCODE ) || has_shortcode( (string) $post->post_content, self::LEGACY_SHORTCODE ) ) ) {
			wp_enqueue_style( 'edss-dashboard' );
		}
	}

	private static function current_educator() {
		$uid = get_current_user_id();
		return ( $uid && EDSS_Resolver::is_educator( $uid ) ) ? $uid : 0;
	}

	/* =========================================================
	 * Stripe onboarding
	 * ========================================================= */

	/** The platform's country, used for new connected accounts unless a country is set in Settings. */
	private static function account_country() {
		$country = strtoupper( trim( (string) EDSS_Settings::get( 'account_country' ) ) );
		if ( preg_match( '/^[A-Z]{2}$/', $country ) ) {
			return $country;
		}
		$cache_key = 'edss_platform_country_' . EDSS_Settings::mode_label();
		$cached    = get_transient( $cache_key );
		if ( $cached ) {
			return $cached;
		}
		$platform = EDSS_Stripe::request( 'GET', 'account' );
		if ( is_wp_error( $platform ) || empty( $platform['country'] ) ) {
			return '';
		}
		set_transient( $cache_key, $platform['country'], DAY_IN_SECONDS );
		return $platform['country'];
	}

	/**
	 * Creates the vendor's Stripe Express account the first time (never replaces an existing ID).
	 *
	 * @return string|WP_Error acct_… ID.
	 */
	private static function ensure_account( $user ) {
		$existing = EDSS_Resolver::educator_account( $user->ID );
		if ( preg_match( EDSS_Resolver::ACCT_REGEX, $existing ) ) {
			return $existing;
		}
		$params = array(
			'type'         => 'express',
			'email'        => $user->user_email,
			'capabilities' => array( 'transfers' => array( 'requested' => 'true' ) ),
			'metadata'     => array(
				'wp_user_id' => (string) $user->ID,
				'edss_site'  => EDSS_Settings::site_tag(),
			),
		);
		$country = self::account_country();
		if ( $country ) {
			$params['country'] = $country;
		}
		// Same key on a double click → Stripe returns the same account instead of creating a second one.
		$acct = EDSS_Stripe::request( 'POST', 'accounts', $params, 'edss-acct-' . EDSS_Settings::site_tag() . '-' . EDSS_Settings::mode_label() . '-' . $user->ID );
		if ( is_wp_error( $acct ) ) {
			return $acct;
		}
		update_user_meta( $user->ID, EDSS_Resolver::account_meta_key(), $acct['id'] );
		update_user_meta( $user->ID, EDSS_Resolver::USER_IS_EDUCATOR, 'yes' );
		return $acct['id'];
	}

	private static function safe_return_url() {
		$url = isset( $_REQUEST['return'] ) ? esc_url_raw( wp_unslash( $_REQUEST['return'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$url = wp_validate_redirect( $url, '' );
		return $url ? $url : home_url( '/' );
	}

	/** "Connect Stripe" / "Finish Stripe setup": also used as the Account Link refresh_url. */
	public static function action_connect() {
		$return = self::safe_return_url();
		if ( ! is_user_logged_in() || ! isset( $_REQUEST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_REQUEST['_wpnonce'] ) ), 'edss_connect' ) ) {
			wp_safe_redirect( add_query_arg( 'edss_stripe', 'expired', $return ) );
			exit;
		}
		$uid = self::current_educator();
		if ( ! $uid || 'yes' !== EDSS_Settings::get( 'onboarding' ) ) {
			wp_die( 'Stripe onboarding is not available for this account.' );
		}

		$acct_id = self::ensure_account( get_userdata( $uid ) );
		if ( is_wp_error( $acct_id ) ) {
			wp_die( 'Stripe could not create your account: ' . esc_html( $acct_id->get_error_message() ) . ' <a href="' . esc_url( $return ) . '">Back</a>' );
		}

		$link = EDSS_Stripe::request(
			'POST',
			'account_links',
			array(
				'account'     => $acct_id,
				'refresh_url' => self::connect_url( $return ),
				'return_url'  => add_query_arg( 'edss_stripe', 'return', $return ),
				'type'        => 'account_onboarding',
			)
		);
		if ( is_wp_error( $link ) || empty( $link['url'] ) ) {
			wp_die( 'Stripe onboarding link failed: ' . esc_html( is_wp_error( $link ) ? $link->get_error_message() : 'no URL returned' ) . ' <a href="' . esc_url( $return ) . '">Back</a>' );
		}
		wp_redirect( $link['url'] ); // phpcs:ignore WordPress.Security.SafeRedirect -- Stripe-hosted onboarding.
		exit;
	}

	/** Opens the vendor's Stripe Express dashboard (balance, payouts, bank details). */
	public static function action_stripe_login() {
		$return = self::safe_return_url();
		if ( ! is_user_logged_in() || ! isset( $_REQUEST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_REQUEST['_wpnonce'] ) ), 'edss_stripe_login' ) ) {
			wp_safe_redirect( $return );
			exit;
		}
		$uid     = self::current_educator();
		$acct_id = $uid ? EDSS_Resolver::educator_account( $uid ) : '';
		if ( ! $acct_id ) {
			wp_safe_redirect( $return );
			exit;
		}
		$login = EDSS_Stripe::request( 'POST', 'accounts/' . rawurlencode( $acct_id ) . '/login_links' );
		if ( is_wp_error( $login ) || empty( $login['url'] ) ) {
			wp_die( 'Your Stripe dashboard could not be opened: ' . esc_html( is_wp_error( $login ) ? $login->get_error_message() : 'no URL' ) . ' <a href="' . esc_url( $return ) . '">Back</a>' );
		}
		wp_redirect( $login['url'] ); // phpcs:ignore WordPress.Security.SafeRedirect -- Stripe-hosted dashboard.
		exit;
	}

	private static function connect_url( $return ) {
		return add_query_arg(
			array(
				'action'   => 'edss_connect',
				'return'   => rawurlencode( $return ),
				'_wpnonce' => wp_create_nonce( 'edss_connect' ),
			),
			admin_url( 'admin-post.php' )
		);
	}

	/* =========================================================
	 * Dashboard shortcode
	 * ========================================================= */

	public static function render() {
		wp_enqueue_style( 'edss-dashboard' ); // Fallback when the shortcode is placed by a page builder.
		if ( ! is_user_logged_in() ) {
			return '<div class="edss-dash"><p>Please <a href="' . esc_url( wp_login_url( get_permalink() ) ) . '">log in</a> to see your earnings.</p></div>';
		}
		$uid = self::current_educator();
		if ( ! $uid ) {
			return '<div class="edss-dash"><p>This page is for vendors.</p></div>';
		}

		$here    = get_permalink();
		$acct_id = EDSS_Resolver::educator_account( $uid );
		$test    = EDSS_Settings::is_test_mode();
		$flag    = isset( $_GET['edss_stripe'] ) ? sanitize_key( $_GET['edss_stripe'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification

		$status = null;
		if ( $acct_id ) {
			$acct = EDSS_Stripe::get_account( $acct_id, 'return' === $flag );
			if ( ! is_wp_error( $acct ) ) {
				$status = EDSS_Stripe::summarize_account( $acct );
				update_user_meta( $uid, 'edss_status_' . EDSS_Settings::mode_label(), $status );
			}
		}

		ob_start();
		?>
		<div class="edss-dash">

			<?php if ( $test ) : ?>
				<p class="edss-muted"><strong>Test mode</strong> — amounts below are test payments, not real money.</p>
			<?php endif; ?>
			<?php if ( 'expired' === $flag ) : ?>
				<p class="edss-warn">That link expired — please click the button again.</p>
			<?php endif; ?>

			<div class="edss-card">
				<h3 style="margin-top:0">Stripe payouts</h3>
				<?php
				if ( ! $acct_id ) {
					if ( 'yes' === EDSS_Settings::get( 'onboarding' ) ) {
						echo '<p>Connect a Stripe account to receive your share of every sale and renewal automatically.</p>';
						echo '<a class="edss-btn" href="' . esc_url( self::connect_url( $here ) ) . '">Connect Stripe</a>';
					} else {
						echo '<p>Your payout account has not been set up yet. Please contact the site team.</p>';
					}
				} elseif ( $status && 'active' === $status['transfers'] ) {
					echo '<p class="edss-ok">✓ Connected — your earnings are sent to Stripe automatically.</p>';
					if ( ! $status['payouts_enabled'] ) {
						echo '<p class="edss-warn">Stripe has paused payouts to your bank. Open Stripe to see what is needed.</p>';
					}
				} else {
					echo '<p class="edss-warn">Your Stripe setup is not finished yet, so payouts are on hold.</p>';
					if ( $status && $status['disabled_reason'] ) {
						echo '<p class="edss-muted">Stripe says: ' . esc_html( $status['disabled_reason'] ) . '</p>';
					}
					if ( 'yes' === EDSS_Settings::get( 'onboarding' ) ) {
						echo '<a class="edss-btn" href="' . esc_url( self::connect_url( $here ) ) . '">Finish Stripe setup</a> ';
					}
				}
				if ( $acct_id ) {
					$login = add_query_arg(
						array(
							'action'   => 'edss_stripe_login',
							'return'   => rawurlencode( $here ),
							'_wpnonce' => wp_create_nonce( 'edss_stripe_login' ),
						),
						admin_url( 'admin-post.php' )
					);
					echo ' <a class="edss-btn edss-secondary" href="' . esc_url( $login ) . '">Open my Stripe dashboard</a>';
					echo '<p class="edss-muted" style="margin-bottom:0">Your earnings arrive in your Stripe balance; Stripe then pays them out to your bank on its payout schedule.</p>';
				}
				?>
			</div>

			<?php echo wp_kses_post( self::earnings_html( $uid, $test ) ); ?>
		</div>
		<?php
		return ob_get_clean();
	}

	private static function earnings_html( $uid, $test ) {
		$totals = EDSS_Ledger::educator_totals( $uid, $test );
		$rows   = EDSS_Ledger::educator_rows( $uid, $test, 50 );

		$paid    = array();
		$month   = array();
		$waiting = array();
		foreach ( $totals as $t ) {
			$c = $t['currency'];
			if ( in_array( $t['status'], array( 'transferred', 'partially_reversed', 'reversed' ), true ) ) {
				$paid[ $c ]  = ( $paid[ $c ] ?? 0 ) + (int) $t['net_minor'];
				$month[ $c ] = ( $month[ $c ] ?? 0 ) + (int) $t['net_minor_month'];
			} elseif ( in_array( $t['status'], array( 'held', 'failed', 'pending', 'processing' ), true ) ) {
				$waiting[ $c ] = ( $waiting[ $c ] ?? 0 ) + (int) $t['net_minor'];
			}
		}
		$fmt = function ( $by_currency ) {
			if ( ! $by_currency ) {
				return '0';
			}
			$parts = array();
			foreach ( $by_currency as $c => $minor ) {
				$parts[] = EDSS_Stripe::format( $minor, $c );
			}
			return implode( ' + ', $parts );
		};

		$labels = array(
			'transferred'        => 'Paid',
			'partially_reversed' => 'Paid (part refunded)',
			'reversed'           => 'Refunded',
			'held'               => 'On hold',
			'failed'             => 'Retrying',
			'pending'            => 'Processing',
			'processing'         => 'Processing',
			'dry_run'            => 'Test calculation',
			'unmapped'           => 'Needs admin review',
			'skipped'            => 'Not paid',
		);

		ob_start();
		?>
		<div class="edss-stats">
			<div class="edss-stat"><span class="edss-muted">Paid this month</span><b><?php echo esc_html( $fmt( $month ) ); ?></b></div>
			<div class="edss-stat"><span class="edss-muted">Paid all time</span><b><?php echo esc_html( $fmt( $paid ) ); ?></b></div>
			<div class="edss-stat"><span class="edss-muted">Waiting</span><b><?php echo esc_html( $fmt( $waiting ) ); ?></b></div>
		</div>
		<div class="edss-card">
			<h3 style="margin-top:0">Recent earnings</h3>
			<?php if ( ! $rows ) : ?>
				<p class="edss-muted">No sales yet.</p>
			<?php else : ?>
				<div class="edss-scroll"><table>
					<thead><tr><th>Date</th><th>Course</th><th>Type</th><th>Your share</th><th>Status</th></tr></thead>
					<tbody>
					<?php foreach ( $rows as $r ) : ?>
						<tr>
							<td><?php echo esc_html( $r['created_at'] ? get_date_from_gmt( $r['created_at'], get_option( 'date_format' ) ) : '' ); ?></td>
							<td><?php echo esc_html( $r['course_id'] ? get_the_title( $r['course_id'] ) : get_the_title( $r['product_id'] ) ); ?></td>
							<td><?php echo $r['is_renewal'] ? 'Renewal' : 'New sale'; ?></td>
							<td><?php echo esc_html( EDSS_Stripe::format( (int) $r['educator_minor'] - (int) $r['reversed_minor'], $r['currency'] ) ); ?></td>
							<td><?php echo esc_html( $labels[ $r['status'] ] ?? $r['status'] ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table></div>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}
}
