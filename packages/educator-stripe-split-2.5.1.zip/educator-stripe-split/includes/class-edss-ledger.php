<?php
/**
 * Audit ledger: one row per paid order line item (initial order or renewal order).
 * The unique idem_key (order + line item) is what makes duplicate webhooks/automation runs harmless.
 */

defined( 'ABSPATH' ) || exit;

class EDSS_Ledger {

	/** Text column sizes. A value longer than its column makes $wpdb refuse the whole write, so update() trims to fit. */
	const MAX_LEN = array(
		'idem_key'       => 80,
		'account_id'     => 64,
		'currency'       => 3,
		'split_type'     => 10,
		'split_source'   => 20,
		'status'         => 20,
		'transfer_id'    => 64,
		'charge_id'      => 64,
		'webhook_status' => 190,
	);

	const INT_COLS = array( 'id', 'order_id', 'item_id', 'parent_order_id', 'subscription_id', 'is_renewal', 'product_id', 'course_id', 'educator_id', 'gross_minor', 'educator_minor', 'platform_minor', 'reversed_minor', 'attempts', 'test_mode' );

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'edss_ledger';
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table   = self::table();
		$collate = $wpdb->get_charset_collate();

		dbDelta(
			"CREATE TABLE $table (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  idem_key varchar(80) NOT NULL,
  order_id bigint(20) unsigned NOT NULL DEFAULT 0,
  item_id bigint(20) unsigned NOT NULL DEFAULT 0,
  parent_order_id bigint(20) unsigned NOT NULL DEFAULT 0,
  subscription_id bigint(20) unsigned NOT NULL DEFAULT 0,
  is_renewal tinyint(1) NOT NULL DEFAULT 0,
  product_id bigint(20) unsigned NOT NULL DEFAULT 0,
  course_id bigint(20) unsigned NOT NULL DEFAULT 0,
  educator_id bigint(20) unsigned NOT NULL DEFAULT 0,
  account_id varchar(64) NOT NULL DEFAULT '',
  currency varchar(3) NOT NULL DEFAULT '',
  gross_minor bigint(20) NOT NULL DEFAULT 0,
  split_type varchar(10) NOT NULL DEFAULT '',
  split_value decimal(14,4) NOT NULL DEFAULT 0,
  split_source varchar(20) NOT NULL DEFAULT '',
  educator_minor bigint(20) NOT NULL DEFAULT 0,
  platform_minor bigint(20) NOT NULL DEFAULT 0,
  status varchar(20) NOT NULL DEFAULT 'pending',
  transfer_id varchar(64) NOT NULL DEFAULT '',
  charge_id varchar(64) NOT NULL DEFAULT '',
  reversed_minor bigint(20) NOT NULL DEFAULT 0,
  reversal_ids text NULL,
  attempts int(11) NOT NULL DEFAULT 0,
  last_error text NULL,
  webhook_status varchar(190) NOT NULL DEFAULT '',
  test_mode tinyint(1) NOT NULL DEFAULT 0,
  created_at datetime NULL DEFAULT NULL,
  updated_at datetime NULL DEFAULT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY idem_key (idem_key),
  KEY order_id (order_id),
  KEY status (status),
  KEY educator_id (educator_id)
) $collate;"
		);

		update_option( 'edss_db_version', EDSS_DB_VERSION );
	}

	public static function maybe_upgrade() {
		if ( EDSS_DB_VERSION !== get_option( 'edss_db_version' ) ) {
			self::install();
		}
	}

	private static function format_for( $col ) {
		return in_array( $col, self::INT_COLS, true ) ? '%d' : '%s';
	}

	/*
	 * The ledger is a custom table, so $wpdb is the only way to read and write it, and it is deliberately never
	 * cached: payout decisions must always see the current row. Every query below is prepared, with the table
	 * name passed through the %i identifier placeholder.
	 */
	// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

	public static function get( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id = %d', self::table(), $id ), ARRAY_A );
	}

	public static function get_by_key( $key ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE idem_key = %s', self::table(), $key ), ARRAY_A );
	}

	public static function for_order( $order_id ) {
		global $wpdb;
		return (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE order_id = %d ORDER BY id ASC', self::table(), $order_id ), ARRAY_A );
	}

	/**
	 * INSERT IGNORE on the unique key, then return whichever row won.
	 */
	public static function create_if_missing( $key, $data ) {
		global $wpdb;
		$now = current_time( 'mysql', true );
		$wpdb->query(
			$wpdb->prepare(
				'INSERT IGNORE INTO %i
					(idem_key, order_id, item_id, parent_order_id, subscription_id, is_renewal, product_id, currency, test_mode, status, created_at, updated_at)
				 VALUES (%s, %d, %d, %d, %d, %d, %d, %s, %d, %s, %s, %s)',
				self::table(),
				$key,
				(int) ( $data['order_id'] ?? 0 ),
				(int) ( $data['item_id'] ?? 0 ),
				(int) ( $data['parent_order_id'] ?? 0 ),
				(int) ( $data['subscription_id'] ?? 0 ),
				(int) ( $data['is_renewal'] ?? 0 ),
				(int) ( $data['product_id'] ?? 0 ),
				(string) ( $data['currency'] ?? '' ),
				(int) ( $data['test_mode'] ?? 0 ),
				'pending',
				$now,
				$now
			)
		);
		return self::get_by_key( $key );
	}

	public static function update( $id, $data ) {
		global $wpdb;
		$data['updated_at'] = current_time( 'mysql', true );
		foreach ( self::MAX_LEN as $col => $max ) {
			if ( isset( $data[ $col ] ) && is_string( $data[ $col ] ) && strlen( $data[ $col ] ) > $max ) {
				$data[ $col ] = substr( $data[ $col ], 0, $max );
			}
		}
		return $wpdb->update(
			self::table(),
			$data,
			array( 'id' => (int) $id ),
			array_map( array( __CLASS__, 'format_for' ), array_keys( $data ) ),
			array( '%d' )
		);
	}

	/**
	 * Atomically move a row into 'processing'. Only one PHP process can win, so two simultaneous
	 * events for the same order can never both send a transfer. Rows waiting to be (re)processed can be
	 * claimed, and so can a 'processing' row older than 15 minutes (crashed run).
	 */
	public static function claim( $id ) {
		global $wpdb;
		$claimed = $wpdb->query(
			$wpdb->prepare(
				"UPDATE %i SET status = 'processing', updated_at = %s
				 WHERE id = %d AND ( status IN ('pending','held','failed','unmapped') OR ( status = 'processing' AND updated_at < %s ) )",
				self::table(),
				current_time( 'mysql', true ),
				(int) $id,
				gmdate( 'Y-m-d H:i:s', time() - 15 * MINUTE_IN_SECONDS )
			)
		);
		return 1 === (int) $claimed;
	}

	/**
	 * Orders with splits that should be retried by the hourly sweep.
	 */
	public static function orders_needing_retry( $max_attempts, $limit = 50 ) {
		global $wpdb;
		return array_map(
			'intval',
			(array) $wpdb->get_col(
				$wpdb->prepare(
					"SELECT DISTINCT order_id FROM %i WHERE status = 'held'
					 OR ( status = 'failed' AND attempts < %d )
					 OR ( status IN ('processing','pending') AND updated_at < %s )
					 ORDER BY order_id ASC LIMIT %d",
					self::table(),
					$max_attempts,
					gmdate( 'Y-m-d H:i:s', time() - 15 * MINUTE_IN_SECONDS ),
					$limit
				)
			)
		);
	}

	/**
	 * Paged list for the Payouts screen. Each filter is optional: an empty status / zero ID matches everything.
	 */
	public static function query( $args ) {
		global $wpdb;
		$status   = (string) ( $args['status'] ?? '' );
		$order_id = (int) ( $args['order_id'] ?? 0 );
		$educator = (int) ( $args['educator_id'] ?? 0 );
		$limit    = max( 1, (int) ( $args['per_page'] ?? 50 ) );
		$offset   = ( max( 1, (int) ( $args['page'] ?? 1 ) ) - 1 ) * $limit;

		$total = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM %i WHERE ( %s = '' OR status = %s ) AND ( %d = 0 OR order_id = %d ) AND ( %d = 0 OR educator_id = %d )",
				self::table(),
				$status,
				$status,
				$order_id,
				$order_id,
				$educator,
				$educator
			)
		);
		$rows  = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM %i WHERE ( %s = '' OR status = %s ) AND ( %d = 0 OR order_id = %d ) AND ( %d = 0 OR educator_id = %d )
				 ORDER BY id DESC LIMIT %d OFFSET %d",
				self::table(),
				$status,
				$status,
				$order_id,
				$order_id,
				$educator,
				$educator,
				$limit,
				$offset
			),
			ARRAY_A
		);

		return array( $rows ? $rows : array(), $total );
	}

	/** Per currency + status: net (after reversals) all time and since the 1st of this month (UTC). */
	public static function educator_totals( $educator_id, $test_mode ) {
		global $wpdb;
		return (array) $wpdb->get_results(
			$wpdb->prepare(
				'SELECT currency, status,
					SUM(educator_minor - reversed_minor) AS net_minor,
					SUM(CASE WHEN created_at >= %s THEN educator_minor - reversed_minor ELSE 0 END) AS net_minor_month
				 FROM %i WHERE educator_id = %d AND test_mode = %d GROUP BY currency, status',
				gmdate( 'Y-m-01 00:00:00' ),
				self::table(),
				$educator_id,
				$test_mode ? 1 : 0
			),
			ARRAY_A
		);
	}

	/** Net amount paid to all vendors since the 1st of this month (UTC), per currency. */
	public static function month_paid( $test_mode ) {
		global $wpdb;
		$out  = array();
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT currency, SUM(educator_minor - reversed_minor) AS net FROM %i
				 WHERE test_mode = %d AND status IN ('transferred','partially_reversed','reversed') AND created_at >= %s GROUP BY currency",
				self::table(),
				$test_mode ? 1 : 0,
				gmdate( 'Y-m-01 00:00:00' )
			),
			ARRAY_A
		);
		foreach ( (array) $rows as $r ) {
			$out[ $r['currency'] ] = (int) $r['net'];
		}
		return $out;
	}

	public static function attention_rows( $test_mode, $limit = 10 ) {
		global $wpdb;
		return (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM %i WHERE test_mode = %d AND status IN ('unmapped','failed','held') ORDER BY id DESC LIMIT %d",
				self::table(),
				$test_mode ? 1 : 0,
				$limit
			),
			ARRAY_A
		);
	}

	public static function educator_rows( $educator_id, $test_mode, $limit = 50 ) {
		global $wpdb;
		return (array) $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM %i WHERE educator_id = %d AND test_mode = %d ORDER BY id DESC LIMIT %d',
				self::table(),
				$educator_id,
				$test_mode ? 1 : 0,
				$limit
			),
			ARRAY_A
		);
	}

	/** Rows per status; pass true/false to count only test-mode / live-mode rows, null for all. */
	public static function status_counts( $test_mode = null ) {
		global $wpdb;
		$out  = array();
		$mode = null === $test_mode ? -1 : ( $test_mode ? 1 : 0 );
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT status, COUNT(*) AS c FROM %i WHERE ( %d = -1 OR test_mode = %d ) GROUP BY status',
				self::table(),
				$mode,
				$mode
			),
			ARRAY_A
		);
		foreach ( (array) $rows as $r ) {
			$out[ $r['status'] ] = (int) $r['c'];
		}
		return $out;
	}

	// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
}
