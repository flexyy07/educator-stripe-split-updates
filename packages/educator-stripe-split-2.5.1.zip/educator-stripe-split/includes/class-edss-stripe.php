<?php
/**
 * Minimal server-side Stripe API client (no SDK dependency).
 */

defined( 'ABSPATH' ) || exit;

class EDSS_Stripe {

	const API = 'https://api.stripe.com/v1/';

	const ZERO_DECIMAL = array( 'bif', 'clp', 'djf', 'gnf', 'jpy', 'kmf', 'krw', 'mga', 'pyg', 'rwf', 'ugx', 'vnd', 'vuv', 'xaf', 'xof', 'xpf' );

	/**
	 * @return array|WP_Error Decoded Stripe object, or WP_Error with data['stripe_code'].
	 */
	public static function request( $method, $path, $params = array(), $idempotency_key = '' ) {
		$key  = EDSS_Settings::secret_key();
		$test = EDSS_Settings::is_test_mode();

		if ( '' === $key ) {
			return new WP_Error( 'edss_no_key', sprintf( 'No Stripe %s secret key configured.', $test ? 'test' : 'live' ) );
		}
		$is_test_key = 0 === strpos( $key, 'sk_test_' ) || 0 === strpos( $key, 'rk_test_' );
		$is_live_key = 0 === strpos( $key, 'sk_live_' ) || 0 === strpos( $key, 'rk_live_' );
		if ( ( $test && ! $is_test_key ) || ( ! $test && ! $is_live_key ) ) {
			return new WP_Error( 'edss_key_mode', sprintf( 'Stripe key does not match %s mode.', $test ? 'test' : 'live' ) );
		}

		$url  = self::API . ltrim( $path, '/' );
		$args = array(
			'method'  => $method,
			'timeout' => 45,
			'headers' => array( 'Authorization' => 'Bearer ' . $key ),
		);

		if ( 'GET' === $method ) {
			if ( $params ) {
				$url .= '?' . http_build_query( $params, '', '&' );
			}
		} else {
			$args['headers']['Content-Type'] = 'application/x-www-form-urlencoded';
			$args['body']                    = http_build_query( $params, '', '&' );
			if ( '' !== $idempotency_key ) {
				$args['headers']['Idempotency-Key'] = substr( $idempotency_key, 0, 255 );
			}
		}

		$response = wp_remote_request( $url, $args );
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( $code >= 200 && $code < 300 && is_array( $body ) ) {
			return $body;
		}

		$err     = ( is_array( $body ) && isset( $body['error'] ) ) ? $body['error'] : array();
		$message = isset( $err['message'] ) ? $err['message'] : 'Stripe HTTP ' . $code;
		if ( false !== strpos( $message, "platform's connected accounts" ) ) {
			// Seen when the key comes from WooCommerce Stripe's app connection, which cannot manage your own Connect accounts.
			$message .= ' Fix: in Vendor Splits → Settings choose "Use the keys below" and paste the secret key from Stripe → Developers → API keys of the account that owns the vendors.';
		}
		return new WP_Error(
			'edss_stripe',
			$message,
			array(
				'status'      => $code,
				'stripe_code' => $err['code'] ?? '',
				'type'        => $err['type'] ?? '',
			)
		);
	}

	/* ---------- money helpers ---------- */

	public static function decimals( $currency ) {
		return in_array( strtolower( (string) $currency ), self::ZERO_DECIMAL, true ) ? 0 : 2;
	}

	public static function to_minor( $amount, $currency ) {
		return (int) round( (float) $amount * pow( 10, self::decimals( $currency ) ) );
	}

	public static function from_minor( $minor, $currency ) {
		$d = self::decimals( $currency );
		return round( (int) $minor / pow( 10, $d ), $d );
	}

	public static function format( $minor, $currency ) {
		$d = self::decimals( $currency );
		return number_format( (int) $minor / pow( 10, $d ), $d ) . ' ' . strtoupper( (string) $currency );
	}

	/* ---------- connected accounts ---------- */

	public static function get_account( $account_id, $fresh = false ) {
		$cache_key = 'edss_acct_' . EDSS_Settings::mode_label() . '_' . $account_id;
		if ( ! $fresh ) {
			$cached = get_transient( $cache_key );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}
		$acct = self::request( 'GET', 'accounts/' . rawurlencode( $account_id ) );
		if ( ! is_wp_error( $acct ) ) {
			set_transient( $cache_key, $acct, 10 * MINUTE_IN_SECONDS );
		}
		return $acct;
	}

	/**
	 * @return true|WP_Error True when the connected account can receive transfers right now.
	 */
	public static function account_eligibility( $account_id, $fresh = false ) {
		$acct = self::get_account( $account_id, $fresh );
		if ( is_wp_error( $acct ) ) {
			return $acct;
		}
		$transfers = $acct['capabilities']['transfers'] ?? '';
		if ( 'active' === $transfers ) {
			return true;
		}
		$reason = $acct['requirements']['disabled_reason'] ?? '';
		return new WP_Error(
			'edss_account_inactive',
			sprintf(
				'Connected account %s cannot receive transfers yet (transfers capability: %s%s).',
				$account_id,
				$transfers ? $transfers : 'none',
				$reason ? ', reason: ' . $reason : ''
			)
		);
	}

	public static function summarize_account( $acct ) {
		return array(
			'transfers'       => $acct['capabilities']['transfers'] ?? 'none',
			'payouts_enabled' => ! empty( $acct['payouts_enabled'] ),
			'disabled_reason' => $acct['requirements']['disabled_reason'] ?? '',
			'currently_due'   => count( (array) ( $acct['requirements']['currently_due'] ?? array() ) ),
			'checked_at'      => time(),
		);
	}

	/* ---------- charges / transfers ---------- */

	/**
	 * The Stripe charge behind a WooCommerce order, used as source_transaction so the transfer is funded by
	 * that exact charge (works even while the charge funds are still pending in the platform balance).
	 */
	public static function charge_id_for_order( $order ) {
		if ( 0 !== strpos( (string) $order->get_payment_method(), 'stripe' ) ) {
			return '';
		}
		$txn = (string) $order->get_transaction_id();
		if ( preg_match( '/^(ch|py)_/', $txn ) ) {
			return $txn;
		}
		$intent_id = preg_match( '/^pi_/', $txn ) ? $txn : (string) $order->get_meta( '_stripe_intent_id' );
		if ( ! preg_match( '/^pi_/', $intent_id ) ) {
			return '';
		}
		$intent = self::request( 'GET', 'payment_intents/' . rawurlencode( $intent_id ) );
		if ( is_wp_error( $intent ) ) {
			return '';
		}
		if ( ! empty( $intent['latest_charge'] ) ) {
			return is_array( $intent['latest_charge'] ) ? (string) $intent['latest_charge']['id'] : (string) $intent['latest_charge'];
		}
		// Older Stripe API versions expose charges as a list on the intent.
		return (string) ( $intent['charges']['data'][0]['id'] ?? '' );
	}

	/**
	 * Look for a transfer this site already created for a ledger key (guards against double-paying after a
	 * crash/timeout where Stripe succeeded but WordPress never recorded it).
	 *
	 * @param int    $order_id Order the transfer belongs to.
	 * @param string $key      Ledger key.
	 * @return array|null|WP_Error
	 */
	public static function find_transfer( $order_id, $key ) {
		$groups = array( 'EDSS_ORDER_' . $order_id );
		$site   = EDSS_Settings::site_tag();

		foreach ( $groups as $group ) {
			$res = self::request(
				'GET',
				'transfers',
				array(
					'transfer_group' => $group,
					'limit'          => 100,
				)
			);
			if ( is_wp_error( $res ) ) {
				return $res;
			}
			foreach ( (array) ( $res['data'] ?? array() ) as $tr ) {
				$meta    = (array) ( $tr['metadata'] ?? array() );
				$tr_key  = $meta['edss_key'] ?? '';
				$tr_site = $meta['edss_site'] ?? '';
				if ( $tr_key === $key && $tr_site === $site ) {
					return $tr;
				}
			}
		}
		return null;
	}
}
