<?php
/**
 * Plugin updates from the public release feed EDSS_UPDATE_REPO (info.json + packages/*.zip on its main branch).
 *
 * WordPress shows "Update now" (and allows auto-updates) whenever info.json names a version newer than
 * EDSS_VERSION. No key or token is needed.
 */

defined( 'ABSPATH' ) || exit;

class EDSS_Updater {

	const SLUG  = 'educator-stripe-split';
	const CACHE = 'edss_update_release';

	public static function init() {
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'inject' ) );
		add_filter( 'plugins_api', array( __CLASS__, 'info' ), 20, 3 );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'flush' ) );
		add_filter( 'upgrader_pre_download', array( __CLASS__, 'download' ), 5, 2 );
	}

	/**
	 * Tries the real download and throws the file away.
	 *
	 * @return true|WP_Error
	 */
	public static function test_download( $package ) {
		$file = self::download( false, $package );
		if ( is_wp_error( $file ) ) {
			return new WP_Error( 'edss_update', (string) $file->get_error_data() );
		}
		if ( is_string( $file ) ) {
			wp_delete_file( $file );
			return true;
		}
		return new WP_Error( 'edss_update', 'The package address is not on the update feed.' );
	}

	public static function flush() {
		delete_transient( self::CACHE );
		delete_transient( self::CACHE . '_readme' );
	}

	private static function base() {
		return 'https://raw.githubusercontent.com/' . EDSS_UPDATE_REPO . '/main/';
	}

	/** The same files from a second, independent host, used when the first one cannot be reached from this server. */
	private static function mirror() {
		return 'https://cdn.jsdelivr.net/gh/' . EDSS_UPDATE_REPO . '@main/';
	}

	/** Header names another plugin added to one of our requests (names only, never values); for error messages. */
	private static $foreign_headers = array();

	/**
	 * Runs last on our own feed requests. The feed is public, so credentials never belong on these requests: some
	 * plugins attach their own Authorization header to every download, which makes the host refuse the file.
	 */
	public static function clean_request( $args, $url ) {
		if ( 0 !== strpos( (string) $url, self::base() ) && 0 !== strpos( (string) $url, self::mirror() ) ) {
			return $args;
		}
		$headers = isset( $args['headers'] ) && is_array( $args['headers'] ) ? $args['headers'] : array();
		foreach ( array_keys( $headers ) as $name ) {
			if ( in_array( strtolower( (string) $name ), array( 'authorization', 'cookie', 'proxy-authorization', 'private-token' ), true ) ) {
				self::$foreign_headers[] = (string) $name;
				unset( $headers[ $name ] );
			}
		}
		$args['headers'] = $headers;
		$args['cookies'] = array();
		return $args;
	}

	/** GET one of our feed files with a clean request. */
	private static function fetch( $url, $args = array() ) {
		add_filter( 'http_request_args', array( __CLASS__, 'clean_request' ), PHP_INT_MAX, 2 );
		$res = wp_safe_remote_get(
			$url,
			array_merge(
				array(
					'timeout' => 20,
					'headers' => array( 'User-Agent' => self::SLUG ),
				),
				$args
			)
		);
		remove_filter( 'http_request_args', array( __CLASS__, 'clean_request' ), PHP_INT_MAX );
		return $res;
	}

	/**
	 * Downloads our package ourselves: clean request, primary host then mirror, and the file must really be a zip.
	 * If every source fails, the message says exactly what each one answered.
	 *
	 * @return string|WP_Error|mixed Temp file path, error, or the untouched $reply for other plugins' packages.
	 */
	public static function download( $reply, $package ) {
		if ( false !== $reply || ! defined( 'EDSS_UPDATE_REPO' ) || 0 !== strpos( (string) $package, self::base() ) ) {
			return $reply;
		}
		if ( ! function_exists( 'wp_tempnam' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$path    = substr( (string) $package, strlen( self::base() ) );
		$sources = array( self::base() . $path, self::mirror() . $path );
		$report  = array();

		foreach ( $sources as $url ) {
			self::$foreign_headers = array();
			$tmp                   = wp_tempnam( basename( $url ) );
			$res                   = self::fetch(
				$url,
				array(
					'timeout'  => 120,
					'stream'   => true,
					'filename' => $tmp,
				)
			);
			$host = (string) wp_parse_url( $url, PHP_URL_HOST );
			if ( is_wp_error( $res ) ) {
				$note = $res->get_error_message();
			} else {
				$code = (int) wp_remote_retrieve_response_code( $res );
				$head = is_readable( $tmp ) ? (string) file_get_contents( $tmp, false, null, 0, 2 ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions
				if ( 200 === $code && 'PK' === $head ) {
					return $tmp;
				}
				$note = 'HTTP ' . $code . ( 200 === $code ? ' but not a zip file' : '' );
				$auth = wp_remote_retrieve_header( $res, 'www-authenticate' );
				if ( $auth ) {
					$note .= ', asks for: ' . sanitize_text_field( is_array( $auth ) ? implode( ' ', $auth ) : $auth );
				}
			}
			if ( self::$foreign_headers ) {
				$note .= ' (removed header added by another plugin: ' . implode( ', ', array_unique( self::$foreign_headers ) ) . ')';
			}
			$report[] = $host . ': ' . $note;
			wp_delete_file( $tmp );
		}
		return new WP_Error( 'download_failed', 'Download failed.', implode( ' | ', $report ) );
	}

	/**
	 * Latest release, cached for 1 hour.
	 *
	 * @return array|WP_Error {version, package, notes, published}
	 */
	public static function latest( $force = false ) {
		if ( ! defined( 'EDSS_UPDATE_REPO' ) ) {
			return new WP_Error( 'edss_update', 'Updates are not configured for this copy of the plugin.' );
		}
		if ( ! $force ) {
			$cached = get_transient( self::CACHE );
			if ( is_array( $cached ) && isset( $cached['error'] ) ) {
				return new WP_Error( 'edss_update', $cached['error'] );
			}
			// Ignore data cached by older versions of this updater (they pointed somewhere else).
			if ( is_array( $cached ) && 0 === strpos( (string) ( $cached['package'] ?? '' ), self::base() ) ) {
				return $cached;
			}
		}

		// info.json and the zip are plain files (no redirect to a signed URL), fetched with a clean request.
		$base = self::base();
		$res  = self::fetch( $base . 'info.json' );
		if ( is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
			$alt = self::fetch( self::mirror() . 'info.json' );
			if ( ! is_wp_error( $alt ) && 200 === (int) wp_remote_retrieve_response_code( $alt ) ) {
				$res = $alt;
			}
		}
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$body = json_decode( wp_remote_retrieve_body( $res ), true );

		$error = '';
		if ( 200 !== $code || ! is_array( $body ) ) {
			$error = sprintf( 'The update server answered with HTTP %d. Please try again later.', $code );
		} elseif ( empty( $body['version'] ) || empty( $body['package'] ) || 0 !== strpos( (string) $body['package'], $base ) ) {
			$error = 'The update information is incomplete.'; // Only packages from our own feed are ever installed.
		}
		if ( $error ) {
			set_transient( self::CACHE, array( 'error' => $error ), HOUR_IN_SECONDS );
			return new WP_Error( 'edss_update', $error );
		}

		$data = array(
			'version'   => ltrim( (string) $body['version'], 'vV' ),
			'package'   => (string) $body['package'],
			'notes'     => (string) ( $body['notes'] ?? '' ),
			'published' => (string) ( $body['published'] ?? '' ),
		);
		set_transient( self::CACHE, $data, HOUR_IN_SECONDS );
		return $data;
	}

	private static function item( $release ) {
		$file = plugin_basename( EDSS_FILE );
		return (object) array(
			'id'           => $file,
			'slug'         => self::SLUG,
			'plugin'       => $file,
			'new_version'  => $release['version'],
			'url'          => '',
			'package'      => $release['package'],
			'icons'        => array(),
			'banners'      => array(),
			'tested'       => self::tested( self::readme_text() ),
			'requires_php' => '7.4',
		);
	}

	/** Like WordPress.org: "Tested up to: 7.1" in the readme covers every 7.1.x maintenance release. */
	private static function tested( $readme ) {
		$tested = preg_match( '/^Tested up to:\s*([0-9.]+)/mi', (string) $readme, $m ) ? $m[1] : '7.1';
		$wp     = (string) get_bloginfo( 'version' );
		return 0 === strpos( $wp, $tested . '.' ) ? $wp : $tested;
	}

	/** Adds our update to WordPress's plugin-update list. */
	public static function inject( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}
		$release = self::latest( ! empty( $_GET['force-check'] ) ); // phpcs:ignore WordPress.Security.NonceVerification -- core "Check again" link.
		if ( is_wp_error( $release ) ) {
			return $transient;
		}
		$file      = plugin_basename( EDSS_FILE );
		$header    = get_file_data( EDSS_FILE, array( 'Version' => 'Version' ) );
		$installed = ! empty( $header['Version'] ) ? $header['Version'] : EDSS_VERSION; // On disk, not the copy in memory.
		if ( version_compare( $release['version'], $installed, '>' ) ) {
			$transient->response[ $file ] = self::item( $release );
		} else {
			if ( isset( $transient->response[ $file ] ) ) {
				unset( $transient->response[ $file ] );
			}
			$transient->no_update[ $file ] = self::item( $release );
		}
		return $transient;
	}

	/** "View details" popup on the Plugins screen. */
	public static function info( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || self::SLUG !== $args->slug ) {
			return $result;
		}
		$release = self::latest();
		if ( is_wp_error( $release ) ) {
			return $result;
		}
		$readme   = self::readme_text();
		$sections = self::readme_sections( $readme );
		if ( empty( $sections['changelog'] ) ) {
			$sections['changelog'] = $release['notes'] ? '<p>' . nl2br( esc_html( $release['notes'] ) ) . '</p>' : '<p>No release notes.</p>';
		}
		$tested = self::tested( $readme );
		return (object) array(
			'name'          => 'Vendors Payment Split',
			'slug'          => self::SLUG,
			'version'       => $release['version'],
			'author'        => 'PayoutWorks',
			'requires'      => '6.5',
			'tested'        => $tested,
			'requires_php'  => '7.4',
			'last_updated'  => $release['published'],
			'sections'      => $sections,
			'download_link' => $release['package'],
		);
	}

	/** The newest readme.txt from the feed (so the popup describes the version being offered), else the local one. */
	private static function readme_text() {
		$cached = get_transient( self::CACHE . '_readme' );
		if ( is_string( $cached ) && '' !== $cached ) {
			return $cached;
		}
		$res  = self::fetch( self::base() . 'readme.txt' );
		$text = ( ! is_wp_error( $res ) && 200 === (int) wp_remote_retrieve_response_code( $res ) ) ? (string) wp_remote_retrieve_body( $res ) : '';
		if ( '' === $text && is_readable( EDSS_DIR . 'readme.txt' ) ) {
			$text = (string) file_get_contents( EDSS_DIR . 'readme.txt' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		set_transient( self::CACHE . '_readme', $text, 6 * HOUR_IN_SECONDS );
		return $text;
	}

	/**
	 * Turns readme.txt sections into the HTML tabs of the "View details" popup.
	 * Handles what our readme uses: paragraphs, "* " and "1. " lists, "= Heading =", **bold**, `code` and links.
	 */
	private static function readme_sections( $text ) {
		$map   = array(
			'description'                => 'description',
			'installation'               => 'installation',
			'frequently asked questions' => 'faq',
			'changelog'                  => 'changelog',
			'external services'          => 'other_notes',
		);
		$out   = array();
		$parts = preg_split( '/^==\s*(.+?)\s*==\s*$/m', str_replace( "\r\n", "\n", (string) $text ), -1, PREG_SPLIT_DELIM_CAPTURE );
		$count = count( $parts );
		for ( $i = 1; $i + 1 < $count; $i += 2 ) {
			$key = $map[ strtolower( trim( $parts[ $i ] ) ) ] ?? '';
			if ( $key ) {
				$out[ $key ] = self::to_html( trim( $parts[ $i + 1 ] ) );
			}
		}
		return $out;
	}

	private static function to_html( $body ) {
		$html  = '';
		$list  = '';
		$para  = array();
		$flush = function () use ( &$html, &$list, &$para ) {
			if ( $para ) {
				$html .= '<p>' . implode( ' ', $para ) . '</p>';
				$para  = array();
			}
			if ( $list ) {
				$html .= '</' . $list . '>';
				$list  = '';
			}
		};
		foreach ( explode( "\n", $body ) as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				$flush();
				continue;
			}
			if ( preg_match( '/^=\s*(.+?)\s*=$/', $line, $m ) ) {
				$flush();
				$html .= '<h4>' . self::inline( $m[1] ) . '</h4>';
				continue;
			}
			if ( preg_match( '/^(\*|\d+\.)\s+(.*)$/', $line, $m ) ) {
				$want = '*' === $m[1] ? 'ul' : 'ol';
				if ( $para ) {
					$html .= '<p>' . implode( ' ', $para ) . '</p>';
					$para  = array();
				}
				if ( $list !== $want ) {
					if ( $list ) {
						$html .= '</' . $list . '>';
					}
					$html .= '<' . $want . '>';
					$list  = $want;
				}
				$html .= '<li>' . self::inline( $m[2] ) . '</li>';
				continue;
			}
			if ( $list ) {
				$html .= '</' . $list . '>';
				$list  = '';
			}
			$para[] = self::inline( $line );
		}
		$flush();
		return $html;
	}

	private static function inline( $text ) {
		$text = esc_html( $text );
		$text = preg_replace( '/\*\*(.+?)\*\*/', '<strong>$1</strong>', $text );
		$text = preg_replace( '/`([^`]+)`/', '<code>$1</code>', $text );
		return make_clickable( $text );
	}
}
