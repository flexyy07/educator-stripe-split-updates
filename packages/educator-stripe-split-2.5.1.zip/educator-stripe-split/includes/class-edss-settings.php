<?php
/**
 * Plugin settings + Stripe key/mode resolution.
 */

defined( 'ABSPATH' ) || exit;

class EDSS_Settings {

	const OPTION = 'edss_settings';

	public static function defaults() {
		return array(
			// off = do nothing, dry_run = calculate + log only, live = send real Stripe transfers.
			'run_mode'               => 'dry_run',
			// woo = reuse the WooCommerce Stripe gateway keys + its test-mode switch, own = keys entered below.
			'key_source'             => 'woo',
			'own_mode'               => 'test',
			'own_test_secret_key'    => '',
			'own_live_secret_key'    => '',
			'default_split_type'     => 'percent',
			'default_split_value'    => '',
			// excl_tax = line total after discounts, before tax. incl_tax = plus line tax.
			'split_base'             => 'excl_tax',
			// Empty = auto: every known LMS course post type found on this site.
			'course_post_types'      => array(),
			'author_fallback'        => 'yes',
			'require_active_account' => 'yes',
			'use_source_transaction' => 'yes',
			// proportional = reverse the vendor transfer in proportion to the refund, none = leave it and alert.
			'refund_policy'          => 'proportional',
			'max_attempts'           => 10,
			'webhook_url'            => '',
			'webhook_secret'         => '',
			'webhook_events'         => array( 'transferred', 'dry_run', 'held', 'failed', 'unmapped', 'reversed', 'reversal_failed' ),
			'alert_email'            => get_option( 'admin_email' ),
			// Vendors may connect Stripe themselves from the [edss_educator_dashboard] page.
			'onboarding'             => 'yes',
			// Two-letter country for new vendor Stripe accounts; empty = same as the platform account.
			'account_country'        => '',
		);
	}

	public static function all() {
		$saved = get_option( self::OPTION, array() );
		return wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
	}

	public static function get( $key ) {
		$all = self::all();
		return isset( $all[ $key ] ) ? $all[ $key ] : null;
	}

	public static function woo_stripe_settings() {
		$s = get_option( 'woocommerce_stripe_settings', array() );
		return is_array( $s ) ? $s : array();
	}

	public static function is_test_mode() {
		if ( 'woo' === self::get( 'key_source' ) ) {
			$woo = self::woo_stripe_settings();
			return isset( $woo['testmode'] ) && 'yes' === $woo['testmode'];
		}
		return 'live' !== self::get( 'own_mode' );
	}

	public static function mode_label() {
		return self::is_test_mode() ? 'test' : 'live';
	}

	public static function secret_key() {
		$test = self::is_test_mode();
		if ( 'woo' === self::get( 'key_source' ) ) {
			$woo = self::woo_stripe_settings();
			$key = $test ? ( $woo['test_secret_key'] ?? '' ) : ( $woo['secret_key'] ?? '' );
		} else {
			$key = $test ? self::get( 'own_test_secret_key' ) : self::get( 'own_live_secret_key' );
		}
		return trim( (string) apply_filters( 'edss_secret_key', $key, $test ) );
	}

	public static function mask( $key ) {
		$key = (string) $key;
		if ( strlen( $key ) < 12 ) {
			return '' === $key ? '(not set)' : '••••';
		}
		return substr( $key, 0, 8 ) . '…' . substr( $key, -4 );
	}

	/**
	 * Short identifier for this WordPress install. Stamped on every transfer so a staging copy of the site
	 * sharing the same Stripe account can never adopt or collide with production transfers.
	 */
	public static function site_tag() {
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		return $host ? $host : 'site';
	}
}
