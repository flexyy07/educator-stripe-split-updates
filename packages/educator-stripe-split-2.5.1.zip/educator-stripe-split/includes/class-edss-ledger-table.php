<?php
/**
 * Admin list of every split (audit trail).
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class EDSS_Ledger_Table extends WP_List_Table {

	const STATUSES = array( 'transferred', 'dry_run', 'held', 'failed', 'unmapped', 'processing', 'pending', 'partially_reversed', 'reversed', 'skipped' );

	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'split',
				'plural'   => 'splits',
				'ajax'     => false,
			)
		);
	}

	public function get_columns() {
		return array(
			'created_at' => 'Date',
			'order'      => 'Order',
			'product'    => 'Course',
			'educator'   => 'Vendor',
			'amounts'    => 'Sale → Vendor gets / You keep',
			'status'     => 'Status',
			'stripe'     => 'Stripe reference',
			'actions'    => '',
		);
	}

	protected function get_views() {
		$counts  = EDSS_Ledger::status_counts();
		$current = isset( $_GET['status'] ) ? sanitize_key( $_GET['status'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$base    = admin_url( 'admin.php?page=edss' );
		$views   = array( 'all' => sprintf( '<a href="%s"%s>All <span class="count">(%d)</span></a>', esc_url( $base ), '' === $current ? ' class="current"' : '', array_sum( $counts ) ) );
		foreach ( self::STATUSES as $s ) {
			if ( empty( $counts[ $s ] ) ) {
				continue;
			}
			$views[ $s ] = sprintf( '<a href="%s"%s>%s <span class="count">(%d)</span></a>', esc_url( add_query_arg( 'status', $s, $base ) ), $current === $s ? ' class="current"' : '', esc_html( EDSS_Admin::status_label( $s ) ), $counts[ $s ] );
		}
		return $views;
	}

	public function prepare_items() {
		// phpcs:disable WordPress.Security.NonceVerification
		$per_page = 50;
		list( $rows, $total ) = EDSS_Ledger::query(
			array(
				'status'      => isset( $_GET['status'] ) ? sanitize_key( $_GET['status'] ) : '',
				'order_id'    => isset( $_GET['order_id'] ) ? absint( $_GET['order_id'] ) : 0,
				'educator_id' => isset( $_GET['educator_id'] ) ? absint( $_GET['educator_id'] ) : 0,
				'per_page'    => $per_page,
				'page'        => $this->get_pagenum(),
			)
		);
		// phpcs:enable
		$this->items           = $rows;
		$this->_column_headers = array( $this->get_columns(), array(), array() );
		$this->set_pagination_args(
			array(
				'total_items' => $total,
				'per_page'    => $per_page,
			)
		);
	}

	public function no_items() {
		echo 'No payouts yet. They appear here after someone buys (or renews) a course product.';
	}

	public function column_default( $row, $col ) {
		$c = $row['currency'];
		switch ( $col ) {
			case 'created_at':
				return esc_html( $row['created_at'] ? get_date_from_gmt( $row['created_at'], 'Y-m-d H:i' ) : '' ) . ( (int) $row['test_mode'] ? '<br><small>test mode</small>' : '' );

			case 'order':
				$order = wc_get_order( $row['order_id'] );
				$link  = $order ? sprintf( '<a href="%s">#%s</a>', esc_url( $order->get_edit_order_url() ), esc_html( $order->get_order_number() ) ) : '#' . (int) $row['order_id'];
				$extra = $row['is_renewal'] ? ' <span class="edss-pill">renewal</span>' : '';
				if ( $row['subscription_id'] ) {
					$extra .= '<br><small>subscription #' . (int) $row['subscription_id'] . '</small>';
				}
				return $link . $extra;

			case 'product':
				$out = $row['product_id'] ? esc_html( get_the_title( $row['product_id'] ) ) . ' <small>(#' . (int) $row['product_id'] . ')</small>' : '—';
				if ( $row['course_id'] ) {
					$out .= '<br><small>Course: ' . esc_html( get_the_title( $row['course_id'] ) ) . ' (#' . (int) $row['course_id'] . ')</small>';
				}
				return $out;

			case 'educator':
				if ( ! $row['educator_id'] ) {
					return '—';
				}
				$u = get_userdata( $row['educator_id'] );
				return esc_html( $u ? $u->display_name : '#' . $row['educator_id'] ) . '<br><code>' . esc_html( $row['account_id'] ? $row['account_id'] : 'no acct' ) . '</code>';

			case 'amounts':
				if ( ! $row['split_type'] ) {
					return '—';
				}
				$out = sprintf(
					'%s → <strong>%s</strong> / %s<br><small>%s rule from %s</small>',
					esc_html( EDSS_Stripe::format( $row['gross_minor'], $c ) ),
					esc_html( EDSS_Stripe::format( $row['educator_minor'], $c ) ),
					esc_html( EDSS_Stripe::format( $row['platform_minor'], $c ) ),
					esc_html( EDSS_Resolver::describe_rule( $row['split_type'], $row['split_value'], $c ) ),
					esc_html( EDSS_Resolver::source_label( $row['split_source'] ) )
				);
				if ( (int) $row['reversed_minor'] > 0 ) {
					$out .= '<br><small>Reversed: ' . esc_html( EDSS_Stripe::format( $row['reversed_minor'], $c ) ) . '</small>';
				}
				return $out;

			case 'status':
				$out = EDSS_Admin::status_badge( $row['status'] );
				if ( (int) $row['attempts'] > 0 ) {
					$out .= ' <small>(' . (int) $row['attempts'] . ' attempts)</small>';
				}
				if ( $row['last_error'] ) {
					$out .= '<br><small>' . esc_html( $row['last_error'] ) . '</small>';
				}
				return $out;

			case 'stripe':
				$out = $row['transfer_id'] ? '<code>' . esc_html( $row['transfer_id'] ) . '</code>' : '';
				if ( $row['charge_id'] ) {
					$out .= '<br><small>from ' . esc_html( $row['charge_id'] ) . '</small>';
				}
				if ( $row['webhook_status'] ) {
					$out .= '<br><small>Webhook: ' . esc_html( $row['webhook_status'] ) . '</small>';
				}
				return $out;

			case 'actions':
				return EDSS_Admin::row_actions_html( $row );
		}
		return '';
	}
}
