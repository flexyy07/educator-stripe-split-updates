<?php
/**
 * Payment → split → Stripe transfer pipeline.
 *
 * Every paid WooCommerce order — the first subscription payment AND every renewal order — is processed
 * line item by line item. Work runs in Action Scheduler (bundled with WooCommerce) so checkout is never slowed.
 */

defined( 'ABSPATH' ) || exit;

class EDSS_Processor {

	/** Statuses that may be (re)processed automatically. */
	const REPROCESSABLE = array( 'pending', 'held', 'failed', 'unmapped' );

	public static function init() {
		// Initial payments and renewals. Several of these fire for one payment; the ledger makes that harmless.
		add_action( 'woocommerce_payment_complete', array( __CLASS__, 'queue_order' ), 20 );
		add_action( 'woocommerce_order_status_processing', array( __CLASS__, 'queue_order' ), 20 );
		add_action( 'woocommerce_order_status_completed', array( __CLASS__, 'queue_order' ), 20 );
		add_action( 'woocommerce_subscription_renewal_payment_complete', array( __CLASS__, 'queue_renewal' ), 20, 2 );
		add_action( 'woocommerce_order_refunded', array( __CLASS__, 'queue_refund' ), 20, 2 );

		add_action( 'edss_process_order', array( __CLASS__, 'process_order' ) );
		add_action( 'edss_process_refund', array( __CLASS__, 'process_refund' ), 10, 2 );
		add_action( 'edss_sweep', array( __CLASS__, 'sweep' ) );
		add_action( 'init', array( __CLASS__, 'schedule_sweep' ), 20 );
	}

	/* =========================================================
	 * Queueing
	 * ========================================================= */

	private static function enqueue( $hook, $args ) {
		if ( function_exists( 'as_enqueue_async_action' ) ) {
			if ( function_exists( 'as_has_scheduled_action' ) && as_has_scheduled_action( $hook, $args, EDSS_GROUP ) ) {
				return;
			}
			as_enqueue_async_action( $hook, $args, EDSS_GROUP );
			return;
		}
		// No Action Scheduler (it ships with WooCommerce, so this is only a safety net): run it right away.
		if ( 'edss_process_refund' === $hook ) {
			self::process_refund( $args[0], $args[1] );
		} else {
			self::process_order( $args[0] );
		}
	}

	public static function queue_order( $order_id ) {
		$order_id = absint( $order_id );
		if ( ! $order_id || 'off' === EDSS_Settings::get( 'run_mode' ) ) {
			return;
		}
		self::enqueue( 'edss_process_order', array( $order_id ) );
	}

	public static function queue_renewal( $subscription, $last_order ) {
		self::queue_order( is_object( $last_order ) ? $last_order->get_id() : $last_order );
	}

	public static function queue_refund( $order_id, $refund_id ) {
		if ( 'off' === EDSS_Settings::get( 'run_mode' ) ) {
			return;
		}
		self::enqueue( 'edss_process_refund', array( absint( $order_id ), absint( $refund_id ) ) );
	}

	public static function schedule_sweep() {
		if ( get_transient( 'edss_sweep_checked' ) || ! function_exists( 'as_next_scheduled_action' ) ) {
			return;
		}
		if ( false === as_next_scheduled_action( 'edss_sweep', array(), EDSS_GROUP ) ) {
			as_schedule_recurring_action( time() + 300, HOUR_IN_SECONDS, 'edss_sweep', array(), EDSS_GROUP );
		}
		set_transient( 'edss_sweep_checked', 1, HOUR_IN_SECONDS );
	}

	/** Hourly: retry held (account not ready) and failed (API error) splits. */
	public static function sweep() {
		if ( 'off' === EDSS_Settings::get( 'run_mode' ) ) {
			return;
		}
		foreach ( EDSS_Ledger::orders_needing_retry( (int) EDSS_Settings::get( 'max_attempts' ) ) as $order_id ) {
			self::enqueue( 'edss_process_order', array( $order_id ) );
		}
	}

	/* =========================================================
	 * Order processing
	 * ========================================================= */

	private static function get_order( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || ! is_a( $order, 'WC_Order' ) || 'shop_order' !== $order->get_type() ) {
			return null;
		}
		return $order;
	}

	public static function process_order( $order_id ) {
		$mode = EDSS_Settings::get( 'run_mode' );
		if ( 'off' === $mode ) {
			return;
		}
		$order = self::get_order( $order_id );
		if ( ! $order ) {
			return;
		}

		// Payment failed / cancelled / fully refunded before we got to it: never send money.
		if ( ! $order->is_paid() ) {
			foreach ( EDSS_Ledger::for_order( $order->get_id() ) as $row ) {
				if ( in_array( $row['status'], self::REPROCESSABLE, true ) ) {
					EDSS_Ledger::update(
						$row['id'],
						array(
							'status'     => 'skipped',
							'last_error' => sprintf( 'Order is no longer paid (status: %s).', $order->get_status() ),
						)
					);
				}
			}
			return;
		}

		$ctx = self::subscription_context( $order );
		foreach ( $order->get_items( 'line_item' ) as $item ) {
			self::process_item( $order, $item, $ctx, $mode );
		}
	}

	private static function subscription_context( $order ) {
		$ctx = array(
			'is_renewal'    => 0,
			'subscriptions' => array(),
		);
		if ( function_exists( 'wcs_order_contains_renewal' ) && wcs_order_contains_renewal( $order ) ) {
			$ctx['is_renewal'] = 1;
		}
		if ( function_exists( 'wcs_get_subscriptions_for_order' ) ) {
			$ctx['subscriptions'] = array_values( (array) wcs_get_subscriptions_for_order( $order, array( 'order_type' => 'any' ) ) );
		}
		return $ctx;
	}

	/** One order can start several subscriptions — match the line item to its own subscription. */
	private static function subscription_for_item( $ctx, $item ) {
		$product_id   = (int) $item->get_product_id();
		$variation_id = (int) $item->get_variation_id();
		foreach ( $ctx['subscriptions'] as $sub ) {
			if ( method_exists( $sub, 'has_product' ) && ( $sub->has_product( $product_id ) || ( $variation_id && $sub->has_product( $variation_id ) ) ) ) {
				return $sub;
			}
		}
		return $ctx['subscriptions'] ? $ctx['subscriptions'][0] : null;
	}

	private static function process_item( $order, $item, $ctx, $mode ) {
		$base = 'o' . $order->get_id() . '-i' . $item->get_id();
		$map  = EDSS_Resolver::resolve( (int) $item->get_product_id() );

		// Non-course products (merch, etc.) or split switched off: ignored without creating ledger noise.
		if ( 'not_applicable' === $map['status'] ) {
			foreach ( EDSS_Ledger::for_order( $order->get_id() ) as $row ) {
				if ( (int) $row['item_id'] === (int) $item->get_id() && in_array( $row['status'], self::REPROCESSABLE, true ) ) {
					EDSS_Ledger::update(
						$row['id'],
						array(
							'status'     => 'skipped',
							'last_error' => $map['error'],
						)
					);
				}
			}
			return;
		}

		if ( 'ok' !== $map['status'] ) {
			self::process_payee( $order, $item, $ctx, $mode, $base, $map, null, $map['error'] );
			return;
		}

		$shares = self::shares( $order, $item, $map['payees'] );
		if ( is_wp_error( $shares ) ) {
			self::process_payee( $order, $item, $ctx, $mode, $base, $map, null, $shares->get_error_message() );
			return;
		}

		// One ledger row + one Stripe transfer per payee. The owning vendor keeps the original key, so rows
		// recorded before co-vendors existed are never paid twice.
		foreach ( $shares['payees'] as $i => $payee ) {
			$payee['gross_minor']    = $shares['gross_minor'];
			$payee['platform_minor'] = 0 === $i ? $shares['platform_minor'] : 0;
			$key                     = 0 === $i ? $base : $base . '-u' . (int) $payee['educator_id'];
			self::process_payee( $order, $item, $ctx, $mode, $key, $map, $payee, '' );
		}
	}

	private static function process_payee( $order, $item, $ctx, $mode, $key, $map, $payee, $error ) {
		$row = EDSS_Ledger::get_by_key( $key );
		if ( ! $row ) {
			$sub = self::subscription_for_item( $ctx, $item );
			$row = EDSS_Ledger::create_if_missing(
				$key,
				array(
					'order_id'        => $order->get_id(),
					'item_id'         => $item->get_id(),
					'parent_order_id' => $sub ? (int) $sub->get_parent_id() : 0,
					'subscription_id' => $sub ? (int) $sub->get_id() : 0,
					'is_renewal'      => $ctx['is_renewal'],
					'product_id'      => (int) $item->get_product_id(),
					'currency'        => $order->get_currency(),
					'test_mode'       => EDSS_Settings::is_test_mode() ? 1 : 0,
				)
			);
			if ( ! $row ) {
				return;
			}
		}

		// A row recorded in test mode must never turn into a real transfer after the site goes live.
		if ( (int) $row['test_mode'] !== ( EDSS_Settings::is_test_mode() ? 1 : 0 ) ) {
			if ( in_array( $row['status'], self::REPROCESSABLE, true ) ) {
				EDSS_Ledger::update(
					$row['id'],
					array(
						'status'     => 'skipped',
						'last_error' => sprintf( 'Recorded in %s mode; never processed in the other Stripe mode.', (int) $row['test_mode'] ? 'test' : 'live' ),
					)
				);
			}
			return;
		}

		$prev = $row['status'];
		if ( ! EDSS_Ledger::claim( $row['id'] ) ) {
			return; // Already done, or another process is on it.
		}

		$data = array(
			'product_id'  => (int) $item->get_product_id(),
			'course_id'   => (int) $map['course_id'],
			'educator_id' => (int) ( $payee ? $payee['educator_id'] : $map['educator_id'] ),
			'account_id'  => (string) ( $payee ? $payee['account_id'] : $map['account_id'] ),
		);

		if ( '' !== $error || ! $payee ) {
			$data['last_error'] = '' !== $error ? $error : 'No payee resolved.';
			self::finish( $row, $prev, 'unmapped', $data, $order );
			return;
		}

		$currency = $order->get_currency();
		$data    += array(
			'currency'       => $currency,
			'gross_minor'    => (int) $payee['gross_minor'],
			'split_type'     => $payee['split_type'],
			'split_value'    => (string) $payee['split_value'],
			'split_source'   => $payee['split_source'],
			'educator_minor' => (int) $payee['educator_minor'],
			'platform_minor' => (int) $payee['platform_minor'],
			'last_error'     => '',
		);

		if ( (int) $payee['educator_minor'] <= 0 ) {
			$data['last_error'] = 'Vendor share is zero for this line.';
			self::finish( $row, $prev, 'skipped', $data, $order );
			return;
		}

		if ( 'dry_run' === $mode ) {
			self::finish( $row, $prev, 'dry_run', $data, $order );
			return;
		}

		// Restricted / not-yet-onboarded vendor: hold and retry hourly.
		if ( 'yes' === EDSS_Settings::get( 'require_active_account' ) ) {
			$eligible = EDSS_Stripe::account_eligibility( $payee['account_id'] );
			if ( is_wp_error( $eligible ) ) {
				$data['last_error'] = $eligible->get_error_message();
				self::finish( $row, $prev, 'held', $data, $order );
				return;
			}
		}

		// Stripe succeeded last time but WordPress never recorded it? Adopt that transfer instead of paying twice.
		$existing = EDSS_Stripe::find_transfer( $order->get_id(), $key );
		if ( is_wp_error( $existing ) ) {
			self::fail( $row, $prev, $data, $order, 'Could not check for an existing transfer: ' . $existing->get_error_message() );
			return;
		}
		if ( $existing ) {
			$data['transfer_id'] = $existing['id'];
			$data['last_error']  = 'Adopted an existing Stripe transfer for this line (no new transfer sent).';
			self::finish( $row, $prev, 'transferred', $data, $order );
			return;
		}

		$charge = 'yes' === EDSS_Settings::get( 'use_source_transaction' ) ? EDSS_Stripe::charge_id_for_order( $order ) : '';

		$params = array(
			'amount'         => (int) $payee['educator_minor'],
			'currency'       => strtolower( $currency ),
			'destination'    => $payee['account_id'],
			'transfer_group' => 'EDSS_ORDER_' . $order->get_id(),
			'description'    => sprintf( 'Vendor share - order #%s, item %d', $order->get_order_number(), $item->get_id() ),
			'metadata'       => array(
				'edss_key'        => $key,
				'edss_site'       => EDSS_Settings::site_tag(),
				'order_id'        => (string) $order->get_id(),
				'item_id'         => (string) $item->get_id(),
				'product_id'      => (string) $item->get_product_id(),
				'course_id'       => (string) $map['course_id'],
				'educator_id'     => (string) $payee['educator_id'],
				'subscription_id' => (string) (int) $row['subscription_id'],
				'is_renewal'      => (string) (int) $row['is_renewal'],
			),
		);
		if ( $charge ) {
			$params['source_transaction'] = $charge;
			$data['charge_id']            = $charge;
		}

		// Same key for the same payout → Stripe returns the original transfer instead of creating another one.
		$idem = implode( '-', array( 'edss', EDSS_Settings::site_tag(), $key, $payee['account_id'], (int) $payee['educator_minor'], $charge ) );

		$transfer = EDSS_Stripe::request( 'POST', 'transfers', $params, $idem );
		if ( is_wp_error( $transfer ) ) {
			self::fail( $row, $prev, $data, $order, 'Stripe transfer failed: ' . $transfer->get_error_message() );
			return;
		}

		$data['transfer_id'] = $transfer['id'];
		self::finish( $row, $prev, 'transferred', $data, $order );
	}

	/**
	 * Gross = what the customer actually paid for this line (after coupons, minus anything already refunded).
	 */
	public static function line_gross( $order, $item ) {
		$total    = (float) $item->get_total();
		$tax      = (float) $item->get_total_tax();
		$refunded = abs( (float) $order->get_total_refunded_for_item( $item->get_id() ) );
		$ratio    = $total > 0 ? max( 0, ( $total - $refunded ) / $total ) : 0;
		$base     = 'incl_tax' === EDSS_Settings::get( 'split_base' ) ? $total + $tax : $total;
		return (int) round( EDSS_Stripe::to_minor( $base, $order->get_currency() ) * $ratio );
	}

	/**
	 * Each payee's amount for one order line. A single vendor is capped at the line total; with co-vendors,
	 * shares that add up to more than the line are refused (nothing is sent) so no one is short-paid silently.
	 *
	 * @return array|WP_Error {gross_minor, platform_minor, payees[] (+educator_minor)}
	 */
	public static function shares( $order, $item, $payees ) {
		$currency = $order->get_currency();
		$gross    = self::line_gross( $order, $item );
		$qty      = max( 1, (int) $item->get_quantity() );
		$total    = 0;
		$out      = array();

		foreach ( $payees as $p ) {
			$amount              = 'fixed' === $p['split_type']
				? EDSS_Stripe::to_minor( $p['split_value'], $currency ) * $qty
				: (int) round( $gross * (float) $p['split_value'] / 100 );
			$p['educator_minor'] = max( 0, $amount );
			$total              += $p['educator_minor'];
			$out[]               = $p;
		}

		if ( 1 === count( $out ) ) {
			$out[0]['educator_minor'] = min( $out[0]['educator_minor'], $gross ); // Never send more than was collected.
			$total                    = $out[0]['educator_minor'];
		} elseif ( $total > $gross ) {
			return new WP_Error(
				'edss_over_split',
				sprintf( 'Vendor shares add up to %s but this sale line is %s. Nothing was sent — fix the co-vendor rules.', EDSS_Stripe::format( $total, $currency ), EDSS_Stripe::format( $gross, $currency ) )
			);
		}

		return array(
			'gross_minor'    => $gross,
			'platform_minor' => $gross - $total,
			'payees'         => $out,
		);
	}

	private static function fail( $row, $prev, $data, $order, $message ) {
		$attempts           = (int) $row['attempts'] + 1;
		$max                = (int) EDSS_Settings::get( 'max_attempts' );
		$data['attempts']   = $attempts;
		$data['last_error'] = $message . ( $attempts >= $max ? sprintf( ' Gave up after %d attempts — use Retry in the ledger.', $attempts ) : '' );

		$fresh = self::finish( $row, $prev, 'failed', $data, $order );

		if ( $attempts < $max && function_exists( 'as_schedule_single_action' ) ) {
			$delay = min( 6 * HOUR_IN_SECONDS, 5 * MINUTE_IN_SECONDS * pow( 2, $attempts - 1 ) );
			as_schedule_single_action( time() + $delay, 'edss_process_order', array( (int) $order->get_id() ), EDSS_GROUP );
		} elseif ( 'failed' === $prev && $fresh ) {
			self::alert( $fresh, $order ); // Final failure after repeated retries.
		}
	}

	private static function finish( $row, $prev, $status, $data, $order ) {
		$data['status'] = $status;
		EDSS_Ledger::update( $row['id'], $data );
		$fresh = EDSS_Ledger::get( $row['id'] );

		if ( $fresh && $prev !== $status ) {
			$order->add_order_note( self::note_for( $fresh ) );
			if ( in_array( $status, array( 'failed', 'held', 'unmapped' ), true ) ) {
				self::alert( $fresh, $order );
			}
			EDSS_Notifier::queue( $fresh['id'], $status );
			do_action( 'edss_split_' . $status, $fresh, $order );
		}
		return $fresh;
	}

	public static function note_for( $row ) {
		$c   = $row['currency'];
		$amt = EDSS_Stripe::format( $row['educator_minor'], $c );
		$who = sprintf( 'vendor #%d (%s)', $row['educator_id'], $row['account_id'] );
		$tag = $row['is_renewal'] ? ' [renewal]' : '';

		switch ( $row['status'] ) {
			case 'transferred':
				return sprintf( 'Vendor split%s: %s sent to %s — Stripe transfer %s. Line gross %s, platform keeps %s (before Stripe fees).', $tag, $amt, $who, $row['transfer_id'], EDSS_Stripe::format( $row['gross_minor'], $c ), EDSS_Stripe::format( $row['platform_minor'], $c ) );
			case 'dry_run':
				return sprintf( 'Vendor split%s (DRY RUN — no money moved): would send %s to %s (%s rule from %s).', $tag, $amt, $who, EDSS_Resolver::describe_rule( $row['split_type'], $row['split_value'], $c ), EDSS_Resolver::source_label( $row['split_source'] ) );
			case 'held':
				return sprintf( 'Vendor split%s HELD: %s Will retry automatically every hour.', $tag, $row['last_error'] );
			case 'failed':
				return sprintf( 'Vendor split%s FAILED: %s', $tag, $row['last_error'] );
			case 'unmapped':
				return sprintf( 'Vendor split%s NOT SENT — mapping problem: %s', $tag, $row['last_error'] );
			default:
				return sprintf( 'Vendor split%s %s: %s', $tag, $row['status'], $row['last_error'] );
		}
	}

	public static function alert( $row, $order, $subject_suffix = '' ) {
		$to = EDSS_Settings::get( 'alert_email' );
		if ( ! $to ) {
			return;
		}
		$subject = sprintf( '[Vendor Splits] %s — order #%s%s', strtoupper( $row['status'] ), $order->get_order_number(), $subject_suffix );
		$body    = self::note_for( $row ) . "\n\n"
			. 'Order: ' . $order->get_edit_order_url() . "\n"
			. 'Ledger: ' . admin_url( 'admin.php?page=edss&order_id=' . (int) $row['order_id'] ) . "\n";
		wp_mail( $to, $subject, $body );
	}

	/* =========================================================
	 * Refunds
	 * ========================================================= */

	public static function process_refund( $order_id, $refund_id ) {
		$order  = self::get_order( $order_id );
		$refund = wc_get_order( $refund_id );
		if ( ! $order || ! $refund ) {
			return;
		}
		$rows = EDSS_Ledger::for_order( $order->get_id() );
		if ( ! $rows ) {
			return;
		}

		$incl_tax = 'incl_tax' === EDSS_Settings::get( 'split_base' );
		$by_item  = array();
		foreach ( $refund->get_items( 'line_item' ) as $ritem ) {
			$orig = (int) $ritem->get_meta( '_refunded_item_id' );
			if ( $orig ) {
				$amount            = abs( (float) $ritem->get_total() ) + ( $incl_tax ? abs( (float) $ritem->get_total_tax() ) : 0 );
				$by_item[ $orig ] = ( $by_item[ $orig ] ?? 0 ) + $amount;
			}
		}
		// Amount-only refund (no line items chosen): spread it across the order proportionally.
		$order_ratio = 0;
		if ( ! $by_item ) {
			$order_total = (float) $order->get_total();
			$order_ratio = $order_total > 0 ? min( 1, abs( (float) $refund->get_amount() ) / $order_total ) : 0;
		}

		$policy = EDSS_Settings::get( 'refund_policy' );
		$rkey   = 'r' . (int) $refund_id;

		foreach ( $rows as $row ) {
			if ( ! in_array( $row['status'], array( 'transferred', 'partially_reversed', 'dry_run' ), true ) ) {
				continue;
			}
			$done = json_decode( (string) $row['reversal_ids'], true );
			$done = is_array( $done ) ? $done : array();
			if ( isset( $done[ $rkey ] ) ) {
				continue; // This refund was already handled for this line.
			}

			if ( $by_item ) {
				if ( ! isset( $by_item[ (int) $row['item_id'] ] ) ) {
					continue;
				}
				$refunded = EDSS_Stripe::to_minor( $by_item[ (int) $row['item_id'] ], $row['currency'] );
				$ratio    = (int) $row['gross_minor'] > 0 ? min( 1, $refunded / (int) $row['gross_minor'] ) : 0;
			} else {
				$ratio = $order_ratio;
			}

			$remaining = (int) $row['educator_minor'] - (int) $row['reversed_minor'];
			$reverse   = min( (int) round( (int) $row['educator_minor'] * $ratio ), $remaining );
			if ( $reverse <= 0 ) {
				continue;
			}
			$label = EDSS_Stripe::format( $reverse, $row['currency'] );

			$simulated = 'dry_run' === $row['status'] || 'live' !== EDSS_Settings::get( 'run_mode' );
			if ( $simulated || 'none' === $policy ) {
				$done[ $rkey ] = $simulated ? 'dry_run' : 'policy_none';
				EDSS_Ledger::update( $row['id'], array( 'reversal_ids' => wp_json_encode( $done ) ) );
				if ( $simulated ) {
					$order->add_order_note( sprintf( 'Vendor split (DRY RUN — no money moved): refund #%d would reverse %s from %s.', $refund_id, $label, $row['account_id'] ) );
				} else {
					$order->add_order_note( sprintf( 'Vendor split: refund #%d — vendor share %s was NOT reversed (refund policy = none). Recover it manually if needed.', $refund_id, $label ) );
					self::alert( EDSS_Ledger::get( $row['id'] ), $order, ' (refund not reversed)' );
				}
				continue;
			}

			$reversal = EDSS_Stripe::request(
				'POST',
				'transfers/' . rawurlencode( $row['transfer_id'] ) . '/reversals',
				array(
					'amount'   => $reverse,
					'metadata' => array(
						'refund_id' => (string) $refund_id,
						'order_id'  => (string) $order->get_id(),
						'edss_key'  => $row['idem_key'],
					),
				),
				'edss-rev-' . EDSS_Settings::site_tag() . '-' . $refund_id . '-' . $row['id']
			);

			if ( is_wp_error( $reversal ) ) {
				$msg = sprintf( 'Reversal of %s for refund #%d failed: %s', $label, $refund_id, $reversal->get_error_message() );
				EDSS_Ledger::update( $row['id'], array( 'last_error' => $msg ) );
				$order->add_order_note( 'Vendor split: ' . $msg . ' — reverse it manually in Stripe.' );
				$fresh = EDSS_Ledger::get( $row['id'] );
				self::alert( $fresh, $order, ' (REVERSAL FAILED)' );
				EDSS_Notifier::queue( $row['id'], 'reversal_failed' );
				continue;
			}

			$reversed      = (int) $row['reversed_minor'] + $reverse;
			$done[ $rkey ] = $reversal['id'];
			EDSS_Ledger::update(
				$row['id'],
				array(
					'reversed_minor' => $reversed,
					'reversal_ids'   => wp_json_encode( $done ),
					'status'         => $reversed >= (int) $row['educator_minor'] ? 'reversed' : 'partially_reversed',
					'last_error'     => '',
				)
			);
			$order->add_order_note( sprintf( 'Vendor split: refund #%d — reversed %s from %s (Stripe reversal %s).', $refund_id, $label, $row['account_id'], $reversal['id'] ) );
			EDSS_Notifier::queue( $row['id'], 'reversed' );
			do_action( 'edss_split_reversed', EDSS_Ledger::get( $row['id'] ), $order, $refund_id );
		}
	}
}
