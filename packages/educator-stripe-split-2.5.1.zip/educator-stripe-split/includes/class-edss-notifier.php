<?php
/**
 * Sends each split result to ONE webhook (Pabbly, Zapier, Make, n8n, a CRM…). The automation does not need to call Stripe or
 * look anything up — the payload already contains customer, course, vendor, amounts and the transfer ID.
 */

defined( 'ABSPATH' ) || exit;

class EDSS_Notifier {

	public static function init() {
		add_action( 'edss_send_webhook', array( __CLASS__, 'send' ), 10, 2 );
	}

	public static function queue( $row_id, $event ) {
		if ( ! EDSS_Settings::get( 'webhook_url' ) || ! in_array( $event, (array) EDSS_Settings::get( 'webhook_events' ), true ) ) {
			return;
		}
		if ( function_exists( 'as_enqueue_async_action' ) ) {
			as_enqueue_async_action( 'edss_send_webhook', array( (int) $row_id, $event ), EDSS_GROUP );
		} else {
			self::send( $row_id, $event );
		}
	}

	/**
	 * @return true|WP_Error
	 */
	public static function send( $row_id, $event ) {
		$url = EDSS_Settings::get( 'webhook_url' );
		$row = EDSS_Ledger::get( $row_id );
		if ( ! $url || ! $row ) {
			return new WP_Error( 'edss_webhook', 'No webhook URL or ledger row.' );
		}
		$result = self::post( $url, self::payload( $row, $event ) );
		EDSS_Ledger::update(
			$row_id,
			array( 'webhook_status' => substr( gmdate( 'Y-m-d H:i' ) . ' ' . $event . ': ' . ( is_wp_error( $result ) ? 'ERROR ' . $result->get_error_message() : 'sent' ), 0, 190 ) )
		);
		return $result;
	}

	public static function post( $url, $payload ) {
		$body    = wp_json_encode( $payload );
		$headers = array(
			'Content-Type' => 'application/json',
			'X-EDSS-Event'  => $payload['event'],
		);
		$secret = EDSS_Settings::get( 'webhook_secret' );
		if ( $secret ) {
			$headers['X-EDSS-Signature'] = 'sha256=' . hash_hmac( 'sha256', $body, $secret );
		}
		$res = wp_remote_post(
			$url,
			array(
				'timeout' => 15,
				'headers' => $headers,
				'body'    => $body,
			)
		);
		if ( is_wp_error( $res ) ) {
			self::log( 'Webhook error: ' . $res->get_error_message() );
			return $res;
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		if ( $code < 200 || $code >= 300 ) {
			self::log( 'Webhook HTTP ' . $code );
			return new WP_Error( 'edss_webhook_http', 'HTTP ' . $code );
		}
		return true;
	}

	private static function log( $message ) {
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->warning( $message, array( 'source' => 'educator-stripe-split' ) );
		}
	}

	public static function payload( $row, $event ) {
		$c        = $row['currency'];
		$order    = wc_get_order( $row['order_id'] );
		$product  = $row['product_id'] ? wc_get_product( $row['product_id'] ) : null;
		$educator = $row['educator_id'] ? get_userdata( $row['educator_id'] ) : null;

		return array(
			'event'    => $event,
			'site'     => home_url(),
			'mode'     => (int) $row['test_mode'] ? 'test' : 'live',
			'sent_at'  => gmdate( 'c' ),
			'split'    => array(
				'ledger_id'       => (int) $row['id'],
				'key'             => $row['idem_key'],
				'status'          => $row['status'],
				'stripe_transfer' => $row['transfer_id'],
				'stripe_charge'   => $row['charge_id'],
				'account_id'      => $row['account_id'],
				'currency'        => strtoupper( $c ),
				'gross_amount'    => EDSS_Stripe::from_minor( $row['gross_minor'], $c ),
				'vendor_amount'   => EDSS_Stripe::from_minor( $row['educator_minor'], $c ),
				'educator_amount' => EDSS_Stripe::from_minor( $row['educator_minor'], $c ), // Same value, older name.
				'platform_amount' => EDSS_Stripe::from_minor( $row['platform_minor'], $c ),
				'reversed_amount' => EDSS_Stripe::from_minor( $row['reversed_minor'], $c ),
				'split_type'      => $row['split_type'],
				'split_value'     => (float) $row['split_value'],
				'split_source'    => $row['split_source'],
				'error'           => (string) $row['last_error'],
			),
			'order'    => array(
				'id'              => (int) $row['order_id'],
				'number'          => $order ? $order->get_order_number() : '',
				'is_renewal'      => (bool) $row['is_renewal'],
				'subscription_id' => (int) $row['subscription_id'],
				'parent_order_id' => (int) $row['parent_order_id'],
				'total'           => $order ? (float) $order->get_total() : 0,
				'date_paid'       => ( $order && $order->get_date_paid() ) ? $order->get_date_paid()->date( 'c' ) : '',
				'payment_method'  => $order ? $order->get_payment_method() : '',
			),
			'customer' => array(
				'user_id'    => $order ? (int) $order->get_customer_id() : 0,
				'email'      => $order ? $order->get_billing_email() : '',
				'first_name' => $order ? $order->get_billing_first_name() : '',
				'last_name'  => $order ? $order->get_billing_last_name() : '',
				'phone'      => $order ? $order->get_billing_phone() : '',
			),
			'product'  => array(
				'id'   => (int) $row['product_id'],
				'name' => $product ? $product->get_name() : '',
				'sku'  => $product ? $product->get_sku() : '',
			),
			'course'   => array(
				'id'    => (int) $row['course_id'],
				'title' => $row['course_id'] ? get_the_title( $row['course_id'] ) : '',
			),
			'vendor'   => array(
				'id'    => (int) $row['educator_id'],
				'name'  => $educator ? $educator->display_name : '',
				'email' => $educator ? $educator->user_email : '',
			),
			'educator' => array(
				'id'    => (int) $row['educator_id'],
				'name'  => $educator ? $educator->display_name : '',
				'email' => $educator ? $educator->user_email : '',
			),
		);
	}

	/** Shape-only sample so the automation trigger can be mapped before real orders exist. */
	public static function sample_payload() {
		return array(
			'event'    => 'test',
			'site'     => home_url(),
			'mode'     => EDSS_Settings::mode_label(),
			'sent_at'  => gmdate( 'c' ),
			'split'    => array(
				'ledger_id'       => 0,
				'key'             => 'o0-i0',
				'status'          => 'test',
				'stripe_transfer' => 'tr_TEST',
				'stripe_charge'   => 'ch_TEST',
				'account_id'      => 'acct_TEST',
				'currency'        => strtoupper( get_woocommerce_currency() ),
				'gross_amount'    => 100.00,
				'vendor_amount'   => 40.00,
				'educator_amount' => 40.00,
				'platform_amount' => 60.00,
				'reversed_amount' => 0,
				'split_type'      => 'percent',
				'split_value'     => 40,
				'split_source'    => 'course',
				'error'           => '',
			),
			'order'    => array(
				'id'              => 0,
				'number'          => 'TEST',
				'is_renewal'      => false,
				'subscription_id' => 0,
				'parent_order_id' => 0,
				'total'           => 100.00,
				'date_paid'       => gmdate( 'c' ),
				'payment_method'  => 'stripe',
			),
			'customer' => array(
				'user_id'    => 0,
				'email'      => 'test-student@example.com',
				'first_name' => 'Test',
				'last_name'  => 'Student',
				'phone'      => '',
			),
			'product'  => array(
				'id'   => 0,
				'name' => 'TEST product',
				'sku'  => '',
			),
			'course'   => array(
				'id'    => 0,
				'title' => 'TEST course',
			),
			'vendor'   => array(
				'id'    => 0,
				'name'  => 'TEST vendor',
				'email' => 'test-vendor@example.com',
			),
			'educator' => array(
				'id'    => 0,
				'name'  => 'TEST vendor',
				'email' => 'test-vendor@example.com',
			),
		);
	}
}
